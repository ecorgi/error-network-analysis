#!/usr/bin/env python3
"""Build automatic annotations for the exact input corpus CSV."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.annotation import annotate_errors, detect_possible_interference
from src.io_utils import attach_native_language, load_corpus, load_student_meta, save_dataframe, validate_corpus
from src.preprocessing import preprocess_texts
from src.taxonomy import add_display_columns


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create automatic annotations for the exact input corpus.")
    parser.add_argument("--input", required=True, help="Path to corpus CSV with text_id/student_id/time_slice/lang_level/topic/text.")
    parser.add_argument("--output", required=True, help="Path to write annotations CSV.")
    parser.add_argument("--language", default="en", help="Language code.")
    parser.add_argument("--spacy-model", default=None, help="Optional explicit spaCy model, e.g. en_core_web_lg.")
    parser.add_argument(
        "--annotation-strategy",
        choices=["combined", "languagetool", "heuristic"],
        default="combined",
        help="Automatic annotation strategy. combined = LanguageTool plus corpus-local heuristics.",
    )
    parser.add_argument("--student-meta", default=None, help="Optional student metadata CSV.")
    parser.add_argument("--native-lang", default=None, help="Optional native language for the whole corpus.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    corpus_raw = load_corpus(args.input)
    corpus_df, _ = validate_corpus(corpus_raw)
    corpus_df = attach_native_language(corpus_df, load_student_meta(args.student_meta), args.native_lang)
    units_df = preprocess_texts(corpus_df, language=args.language, spacy_model=args.spacy_model)
    errors_df = add_display_columns(
        detect_possible_interference(
            annotate_errors(
                units_df,
                language=args.language,
                strategy=args.annotation_strategy,
                spacy_model=args.spacy_model,
            )
        )
    )
    save_dataframe(errors_df, args.output)
    print(f"Wrote {len(errors_df)} automatic annotation rows to {args.output}")
    print("Automatic annotations are heuristic/semi-automatic and require expert verification.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
