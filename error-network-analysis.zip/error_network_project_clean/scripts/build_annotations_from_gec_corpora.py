#!/usr/bin/env python3
"""Build `annotations.csv` from open/research GEC corpora.

The script can now automatically download the public JFLEG corpus from the
official GitHub repository and derive `annotations.csv` by aligning source
sentences with human reference corrections. It can also still convert local
M2/NUCLE-SGML files that you obtained under a research/non-commercial licence.

Licensing guardrail: the script does not bypass licence forms, gated downloads,
or authentication. For public JFLEG, `--accept-license` confirms that you accept
CC BY-NC-SA 4.0 terms. For gated corpora, use local files after obtaining access.

Important: this converter never invents or generates student essays. With
`--write-corpus-csv`, it writes `essays.csv` only by copying exact source texts
from the downloaded/extracted corpus so that `error_network_analysis.py` can use
the same `text_id` values as `annotations.csv`.

Supported modes:
  * automatic JFLEG download: --auto-download --dataset jfleg_github
  * local M2 files, as used by CoNLL/BEA grammatical error correction datasets
  * local NUCLE-style SGML files with <DOC>, <TEXT><P>...</P>, and <MISTAKE> tags

Outputs:
  * annotations.csv  -- annotation table for error_network_analysis.py
  * essays.csv       -- optional exact corpus source texts when --write-corpus-csv is set
  * text_index.csv   -- text IDs, hashes, offsets provenance
  * student_meta.csv -- optional, when native language is supplied
  * source_manifest.csv -- corpus provenance and licence notes

Example automatic JFLEG run:
  python scripts/build_annotations_from_gec_corpora.py \
    --auto-download \
    --dataset jfleg_github \
    --output-dir corpora/jfleg_annotations \
    --accept-license \
    --write-corpus-csv

Then run the analysis pipeline:
  python error_network_analysis.py \
    --input corpora/jfleg_annotations/essays.csv \
    --annotations corpora/jfleg_annotations/annotations.csv \
    --skip-grammar-check \
    --output-dir results_jfleg \
    --unit sentence
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import logging
import re
import sys
import urllib.error
import urllib.request
from difflib import SequenceMatcher
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Iterator

import pandas as pd


ANNOTATION_COLUMNS = [
    "error_id",
    "text_id",
    "student_id",
    "sentence_id",
    "start_char",
    "end_char",
    "error_span",
    "suggested_correction",
    "macro_category",
    "error_category",
    "interference_flag",
    "interference_type",
    "confidence",
    # Extra columns accepted by the main pipeline and useful for provenance.
    "time_slice",
    "lang_level",
    "native_lang",
    "topic",
    "unit_id",
    "paragraph_id",
    "tool_rule_id",
    "tool_message",
    "interference_confidence",
    "annotation_source",
    "source_corpus",
    "source_file",
    "source_error_type",
    "source_annotator",
]

TEXT_INDEX_COLUMNS = [
    "text_id",
    "student_id",
    "time_slice",
    "lang_level",
    "topic",
    "native_lang",
    "sentence_id",
    "paragraph_id",
    "source_corpus",
    "source_file",
    "source_record_index",
    "source_text_sha1",
    "source_text_char_count",
    "source_text_token_count",
]
REQUIRED_EXTERNAL_ESSAY_COLUMNS = ["text_id", "student_id", "time_slice", "lang_level", "topic", "text"]
CORPUS_COLUMNS = ["text_id", "student_id", "time_slice", "lang_level", "topic", "text", "native_lang"]
STUDENT_META_COLUMNS = ["student_id", "native_lang"]


@dataclass(frozen=True)
class DatasetLicense:
    """Known dataset licence metadata used for provenance and guardrails."""

    dataset_id: str
    name: str
    permitted_use: str
    licence_url: str
    citation_hint: str
    notes: str


KNOWN_DATASETS: dict[str, DatasetLicense] = {

    "jfleg_github": DatasetLicense(
        dataset_id="jfleg_github",
        name="JFLEG from the official GitHub repository",
        permitted_use="Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (research/non-commercial use)",
        licence_url="https://github.com/keisks/jfleg",
        citation_hint="Napoles, Sakaguchi & Tetreault (2017); Heilman et al. (2014) for the original GUG source",
        notes=(
            "Downloaded from the official public repository. The script derives edit annotations "
            "from the released source/reference pairs; these derived edits are automatic alignment, not expert error typing."
        ),
    ),
    "bea2019_fce": DatasetLicense(
        dataset_id="bea2019_fce",
        name="BEA 2019 / FCE M2 files",
        permitted_use="non-commercial research/educational use; user must accept the original Cambridge licence",
        licence_url="https://ilexir.co.uk/datasets/index.html",
        citation_hint="Yannakoudakis, Briscoe & Medlock (2011); BEA 2019 shared task paper if using BEA files",
        notes="Do not redistribute derived text unless the licence allows it; excerpts may be limited.",
    ),
    "bea2019_wi_locness": DatasetLicense(
        dataset_id="bea2019_wi_locness",
        name="BEA 2019 / W&I+LOCNESS M2 files",
        permitted_use="non-commercial research/educational use; user must accept the original Cambridge/LOCNESS terms",
        licence_url="https://www.cl.cam.ac.uk/research/nl/bea2019st/",
        citation_hint="Bryant et al. (2019) and the original W&I/LOCNESS dataset references",
        notes="LOCNESS has third-party redistribution restrictions; keep outputs internal to the licensed project.",
    ),
    "nucle": DatasetLicense(
        dataset_id="nucle",
        name="NUS Corpus of Learner English (NUCLE)",
        permitted_use="research use under the NUS licence agreement accepted by the user",
        licence_url="https://huggingface.co/datasets/nusnlp/NUCLE",
        citation_hint="Dahlmeier, Ng & Wu (2013)",
        notes="NUCLE is distributed under the NUS licensing agreement; do not bypass it.",
    ),
    "write_improve_2024": DatasetLicense(
        dataset_id="write_improve_2024",
        name="Write & Improve Corpus 2024",
        permitted_use="non-commercial research/educational use under Cambridge ELiT terms",
        licence_url="https://researchdatasets.cambridge.org/datasets/write-and-improve-corpus-2024",
        citation_hint="Nicholls et al. (2024)",
        notes="The exact source format may differ; use M2 only if you have an M2 export or adapt the loader.",
    ),
    "custom_research_noncommercial": DatasetLicense(
        dataset_id="custom_research_noncommercial",
        name="Custom research/non-commercial/open corpus",
        permitted_use="user-confirmed research/non-commercial/open-source compatible use",
        licence_url="",
        citation_hint="Use the dataset's required citation.",
        notes="Only use this option after checking the licence yourself.",
    ),
}


# Project taxonomy. Kept self-contained so the converter can run outside the main package.
CATEGORY_TO_MACRO = {
    "Punctuation": "Punctuation",
    "Spelling": "Spelling",
    "Capitalisation": "Capitalisation",
    "Articles_Determiners": "Grammar",
    "Prepositions": "Grammar",
    "Verb_Tense_Aspect": "Grammar",
    "Verb_Form_Morphology": "Grammar",
    "Subject_Verb_Agreement": "Grammar",
    "Noun_Number_Countability": "Grammar",
    "Pronouns": "Grammar",
    "Word_Order": "Grammar",
    "Sentence_Structure": "Grammar",
    "Word_Choice": "Vocabulary",
    "Collocations_Fixed_Expressions": "Vocabulary",
    "Reference": "Discourse",
    "Linking_Devices": "Discourse",
    "Discourse_Logic": "Discourse",
    "Other_Unclassified": "Technical",
}

# Mapping covers common ERRANT/M2 tags, CoNLL/NUCLE tags, and broad labels.
ERROR_TYPE_PATTERNS: list[tuple[re.Pattern[str], str, float]] = [
    (re.compile(r"(^|:)PUNCT|Mec|Punctuation", re.I), "Punctuation", 0.90),
    (re.compile(r"SPELL|Spelling|Mec:SPELL|R:ORTH", re.I), "Spelling", 0.88),
    (re.compile(r"ORTH|Capitali[sz]ation|CASE", re.I), "Capitalisation", 0.70),
    (re.compile(r"DET|ARTICLE|ArtOrDet|A_AN|THE", re.I), "Articles_Determiners", 0.88),
    (re.compile(r"PREP|Prep", re.I), "Prepositions", 0.86),
    (re.compile(r"VERB:TENSE|VERB:ASPECT|Vt|TENSE|ASPECT", re.I), "Verb_Tense_Aspect", 0.84),
    (re.compile(r"VERB:FORM|VERB:INFL|VERB|Vm|Vform|V0|Vinf|GERUND|PARTICIPLE", re.I), "Verb_Form_Morphology", 0.72),
    (re.compile(r"VERB:SVA|SVA|AGREEMENT|SubjectVerb", re.I), "Subject_Verb_Agreement", 0.84),
    (re.compile(r"NOUN:NUM|NOUN|Nn|COUNT|NUMBER|SINGULAR|PLURAL", re.I), "Noun_Number_Countability", 0.76),
    (re.compile(r"PRON|Pron|REFL|POSS", re.I), "Pronouns", 0.76),
    (re.compile(r"WO|WORD[_ -]?ORDER|Worder|WOinc|WOadv", re.I), "Word_Order", 0.82),
    (re.compile(r"SENT|Sentence|Srun|Smod|Sfrag|FRAGMENT|RUNON|CLAUSE", re.I), "Sentence_Structure", 0.76),
    (re.compile(r"CONJ|LINK|TRANS|Trans|CONNECT", re.I), "Linking_Devices", 0.70),
    (re.compile(r"REF|REFERENCE|COREF|ANTECEDENT|Rloc", re.I), "Reference", 0.68),
    (re.compile(r"Wci|Wtone|WORD[_ -]?CHOICE|LEX|OTHER:LEX|ADJ|ADV|NOUN:INFL", re.I), "Word_Choice", 0.68),
    (re.compile(r"COLLOC|IDIOM|PHRASE|FIXED", re.I), "Collocations_Fixed_Expressions", 0.74),
    (re.compile(r"LOGIC|COHER|DISCOURSE", re.I), "Discourse_Logic", 0.65),
]

SKIP_ERROR_TYPES = {"noop", "no-op", "none", "um", "unclear meaning"}

RU_INTERFERENCE_MAP = {
    "Articles_Determiners": ("L1_article_absence_transfer", 0.65),
    "Word_Order": ("L1_word_order_transfer", 0.60),
    "Prepositions": ("L1_preposition_transfer", 0.62),
    "Verb_Tense_Aspect": ("L1_tense_aspect_transfer", 0.60),
    "Reference": ("L1_reference_transfer", 0.58),
    "Pronouns": ("L1_reference_transfer", 0.58),
    "Noun_Number_Countability": ("L1_countability_transfer", 0.58),
}


def configure_logging(verbose: bool) -> None:
    """Configure console logging."""
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(levelname)s: %(message)s",
    )


def stable_id(*parts: object, length: int = 12) -> str:
    """Return a short deterministic hash for IDs."""
    raw = "||".join(str(p) for p in parts)
    return hashlib.sha1(raw.encode("utf-8", errors="replace")).hexdigest()[:length]


def normalize_label(value: object) -> str:
    """Normalize metadata labels for CSV output."""
    text = str(value or "").strip()
    return text if text else "unknown"


def safe_file_stem(path: Path) -> str:
    """Return a compact, filesystem-safe stem for provenance IDs."""
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", path.stem)[:80] or "file"


def token_offsets(tokens: list[str]) -> tuple[str, list[tuple[int, int]]]:
    """Reconstruct tokenized text with single spaces and return char offsets."""
    offsets: list[tuple[int, int]] = []
    cursor = 0
    pieces: list[str] = []
    for tok in tokens:
        if pieces:
            pieces.append(" ")
            cursor += 1
        start = cursor
        pieces.append(tok)
        cursor += len(tok)
        offsets.append((start, cursor))
    return "".join(pieces), offsets


def span_from_token_range(tokens: list[str], offsets: list[tuple[int, int]], start: int, end: int) -> tuple[int, int, str]:
    """Convert M2 token span [start, end) to char offsets in reconstructed text."""
    start = max(int(start), 0)
    end = max(int(end), 0)
    if not tokens:
        return 0, 0, ""
    if start == end:
        if start < len(offsets):
            pos = offsets[start][0]
        else:
            pos = offsets[-1][1]
        return pos, pos, ""
    start = min(start, len(tokens) - 1)
    end = min(max(end, start + 1), len(tokens))
    char_start = offsets[start][0]
    char_end = offsets[end - 1][1]
    return char_start, char_end, " ".join(tokens[start:end])


def map_source_error_type(source_error_type: str) -> tuple[str, str, float]:
    """Map source corpus error labels to the project taxonomy."""
    label = str(source_error_type or "").strip()
    for pattern, category, confidence in ERROR_TYPE_PATTERNS:
        if pattern.search(label):
            return CATEGORY_TO_MACRO[category], category, confidence
    return "Technical", "Other_Unclassified", 0.40


def interference_fields(native_lang: str | None, error_category: str) -> tuple[object, str, object]:
    """Return heuristic interference fields compatible with the main pipeline."""
    native = str(native_lang or "").strip().lower()
    if not native or native == "unknown":
        return None, "unknown_native_language", None
    if native in {"ru", "rus", "russian", "русский"} and error_category in RU_INTERFERENCE_MAP:
        interference_type, confidence = RU_INTERFERENCE_MAP[error_category]
        return True, interference_type, confidence
    return False, "not_flagged", 0.0


@dataclass
class M2Edit:
    """One M2 edit line."""

    start: int
    end: int
    error_type: str
    correction: str
    annotator: str
    raw: str


def parse_m2_edit(line: str) -> M2Edit | None:
    """Parse an M2 A-line. Return None for malformed or no-op edits."""
    # M2: A start end|||error_type|||correction|||REQUIRED|||-NONE-|||annotator
    if not line.startswith("A "):
        return None
    body = line[2:].rstrip("\n")
    parts = body.split("|||")
    if len(parts) < 3:
        logging.warning("Skipping malformed M2 edit: %s", line.rstrip())
        return None
    span = parts[0].strip().split()
    if len(span) < 2:
        logging.warning("Skipping M2 edit with malformed span: %s", line.rstrip())
        return None
    try:
        start, end = int(span[0]), int(span[1])
    except ValueError:
        logging.warning("Skipping M2 edit with non-integer span: %s", line.rstrip())
        return None
    error_type = parts[1].strip() or "Other"
    correction = parts[2].strip()
    annotator = parts[-1].strip() if len(parts) >= 6 else "0"
    if start < 0 or error_type.strip().lower() in SKIP_ERROR_TYPES:
        return None
    return M2Edit(start=start, end=end, error_type=error_type, correction=correction, annotator=annotator, raw=line.rstrip("\n"))


@dataclass
class SentenceRecord:
    """One source sentence/paragraph converted to corpus row plus annotations."""

    text_id: str
    student_id: str
    time_slice: str
    lang_level: str
    topic: str
    native_lang: str | None
    text: str
    sentence_id: str
    paragraph_id: str
    source_corpus: str
    source_file: str
    annotation_rows: list[dict[str, object]]


def iter_m2_blocks(path: Path) -> Iterator[tuple[list[str], list[M2Edit], int]]:
    """Yield M2 sentence tokens and edits from a file."""
    tokens: list[str] | None = None
    edits: list[M2Edit] = []
    sentence_index = 0

    def flush() -> Iterator[tuple[list[str], list[M2Edit], int]]:
        nonlocal tokens, edits, sentence_index
        if tokens is not None:
            yield tokens, edits, sentence_index
            sentence_index += 1
        tokens = None
        edits = []

    with path.open("r", encoding="utf-8", errors="replace") as fh:
        for raw_line in fh:
            line = raw_line.rstrip("\n")
            if not line.strip():
                yield from flush()
                continue
            if line.startswith("S "):
                if tokens is not None:
                    yield from flush()
                tokens = line[2:].split()
            elif line.startswith("A "):
                edit = parse_m2_edit(line)
                if edit is not None:
                    edits.append(edit)
        yield from flush()


def convert_m2_files(
    paths: list[Path],
    dataset: str,
    default_time_slice: str,
    default_lang_level: str,
    default_topic: str,
    default_native_lang: str | None,
    student_id_strategy: str,
) -> list[SentenceRecord]:
    """Convert M2 files into corpus records and annotation rows."""
    records: list[SentenceRecord] = []
    for path in paths:
        file_key = safe_file_stem(path)
        logging.info("Reading M2: %s", path)
        for tokens, edits, sent_idx in iter_m2_blocks(path):
            text, offsets = token_offsets(tokens)
            text_hash = stable_id(path.as_posix(), sent_idx, text, length=10)
            text_id = f"{dataset}_{file_key}_{sent_idx:06d}_{text_hash}"
            if student_id_strategy == "file":
                student_id = f"{dataset}_{file_key}"
            elif student_id_strategy == "sentence":
                student_id = f"{dataset}_{file_key}_{sent_idx:06d}"
            else:
                student_id = f"{dataset}_unknown_student"
            sentence_id = f"{text_id}::s0000"
            paragraph_id = f"{text_id}::p0000"
            annotation_rows: list[dict[str, object]] = []
            for edit_idx, edit in enumerate(edits):
                start_char, end_char, error_span = span_from_token_range(tokens, offsets, edit.start, edit.end)
                macro, category, confidence = map_source_error_type(edit.error_type)
                interference_flag, interference_type, interference_confidence = interference_fields(default_native_lang, category)
                error_id = f"E_{stable_id(dataset, path.as_posix(), sent_idx, edit_idx, edit.raw)}"
                annotation_rows.append(
                    {
                        "error_id": error_id,
                        "text_id": text_id,
                        "student_id": student_id,
                        "sentence_id": sentence_id,
                        "start_char": start_char,
                        "end_char": end_char,
                        "error_span": error_span,
                        "suggested_correction": edit.correction if edit.correction != "-NONE-" else "",
                        "macro_category": macro,
                        "error_category": category,
                        "interference_flag": interference_flag,
                        "interference_type": interference_type,
                        "confidence": confidence,
                        "time_slice": default_time_slice,
                        "lang_level": default_lang_level,
                        "native_lang": default_native_lang or "",
                        "topic": default_topic,
                        "unit_id": sentence_id,
                        "paragraph_id": paragraph_id,
                        "tool_rule_id": edit.error_type,
                        "tool_message": f"Imported from M2 edit type: {edit.error_type}",
                        "interference_confidence": interference_confidence,
                        "annotation_source": "expert_or_preannotated_m2",
                        "source_corpus": dataset,
                        "source_file": path.as_posix(),
                        "source_error_type": edit.error_type,
                        "source_annotator": edit.annotator,
                    }
                )
            records.append(
                SentenceRecord(
                    text_id=text_id,
                    student_id=student_id,
                    time_slice=default_time_slice,
                    lang_level=default_lang_level,
                    topic=default_topic,
                    native_lang=default_native_lang,
                    text=text,
                    sentence_id=sentence_id,
                    paragraph_id=paragraph_id,
                    source_corpus=dataset,
                    source_file=path.as_posix(),
                    annotation_rows=annotation_rows,
                )
            )
    return records


def strip_tags(text: str) -> str:
    """Remove simple SGML/XML tags and unescape entities."""
    return html.unescape(re.sub(r"<[^>]+>", "", text)).strip()


def parse_attrs(tag: str) -> dict[str, str]:
    """Parse XML-like attributes from an SGML start tag."""
    return {m.group(1): html.unescape(m.group(2)) for m in re.finditer(r"(\w+)\s*=\s*\"([^\"]*)\"", tag)}


def iter_nucle_docs(path: Path) -> Iterator[tuple[str, list[str], list[dict[str, object]]]]:
    """Yield NUCLE-style documents as (doc_id, paragraphs, mistakes)."""
    raw = path.read_text(encoding="utf-8", errors="replace")
    for doc_match in re.finditer(r"<DOC\b(?P<attrs>[^>]*)>(?P<body>.*?)</DOC>", raw, flags=re.I | re.S):
        attrs = parse_attrs(doc_match.group("attrs"))
        doc_id = attrs.get("nid") or attrs.get("id") or stable_id(path.as_posix(), doc_match.start())
        body = doc_match.group("body")
        text_match = re.search(r"<TEXT\b[^>]*>(?P<text>.*?)</TEXT>", body, flags=re.I | re.S)
        text_body = text_match.group("text") if text_match else body
        paragraphs = [strip_tags(m.group("p")) for m in re.finditer(r"<P\b[^>]*>(?P<p>.*?)</P>", text_body, flags=re.I | re.S)]
        if not paragraphs:
            paragraphs = [strip_tags(text_body)]
        mistakes: list[dict[str, object]] = []
        for mistake_match in re.finditer(r"<MISTAKE\b(?P<attrs>[^>]*)>(?P<body>.*?)</MISTAKE>", body, flags=re.I | re.S):
            m_attrs = parse_attrs(mistake_match.group("attrs"))
            m_body = mistake_match.group("body")
            type_match = re.search(r"<TYPE\b[^>]*>(?P<type>.*?)</TYPE>", m_body, flags=re.I | re.S)
            corr_match = re.search(r"<CORRECTION\b[^>]*>(?P<corr>.*?)</CORRECTION>", m_body, flags=re.I | re.S)
            try:
                mistakes.append(
                    {
                        "start_par": int(m_attrs.get("start_par", "0")),
                        "end_par": int(m_attrs.get("end_par", m_attrs.get("start_par", "0"))),
                        "start_off": int(m_attrs.get("start_off", "0")),
                        "end_off": int(m_attrs.get("end_off", m_attrs.get("start_off", "0"))),
                        "error_type": strip_tags(type_match.group("type")) if type_match else "Other",
                        "correction": strip_tags(corr_match.group("corr")) if corr_match else "",
                        "raw": mistake_match.group(0),
                    }
                )
            except ValueError:
                logging.warning("Skipping NUCLE mistake with malformed offsets in %s doc %s", path, doc_id)
        yield doc_id, paragraphs, mistakes


def convert_nucle_sgml_files(
    paths: list[Path],
    dataset: str,
    default_time_slice: str,
    default_lang_level: str,
    default_topic: str,
    default_native_lang: str | None,
) -> list[SentenceRecord]:
    """Convert NUCLE-style SGML to paragraph-level corpus records.

    NUCLE offsets are paragraph-level, so this converter indexes one source
    paragraph at a time and assigns all imported annotations to `::s0000`. It
    does not export paragraph text. For exact sentence-level co-occurrence,
    prefer an M2 version of NUCLE or run the main pipeline with `--unit text`/`--unit paragraph`.
    """
    records: list[SentenceRecord] = []
    for path in paths:
        logging.info("Reading NUCLE SGML: %s", path)
        file_key = safe_file_stem(path)
        for doc_id, paragraphs, mistakes in iter_nucle_docs(path):
            for p_idx, paragraph in enumerate(paragraphs):
                if not paragraph:
                    continue
                text_id = f"{dataset}_{file_key}_{doc_id}_p{p_idx:04d}_{stable_id(paragraph, length=8)}"
                student_id = f"{dataset}_{doc_id}"
                sentence_id = f"{text_id}::s0000"
                paragraph_id = f"{text_id}::p0000"
                annotation_rows: list[dict[str, object]] = []
                paragraph_mistakes = [m for m in mistakes if int(m["start_par"]) == p_idx and int(m["end_par"]) == p_idx]
                for edit_idx, mistake in enumerate(paragraph_mistakes):
                    start_char = max(0, min(int(mistake["start_off"]), len(paragraph)))
                    end_char = max(start_char, min(int(mistake["end_off"]), len(paragraph)))
                    error_type = str(mistake["error_type"])
                    if error_type.strip().lower() in SKIP_ERROR_TYPES:
                        continue
                    macro, category, confidence = map_source_error_type(error_type)
                    interference_flag, interference_type, interference_confidence = interference_fields(default_native_lang, category)
                    error_id = f"E_{stable_id(dataset, path.as_posix(), doc_id, p_idx, edit_idx, mistake.get('raw'))}"
                    annotation_rows.append(
                        {
                            "error_id": error_id,
                            "text_id": text_id,
                            "student_id": student_id,
                            "sentence_id": sentence_id,
                            "start_char": start_char,
                            "end_char": end_char,
                            "error_span": paragraph[start_char:end_char],
                            "suggested_correction": mistake["correction"],
                            "macro_category": macro,
                            "error_category": category,
                            "interference_flag": interference_flag,
                            "interference_type": interference_type,
                            "confidence": confidence,
                            "time_slice": default_time_slice,
                            "lang_level": default_lang_level,
                            "native_lang": default_native_lang or "",
                            "topic": default_topic,
                            "unit_id": sentence_id,
                            "paragraph_id": paragraph_id,
                            "tool_rule_id": error_type,
                            "tool_message": f"Imported from NUCLE SGML type: {error_type}",
                            "interference_confidence": interference_confidence,
                            "annotation_source": "expert_or_preannotated_nucle_sgml",
                            "source_corpus": dataset,
                            "source_file": path.as_posix(),
                            "source_error_type": error_type,
                            "source_annotator": "unknown",
                        }
                    )
                records.append(
                    SentenceRecord(
                        text_id=text_id,
                        student_id=student_id,
                        time_slice=default_time_slice,
                        lang_level=default_lang_level,
                        topic=default_topic,
                        native_lang=default_native_lang,
                        text=paragraph,
                        sentence_id=sentence_id,
                        paragraph_id=paragraph_id,
                        source_corpus=dataset,
                        source_file=path.as_posix(),
                        annotation_rows=annotation_rows,
                    )
                )
    return records


def read_metadata(metadata_csv: Path | None) -> pd.DataFrame | None:
    """Read optional metadata overrides."""
    if metadata_csv is None:
        return None
    if not metadata_csv.exists():
        raise FileNotFoundError(f"Metadata CSV not found: {metadata_csv}")
    df = pd.read_csv(metadata_csv, encoding="utf-8", dtype=str).fillna("")
    allowed = {"text_id", "student_id", "time_slice", "lang_level", "topic", "native_lang", "source_file", "source_corpus"}
    unknown = set(df.columns) - allowed
    if unknown:
        logging.warning("Metadata CSV has columns that will be ignored: %s", sorted(unknown))
    return df[[c for c in df.columns if c in allowed]]


def apply_metadata(records: list[SentenceRecord], metadata: pd.DataFrame | None) -> list[SentenceRecord]:
    """Apply optional metadata overrides by exact text_id or source_file."""
    if metadata is None or metadata.empty:
        return records

    by_text = {row["text_id"]: row for _, row in metadata.iterrows() if row.get("text_id")}
    by_file = {row["source_file"]: row for _, row in metadata.iterrows() if row.get("source_file")}
    updated: list[SentenceRecord] = []
    for rec in records:
        row = by_text.get(rec.text_id) or by_file.get(rec.source_file)
        if row is None:
            updated.append(rec)
            continue
        time_slice = row.get("time_slice") or rec.time_slice
        lang_level = row.get("lang_level") or rec.lang_level
        topic = row.get("topic") or rec.topic
        native_lang = row.get("native_lang") or rec.native_lang
        student_id = row.get("student_id") or rec.student_id
        # Keep text_id stable unless explicitly matched by source_file and changed.
        text_id = row.get("text_id") or rec.text_id
        sentence_id = f"{text_id}::s0000" if text_id != rec.text_id else rec.sentence_id
        paragraph_id = f"{text_id}::p0000" if text_id != rec.text_id else rec.paragraph_id
        new_rows = []
        for ann in rec.annotation_rows:
            ann = ann.copy()
            ann.update(
                {
                    "text_id": text_id,
                    "student_id": student_id,
                    "sentence_id": sentence_id,
                    "unit_id": sentence_id,
                    "paragraph_id": paragraph_id,
                    "time_slice": time_slice,
                    "lang_level": lang_level,
                    "topic": topic,
                    "native_lang": native_lang or "",
                }
            )
            flag, itype, iconf = interference_fields(native_lang, str(ann["error_category"]))
            ann["interference_flag"] = flag
            ann["interference_type"] = itype
            ann["interference_confidence"] = iconf
            new_rows.append(ann)
        updated.append(
            SentenceRecord(
                text_id=text_id,
                student_id=student_id,
                time_slice=time_slice,
                lang_level=lang_level,
                topic=topic,
                native_lang=native_lang,
                text=rec.text,
                sentence_id=sentence_id,
                paragraph_id=paragraph_id,
                source_corpus=rec.source_corpus,
                source_file=rec.source_file,
                annotation_rows=new_rows,
            )
        )
    return updated


def collect_paths(input_glob: list[str]) -> list[Path]:
    """Collect input files from glob patterns."""
    paths: list[Path] = []
    for pattern in input_glob:
        matches = sorted(Path().glob(pattern)) if not Path(pattern).is_absolute() else sorted(Path("/").glob(pattern.lstrip("/")))
        paths.extend(p for p in matches if p.is_file())
    unique = sorted(set(paths))
    if not unique:
        raise FileNotFoundError(f"No files matched: {input_glob}")
    return unique



JFLEG_BASE_URL = "https://raw.githubusercontent.com/keisks/jfleg/master"
JFLEG_FILES = [
    "dev/dev.src",
    "dev/dev.ref0",
    "dev/dev.ref1",
    "dev/dev.ref2",
    "dev/dev.ref3",
    "test/test.src",
    "test/test.ref0",
    "test/test.ref1",
    "test/test.ref2",
    "test/test.ref3",
]
TOKEN_RE = re.compile(r"\w+(?:['’]\w+)?|[^\w\s]", re.UNICODE)
PREPOSITIONS = {
    "about", "above", "across", "after", "against", "among", "around", "at", "before", "behind", "below",
    "between", "by", "during", "for", "from", "in", "into", "of", "on", "over", "through", "to", "under", "with", "without",
}
PRONOUNS = {"i", "me", "my", "mine", "you", "your", "he", "him", "his", "she", "her", "it", "its", "we", "us", "our", "they", "them", "their", "this", "that", "these", "those"}
ARTICLES = {"a", "an", "the"}
PUNCT = set(",.;:!?()[]{}\"'“”‘’-")


def download_file(url: str, output_path: Path, force: bool = False) -> None:
    """Download one URL unless the file already exists."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists() and not force:
        logging.info("Using cached download: %s", output_path)
        return
    logging.info("Downloading %s", url)
    try:
        with urllib.request.urlopen(url, timeout=60) as response:
            data = response.read()
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Could not download {url}: {exc}") from exc
    output_path.write_bytes(data)


def download_jfleg(download_dir: Path, force: bool = False, splits: list[str] | None = None) -> list[Path]:
    """Download the official JFLEG source/reference files from GitHub."""
    selected_splits = set(splits or ["dev", "test"])
    paths: list[Path] = []
    for relative in JFLEG_FILES:
        split = relative.split("/", 1)[0]
        if split not in selected_splits:
            continue
        url = f"{JFLEG_BASE_URL}/{relative}"
        out = download_dir / "jfleg_github" / relative
        download_file(url, out, force=force)
        paths.append(out)
    return paths


def read_parallel_lines(path: Path) -> list[str]:
    """Read a UTF-8 text file as a list of stripped lines."""
    return path.read_text(encoding="utf-8", errors="replace").splitlines()


def tokenize_with_offsets(text: str) -> list[tuple[str, int, int]]:
    """Tokenize text for alignment while keeping character offsets."""
    return [(m.group(0), m.start(), m.end()) for m in TOKEN_RE.finditer(text)]


def classify_parallel_edit(source_tokens: list[str], correction_tokens: list[str], tag: str) -> tuple[str, str, float]:
    """Heuristically classify an edit derived from source/reference alignment.

    JFLEG provides fluent reference corrections but not expert error labels. This
    function therefore produces a conservative, explicitly automatic category.
    """
    src = [t for t in source_tokens if t]
    cor = [t for t in correction_tokens if t]
    src_l = [t.lower() for t in src]
    cor_l = [t.lower() for t in cor]
    all_l = set(src_l + cor_l)
    all_chars = "".join(src + cor)

    if any(ch in PUNCT for ch in all_chars) and not any(tok.isalpha() for tok in src + cor):
        return "Punctuation", "Punctuation", 0.72
    if any(tok in ARTICLES for tok in cor_l + src_l):
        return "Grammar", "Articles_Determiners", 0.68
    if all_l & PREPOSITIONS:
        return "Grammar", "Prepositions", 0.64
    if all_l & PRONOUNS:
        return "Grammar", "Pronouns", 0.58
    if len(src) == len(cor) == 1 and src[0].lower() == cor[0].lower() and src[0] != cor[0]:
        return "Capitalisation", "Capitalisation", 0.82
    if len(src) == len(cor) == 1 and src and cor:
        ratio = SequenceMatcher(None, src[0].lower(), cor[0].lower()).ratio()
        if ratio >= 0.78 and src[0].lower() != cor[0].lower():
            return "Spelling", "Spelling", 0.70
    if any(t.endswith("ed") or t.endswith("ing") for t in src_l + cor_l):
        return "Grammar", "Verb_Tense_Aspect", 0.52
    if tag in {"insert", "delete"} and len(src) + len(cor) >= 3:
        return "Grammar", "Sentence_Structure", 0.46
    return "Vocabulary", "Word_Choice", 0.45


def edits_from_parallel_sentence(
    source: str,
    correction: str,
    dataset: str,
    split: str,
    sent_idx: int,
    ref_idx: int,
    text_id: str,
    student_id: str,
    sentence_id: str,
    paragraph_id: str,
    native_lang: str | None,
    default_time_slice: str,
    default_lang_level: str,
    default_topic: str,
    source_file: str,
) -> list[dict[str, object]]:
    """Create annotation rows by aligning one source sentence to one reference."""
    src_tok_offsets = tokenize_with_offsets(source)
    cor_tok_offsets = tokenize_with_offsets(correction)
    src_tokens = [t for t, _, _ in src_tok_offsets]
    cor_tokens = [t for t, _, _ in cor_tok_offsets]
    matcher = SequenceMatcher(None, src_tokens, cor_tokens, autojunk=False)
    rows: list[dict[str, object]] = []
    edit_counter = 0
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        source_piece = src_tokens[i1:i2]
        correction_piece = cor_tokens[j1:j2]
        if i1 < i2 and src_tok_offsets:
            start_char = src_tok_offsets[i1][1]
            end_char = src_tok_offsets[i2 - 1][2]
            error_span = source[start_char:end_char]
        else:
            # Insertion: point the zero-length span at the next source token, or end of sentence.
            start_char = src_tok_offsets[i1][1] if i1 < len(src_tok_offsets) else len(source)
            end_char = start_char
            error_span = ""
        suggested_correction = " ".join(correction_piece)
        macro, category, confidence = classify_parallel_edit(source_piece, correction_piece, tag)
        interference_flag, interference_type, interference_confidence = interference_fields(native_lang, category)
        error_id = f"E_{stable_id(dataset, split, sent_idx, ref_idx, edit_counter, tag, start_char, end_char, suggested_correction)}"
        rows.append(
            {
                "error_id": error_id,
                "text_id": text_id,
                "student_id": student_id,
                "sentence_id": sentence_id,
                "start_char": start_char,
                "end_char": end_char,
                "error_span": error_span,
                "suggested_correction": suggested_correction,
                "macro_category": macro,
                "error_category": category,
                "interference_flag": interference_flag,
                "interference_type": interference_type,
                "confidence": confidence,
                "time_slice": default_time_slice,
                "lang_level": default_lang_level,
                "native_lang": native_lang or "",
                "topic": default_topic,
                "unit_id": sentence_id,
                "paragraph_id": paragraph_id,
                "tool_rule_id": f"JFLEG_ALIGNMENT_{tag.upper()}",
                "tool_message": "Automatically derived from JFLEG source/reference alignment; not expert error typing.",
                "interference_confidence": interference_confidence,
                "annotation_source": "public_parallel_corpus_auto_aligned",
                "source_corpus": dataset,
                "source_file": source_file,
                "source_error_type": f"parallel_alignment:{tag}",
                "source_annotator": f"ref{ref_idx}",
            }
        )
        edit_counter += 1
    return rows


def convert_jfleg_download(
    download_dir: Path,
    dataset: str,
    splits: list[str],
    reference_strategy: str,
    force_download: bool,
    default_time_slice: str,
    default_lang_level: str,
    default_topic: str,
    default_native_lang: str | None,
) -> tuple[list[SentenceRecord], list[Path]]:
    """Download and convert JFLEG into corpus records plus derived annotations."""
    input_paths = download_jfleg(download_dir=download_dir, splits=splits, force=force_download)
    records: list[SentenceRecord] = []
    for split in splits:
        split_dir = download_dir / "jfleg_github" / split
        src_path = split_dir / f"{split}.src"
        if not src_path.exists():
            raise FileNotFoundError(f"Downloaded source file not found: {src_path}")
        sources = read_parallel_lines(src_path)
        refs_by_idx = []
        for ref_idx in range(4):
            ref_path = split_dir / f"{split}.ref{ref_idx}"
            refs_by_idx.append(read_parallel_lines(ref_path))
        selected_ref_indices = [0] if reference_strategy == "first" else [0, 1, 2, 3]
        for sent_idx, source in enumerate(sources):
            if not source.strip():
                continue
            text_id = f"{dataset}_{split}_{sent_idx:06d}_{stable_id(source, length=8)}"
            student_id = f"{dataset}_{split}_{sent_idx:06d}"
            sentence_id = f"{text_id}::s0000"
            paragraph_id = f"{text_id}::p0000"
            annotation_rows: list[dict[str, object]] = []
            for ref_idx in selected_ref_indices:
                if sent_idx >= len(refs_by_idx[ref_idx]):
                    logging.warning("Missing JFLEG reference ref%d line %d", ref_idx, sent_idx)
                    continue
                annotation_rows.extend(
                    edits_from_parallel_sentence(
                        source=source,
                        correction=refs_by_idx[ref_idx][sent_idx],
                        dataset=dataset,
                        split=split,
                        sent_idx=sent_idx,
                        ref_idx=ref_idx,
                        text_id=text_id,
                        student_id=student_id,
                        sentence_id=sentence_id,
                        paragraph_id=paragraph_id,
                        native_lang=default_native_lang,
                        default_time_slice=default_time_slice,
                        default_lang_level=default_lang_level,
                        default_topic=f"{default_topic}_{split}" if default_topic == "open_gec_corpus" else default_topic,
                        source_file=src_path.as_posix(),
                    )
                )
            records.append(
                SentenceRecord(
                    text_id=text_id,
                    student_id=student_id,
                    time_slice=default_time_slice if default_time_slice != "unknown_time" else split,
                    lang_level=default_lang_level,
                    topic=f"{default_topic}_{split}" if default_topic == "open_gec_corpus" else default_topic,
                    native_lang=default_native_lang,
                    text=source,
                    sentence_id=sentence_id,
                    paragraph_id=paragraph_id,
                    source_corpus=dataset,
                    source_file=src_path.as_posix(),
                    annotation_rows=annotation_rows,
                )
            )
    return records, input_paths

def records_to_dataframes(records: list[SentenceRecord]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Convert internal records to text index, annotations and student metadata.

    The returned text index intentionally excludes the source text. The converter
    reads corpus text only to calculate annotation offsets and hashes; it never
    exports essays or full sentences.
    """
    corpus_rows = []
    text_index_rows = []
    for idx, rec in enumerate(records):
        corpus_rows.append(
            {
                "text_id": rec.text_id,
                "student_id": rec.student_id,
                "time_slice": rec.time_slice,
                "lang_level": rec.lang_level,
                "topic": rec.topic,
                "text": rec.text,
                "native_lang": rec.native_lang or "",
            }
        )
        tokens = rec.text.split()
        text_index_rows.append(
            {
                "text_id": rec.text_id,
                "student_id": rec.student_id,
                "time_slice": rec.time_slice,
                "lang_level": rec.lang_level,
                "topic": rec.topic,
                "native_lang": rec.native_lang or "",
                "sentence_id": rec.sentence_id,
                "paragraph_id": rec.paragraph_id,
                "source_corpus": rec.source_corpus,
                "source_file": rec.source_file,
                "source_record_index": idx,
                "source_text_sha1": hashlib.sha1(rec.text.encode("utf-8", errors="replace")).hexdigest(),
                "source_text_char_count": len(rec.text),
                "source_text_token_count": len(tokens),
            }
        )
    annotation_rows = [ann for rec in records for ann in rec.annotation_rows]
    meta_rows = [
        {"student_id": rec.student_id, "native_lang": rec.native_lang}
        for rec in records
        if rec.native_lang is not None and str(rec.native_lang).strip()
    ]
    corpus_df = pd.DataFrame(corpus_rows, columns=CORPUS_COLUMNS).drop_duplicates("text_id")
    text_index = pd.DataFrame(text_index_rows, columns=TEXT_INDEX_COLUMNS).drop_duplicates("text_id")
    annotations = pd.DataFrame(annotation_rows, columns=ANNOTATION_COLUMNS)
    student_meta = pd.DataFrame(meta_rows, columns=STUDENT_META_COLUMNS).drop_duplicates("student_id")
    return corpus_df, text_index, annotations, student_meta


def write_outputs(
    output_dir: Path,
    corpus_df: pd.DataFrame,
    text_index: pd.DataFrame,
    annotations: pd.DataFrame,
    student_meta: pd.DataFrame,
    dataset_license: DatasetLicense,
    input_paths: list[Path],
    args: argparse.Namespace,
) -> None:
    """Write CSV outputs and manifest. No source essay text is exported."""
    output_dir.mkdir(parents=True, exist_ok=True)
    if getattr(args, "write_corpus_csv", False):
        corpus_df.to_csv(output_dir / "essays.csv", index=False, encoding="utf-8")
    text_index.to_csv(output_dir / "text_index.csv", index=False, encoding="utf-8")
    annotations.to_csv(output_dir / "annotations.csv", index=False, encoding="utf-8", quoting=csv.QUOTE_MINIMAL)
    if not student_meta.empty:
        student_meta.to_csv(output_dir / "student_meta.csv", index=False, encoding="utf-8")

    manifest_rows = []
    for path in input_paths:
        manifest_rows.append(
            {
                "source_corpus": args.dataset,
                "source_file": path.as_posix(),
                "dataset_name": dataset_license.name,
                "permitted_use": dataset_license.permitted_use,
                "licence_url": dataset_license.licence_url,
                "citation_hint": dataset_license.citation_hint,
                "licence_accepted_by_user": bool(args.accept_license),
                "notes": dataset_license.notes,
            }
        )
    pd.DataFrame(manifest_rows).to_csv(output_dir / "source_manifest.csv", index=False, encoding="utf-8")

    summary = {
        "dataset": asdict(dataset_license),
        "input_file_count": len(input_paths),
        "corpus_rows_written": int(len(corpus_df)) if getattr(args, "write_corpus_csv", False) else 0,
        "text_index_rows": int(len(text_index)),
        "annotation_rows": int(len(annotations)),
        "student_meta_rows": int(len(student_meta)),
        "format": args.format,
        "default_time_slice": args.default_time_slice,
        "default_lang_level": args.default_lang_level,
        "default_topic": args.default_topic,
        "default_native_lang": args.default_native_lang,
        "licence_accepted_by_user": bool(args.accept_license),
        "warning": (
            "The converter never invents or generates student essays. "
            "When --write-corpus-csv is used, essays.csv contains exact source texts downloaded/extracted from the licensed corpus. "
            "Do not redistribute source text or derived annotations unless the original corpus licence permits it."
        ),
    }
    (output_dir / "build_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")


def validate_outputs(text_index: pd.DataFrame, annotations: pd.DataFrame) -> None:
    """Run basic validation and warnings for generated annotation outputs."""
    if text_index.empty:
        raise ValueError("No source text records were indexed from the annotation files.")
    missing = set(TEXT_INDEX_COLUMNS) - set(text_index.columns)
    if missing:
        raise ValueError(f"Generated text_index.csv missing columns: {sorted(missing)}")
    missing_ann = set(ANNOTATION_COLUMNS[:13]) - set(annotations.columns)
    if missing_ann:
        raise ValueError(f"Generated annotations.csv missing required columns: {sorted(missing_ann)}")
    if annotations.empty:
        logging.warning("No annotations were generated. Check whether files contain edits/mistakes or only no-op annotations.")
    unknown_share = 0.0
    if not annotations.empty:
        unknown_share = float((annotations["error_category"] == "Other_Unclassified").mean())
    if unknown_share > 0.25:
        logging.warning(
            "%.1f%% of annotations are Other_Unclassified. Consider extending ERROR_TYPE_PATTERNS for this corpus.",
            unknown_share * 100,
        )



def validate_external_essays_csv(path: Path, annotations: pd.DataFrame) -> None:
    """Validate that an external licensed corpus CSV can be paired with annotations.

    The CSV is read only for validation. It is not copied, modified, or written to
    the converter output directory.
    """
    if not path.exists():
        raise FileNotFoundError(f"External essays CSV not found: {path}")
    essays = pd.read_csv(path, encoding="utf-8", dtype=str, usecols=lambda c: c in REQUIRED_EXTERNAL_ESSAY_COLUMNS)
    missing_columns = set(REQUIRED_EXTERNAL_ESSAY_COLUMNS) - set(essays.columns)
    if missing_columns:
        raise ValueError(f"External essays CSV missing required columns: {sorted(missing_columns)}")
    if not annotations.empty:
        essay_ids = set(essays["text_id"].astype(str))
        annotation_ids = set(annotations["text_id"].astype(str))
        missing_ids = sorted(annotation_ids - essay_ids)
        if missing_ids:
            preview = ", ".join(missing_ids[:5])
            raise ValueError(
                f"External essays CSV does not contain {len(missing_ids)} annotated text_id values. "
                f"Examples: {preview}"
            )
    logging.info("Validated external essays CSV for text_id coverage: %s", path)

def build_arg_parser() -> argparse.ArgumentParser:
    """Build command-line argument parser."""
    parser = argparse.ArgumentParser(
        description="Download/convert permitted GEC corpora into annotations.csv for the error-network pipeline."
    )
    parser.add_argument("--format", choices=["m2", "nucle-sgml"], default=None, help="Local input annotation format. Omit for --auto-download jfleg_github.")
    parser.add_argument(
        "--auto-download",
        action="store_true",
        help="Automatically download a supported public/open research corpus instead of reading --input-glob.",
    )
    parser.add_argument(
        "--download-dir",
        type=Path,
        default=Path(".cache/gec_corpora"),
        help="Directory for downloaded corpus files.",
    )
    parser.add_argument("--force-download", action="store_true", help="Re-download files even if cached.")
    parser.add_argument(
        "--include-splits",
        default="dev,test",
        help="Comma-separated splits for auto-download datasets, e.g. dev,test for JFLEG.",
    )
    parser.add_argument(
        "--reference-strategy",
        choices=["first", "all"],
        default="first",
        help="For parallel corpora with several references: use the first reference or all references.",
    )
    parser.add_argument(
        "--write-corpus-csv",
        action="store_true",
        help=(
            "Also write essays.csv from the downloaded/extracted source texts. "
            "The script does not generate text; it copies exact corpus source texts locally for the main pipeline."
        ),
    )
    parser.add_argument("--dataset", choices=sorted(KNOWN_DATASETS), required=True, help="Known dataset/licence profile.")
    parser.add_argument(
        "--input-glob",
        nargs="+",
        default=None,
        help="One or more glob patterns for local source files, e.g. 'data/**/*.m2'. Quote globs in the shell.",
    )
    parser.add_argument("--output-dir", required=True, type=Path, help="Output directory for generated CSV files.")
    parser.add_argument(
        "--accept-license",
        action="store_true",
        help="Confirm that you have obtained the data legally and accepted the relevant research/non-commercial licence.",
    )
    parser.add_argument(
        "--allow-custom-dataset",
        action="store_true",
        help="Allow custom_research_noncommercial after manual licence review. Does not weaken licence responsibility.",
    )
    parser.add_argument("--metadata-csv", type=Path, default=None, help="Optional metadata overrides CSV.")
    parser.add_argument(
        "--external-essays-csv",
        type=Path,
        default=None,
        help=(
            "Optional already-licensed corpus CSV to validate text_id coverage. "
            "The file is read only; it is never copied or regenerated."
        ),
    )
    parser.add_argument("--default-time-slice", default="unknown_time", help="Default time_slice value.")
    parser.add_argument("--default-lang-level", default="unknown_level", help="Default lang_level value.")
    parser.add_argument("--default-topic", default="open_gec_corpus", help="Default topic value.")
    parser.add_argument("--default-native-lang", default=None, help="Default native language, e.g. ru; omit if unknown.")
    parser.add_argument(
        "--student-id-strategy",
        choices=["file", "sentence", "unknown"],
        default="file",
        help="How to synthesize student_id for M2 files without learner metadata.",
    )
    parser.add_argument("--verbose", action="store_true", help="Verbose logging.")
    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    configure_logging(args.verbose)

    if not args.accept_license:
        parser.error("Refusing to process corpus data until --accept-license is set.")
    if args.dataset == "custom_research_noncommercial" and not args.allow_custom_dataset:
        parser.error("custom_research_noncommercial requires --allow-custom-dataset after manual licence review.")

    dataset_license = KNOWN_DATASETS[args.dataset]
    metadata = read_metadata(args.metadata_csv)
    splits = [s.strip() for s in str(args.include_splits).split(",") if s.strip()]

    if args.auto_download:
        if args.dataset != "jfleg_github":
            parser.error("Currently --auto-download is implemented for --dataset jfleg_github. Use --input-glob for other licensed corpora.")
        records, input_paths = convert_jfleg_download(
            download_dir=args.download_dir,
            dataset=args.dataset,
            splits=splits or ["dev", "test"],
            reference_strategy=args.reference_strategy,
            force_download=args.force_download,
            default_time_slice=normalize_label(args.default_time_slice),
            default_lang_level=normalize_label(args.default_lang_level),
            default_topic=normalize_label(args.default_topic),
            default_native_lang=args.default_native_lang,
        )
    else:
        if args.format is None:
            parser.error("--format is required unless --auto-download is used.")
        if not args.input_glob:
            parser.error("--input-glob is required unless --auto-download is used.")
        input_paths = collect_paths(args.input_glob)
        if args.format == "m2":
            records = convert_m2_files(
                paths=input_paths,
                dataset=args.dataset,
                default_time_slice=normalize_label(args.default_time_slice),
                default_lang_level=normalize_label(args.default_lang_level),
                default_topic=normalize_label(args.default_topic),
                default_native_lang=args.default_native_lang,
                student_id_strategy=args.student_id_strategy,
            )
        elif args.format == "nucle-sgml":
            records = convert_nucle_sgml_files(
                paths=input_paths,
                dataset=args.dataset,
                default_time_slice=normalize_label(args.default_time_slice),
                default_lang_level=normalize_label(args.default_lang_level),
                default_topic=normalize_label(args.default_topic),
                default_native_lang=args.default_native_lang,
            )
        else:  # pragma: no cover
            raise AssertionError(args.format)

    records = apply_metadata(records, metadata)
    corpus_df, text_index, annotations, student_meta = records_to_dataframes(records)
    validate_outputs(text_index, annotations)
    if args.external_essays_csv is not None:
        validate_external_essays_csv(args.external_essays_csv, annotations)
    write_outputs(args.output_dir, corpus_df, text_index, annotations, student_meta, dataset_license, input_paths, args)

    if args.write_corpus_csv:
        logging.info("Wrote %s", args.output_dir / "essays.csv")
    logging.info("Wrote %s", args.output_dir / "text_index.csv")
    logging.info("Wrote %s", args.output_dir / "annotations.csv")
    if not student_meta.empty:
        logging.info("Wrote %s", args.output_dir / "student_meta.csv")
    logging.info("Indexed %d source text records and wrote %d annotation rows", len(text_index), len(annotations))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
