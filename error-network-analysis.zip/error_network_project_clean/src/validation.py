"""Expert validation sampling, scoring and inter-annotator agreement."""

from __future__ import annotations

from itertools import combinations
from math import ceil
from pathlib import Path

import numpy as np
import pandas as pd

NO_ERROR_LABEL = "NO_ERROR"


def _available_columns(df: pd.DataFrame, columns: list[str]) -> list[str]:
    return [col for col in columns if col in df.columns]


def _error_key(row: pd.Series) -> str:
    """Build a stable item key when validation_id is absent."""
    parts = [
        row.get("text_id", ""),
        row.get("sentence_id", ""),
        row.get("start_char", ""),
        row.get("end_char", ""),
        row.get("error_span", ""),
    ]
    return "||".join(str(part) for part in parts)


def _context_for_error(row: pd.Series, units_df: pd.DataFrame, width: int = 120) -> str:
    text = str(row.get("sentence_text", "") or "")
    sentence_start = 0
    if not text and "sentence_id" in row and "sentence_id" in units_df.columns:
        matched = units_df[units_df["sentence_id"].astype(str).eq(str(row.get("sentence_id")))]
        if not matched.empty:
            text = str(matched.iloc[0].get("sentence_text", ""))
            sentence_start = int(pd.to_numeric(pd.Series([matched.iloc[0].get("sentence_start_char", 0)]), errors="coerce").fillna(0).iloc[0])
    if not text:
        text = str(row.get("clean_text", "") or row.get("text", "") or "")
    start = int(pd.to_numeric(pd.Series([row.get("start_char", 0)]), errors="coerce").fillna(0).iloc[0])
    local_start = max(0, min(len(text), start - sentence_start))
    return text[max(0, local_start - width) : min(len(text), local_start + width)]


def create_stratified_validation_sample(
    corpus_df: pd.DataFrame,
    units_df: pd.DataFrame,
    errors_df: pd.DataFrame,
    fraction: float = 0.30,
    strata_cols: list[str] | None = None,
    random_seed: int = 42,
) -> pd.DataFrame:
    """Create a 20-30% stratified corpus sample for expert annotation review.

    The sample is drawn at text level and then expanded to all detected errors in
    the selected texts. Texts without detected errors are kept as blank review
    rows so experts can mark missed errors if needed.
    """
    if corpus_df.empty:
        return pd.DataFrame()

    fraction = min(max(float(fraction), 0.20), 1.0)
    strata_cols = _available_columns(corpus_df, strata_cols or ["lang_level", "time_slice"])
    base = corpus_df.drop_duplicates("text_id").copy()
    target_n = max(1, ceil(len(base) * fraction))

    if strata_cols:
        sampled_parts = []
        for _, group in base.groupby(strata_cols, dropna=False):
            n = max(1, ceil(len(group) * fraction))
            sampled_parts.append(group.sample(n=min(n, len(group)), random_state=random_seed))
        sampled = pd.concat(sampled_parts, ignore_index=True).drop_duplicates("text_id")
        if len(sampled) > target_n:
            sampled = sampled.sample(n=target_n, random_state=random_seed).copy()
    else:
        sampled = base.sample(n=target_n, random_state=random_seed).copy()

    sampled_ids = set(sampled["text_id"].astype(str))
    sampled_errors = errors_df[errors_df["text_id"].astype(str).isin(sampled_ids)].copy() if not errors_df.empty else pd.DataFrame()

    rows: list[dict[str, object]] = []
    for _, text_row in sampled.sort_values("text_id").iterrows():
        text_errors = (
            sampled_errors[sampled_errors["text_id"].astype(str).eq(str(text_row["text_id"]))]
            if not sampled_errors.empty
            else pd.DataFrame()
        )
        if text_errors.empty:
            rows.append(
                {
                    "text_id": text_row.get("text_id"),
                    "student_id": text_row.get("student_id"),
                    "time_slice": text_row.get("time_slice"),
                    "lang_level": text_row.get("lang_level"),
                    "topic": text_row.get("topic"),
                    "sentence_id": "",
                    "start_char": "",
                    "end_char": "",
                    "error_span": "",
                    "context": str(text_row.get("text", ""))[:240],
                    "auto_macro_category": "",
                    "auto_error_category": NO_ERROR_LABEL,
                    "expert_error_category": "",
                    "expert_is_error": "",
                    "expert_comment": "",
                }
            )
            continue
        for _, error_row in text_errors.iterrows():
            rows.append(
                {
                    "text_id": error_row.get("text_id"),
                    "student_id": error_row.get("student_id"),
                    "time_slice": error_row.get("time_slice"),
                    "lang_level": error_row.get("lang_level"),
                    "topic": error_row.get("topic"),
                    "sentence_id": error_row.get("sentence_id"),
                    "start_char": error_row.get("start_char"),
                    "end_char": error_row.get("end_char"),
                    "error_span": error_row.get("error_span"),
                    "context": _context_for_error(error_row, units_df),
                    "auto_macro_category": error_row.get("macro_category", ""),
                    "auto_error_category": error_row.get("error_category", NO_ERROR_LABEL),
                    "expert_error_category": "",
                    "expert_is_error": "",
                    "expert_comment": "",
                }
            )

    result = pd.DataFrame(rows)
    result.insert(0, "validation_id", [f"VAL{i:06d}" for i in range(1, len(result) + 1)])
    result["review_key"] = result.apply(_error_key, axis=1)
    return result


def _read_expert_labels(path: str | Path, expert_name: str | None = None) -> pd.DataFrame:
    """Read one expert file and normalize label/id columns."""
    df = pd.read_csv(path, encoding="utf-8", dtype=str).fillna("")
    category_col = next(
        (col for col in ["expert_error_category", "expert_category", "error_category_expert", "error_category"] if col in df.columns),
        None,
    )
    if category_col is None:
        raise ValueError(f"Expert file {path} does not contain an expert category column.")

    ids = df["validation_id"].astype(str) if "validation_id" in df.columns else df.apply(_error_key, axis=1)
    labels = df[category_col].astype(str).str.strip()
    if "expert_is_error" in df.columns:
        is_error = df["expert_is_error"].astype(str).str.strip().str.lower()
        labels = labels.mask(is_error.isin({"0", "false", "no", "нет", "exclude", "not_error"}), NO_ERROR_LABEL)
    labels = labels.replace("", NO_ERROR_LABEL)
    name = expert_name or Path(path).stem
    return pd.DataFrame({"item_id": ids, "expert": name, "label": labels})


def _classification_counts(y_true: pd.Series, y_pred: pd.Series, category: str) -> tuple[int, int, int, int]:
    true_pos = int(((y_true == category) & (y_pred == category)).sum())
    false_pos = int(((y_true != category) & (y_pred == category)).sum())
    false_neg = int(((y_true == category) & (y_pred != category)).sum())
    true_neg = int(((y_true != category) & (y_pred != category)).sum())
    return true_pos, false_pos, false_neg, true_neg


def compare_with_expert_validation(
    automatic_df: pd.DataFrame,
    expert_path: str | Path,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compare automatic labels with one expert validation file."""
    expert = pd.read_csv(expert_path, encoding="utf-8", dtype=str).fillna("")
    auto_label_col = "auto_error_category" if "auto_error_category" in expert.columns else "error_category"
    if auto_label_col not in expert.columns:
        raise ValueError("Expert validation file must contain auto_error_category or error_category.")
    expert_labels = _read_expert_labels(expert_path)

    item_ids = expert["validation_id"].astype(str) if "validation_id" in expert.columns else expert.apply(_error_key, axis=1)
    auto = pd.DataFrame(
        {
            "item_id": item_ids,
            "auto_label": expert[auto_label_col].astype(str).str.strip().replace("", NO_ERROR_LABEL),
        }
    )
    if automatic_df is not None and not automatic_df.empty and "validation_id" in automatic_df.columns:
        auto = automatic_df[["validation_id", auto_label_col]].rename(
            columns={"validation_id": "item_id", auto_label_col: "auto_label"}
        )
    merged = auto.merge(expert_labels[["item_id", "label"]].rename(columns={"label": "expert_label"}), on="item_id", how="inner")
    if merged.empty:
        return pd.DataFrame(), pd.DataFrame()

    labels = sorted(set(merged["auto_label"]) | set(merged["expert_label"]))
    rows = []
    accuracy = float((merged["auto_label"] == merged["expert_label"]).mean())
    for category in labels:
        tp, fp, fn, tn = _classification_counts(merged["expert_label"], merged["auto_label"], category)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        rows.append(
            {
                "category": category,
                "support": int((merged["expert_label"] == category).sum()),
                "accuracy_overall": accuracy,
                "precision": precision,
                "recall": recall,
                "f1": f1,
                "true_positive": tp,
                "false_positive": fp,
                "false_negative": fn,
                "true_negative": tn,
            }
        )
    confusion = pd.crosstab(
        merged["expert_label"],
        merged["auto_label"],
        rownames=["expert_label"],
        colnames=["auto_label"],
        dropna=False,
    ).reset_index()
    return pd.DataFrame(rows), confusion


def _cohen_kappa(labels_a: pd.Series, labels_b: pd.Series) -> float:
    n = len(labels_a)
    if n == 0:
        return np.nan
    observed = float((labels_a == labels_b).mean())
    categories = sorted(set(labels_a) | set(labels_b))
    expected = 0.0
    for category in categories:
        expected += float((labels_a == category).mean()) * float((labels_b == category).mean())
    return (observed - expected) / (1 - expected) if expected < 1 else 1.0


def _fleiss_kappa(label_matrix: pd.DataFrame) -> float:
    """Calculate Fleiss' kappa for nominal labels in wide expert table."""
    if label_matrix.empty or label_matrix.shape[1] < 2:
        return np.nan
    labels = sorted(pd.unique(label_matrix.to_numpy().ravel()))
    n_raters = label_matrix.shape[1]
    counts = np.array([(label_matrix == label).sum(axis=1).to_numpy() for label in labels]).T
    p_i = ((counts * counts).sum(axis=1) - n_raters) / (n_raters * (n_raters - 1))
    p_bar = float(p_i.mean())
    p_j = counts.sum(axis=0) / (counts.sum() or 1)
    p_e = float((p_j * p_j).sum())
    return (p_bar - p_e) / (1 - p_e) if p_e < 1 else 1.0


def calculate_inter_annotator_agreement(expert_paths: list[str | Path]) -> pd.DataFrame:
    """Calculate overall and per-category agreement for two or more experts."""
    if len(expert_paths) < 2:
        return pd.DataFrame()
    labels = pd.concat([_read_expert_labels(path) for path in expert_paths], ignore_index=True)
    wide = labels.pivot_table(index="item_id", columns="expert", values="label", aggfunc="first").dropna()
    if wide.empty or wide.shape[1] < 2:
        return pd.DataFrame()

    rows = []
    experts = list(wide.columns)
    if len(experts) == 2:
        overall = _cohen_kappa(wide[experts[0]], wide[experts[1]])
        rows.append({"scope": "overall", "category": "ALL", "metric": "cohen_kappa", "value": overall, "n_items": len(wide)})
    else:
        overall = _fleiss_kappa(wide)
        rows.append({"scope": "overall", "category": "ALL", "metric": "fleiss_kappa", "value": overall, "n_items": len(wide)})

    categories = sorted(pd.unique(wide.to_numpy().ravel()))
    for category in categories:
        binary = wide.eq(category).replace({True: category, False: f"not_{category}"})
        if len(experts) == 2:
            value = _cohen_kappa(binary[experts[0]], binary[experts[1]])
            metric = "cohen_kappa_binary"
        else:
            value = _fleiss_kappa(binary)
            metric = "fleiss_kappa_binary"
        rows.append({"scope": "category", "category": category, "metric": metric, "value": value, "n_items": len(binary)})

    if len(experts) > 2:
        for expert_a, expert_b in combinations(experts, 2):
            value = _cohen_kappa(wide[expert_a], wide[expert_b])
            rows.append(
                {
                    "scope": "pairwise",
                    "category": "ALL",
                    "metric": "cohen_kappa",
                    "value": value,
                    "n_items": len(wide),
                    "expert_a": expert_a,
                    "expert_b": expert_b,
                }
            )
    return pd.DataFrame(rows)
