"""Graph metrics and community detection."""

from __future__ import annotations

from typing import Any

import networkx as nx
import pandas as pd


def detect_communities(G: nx.Graph) -> dict[str, int]:
    """Detect communities using Louvain if available, otherwise greedy modularity."""
    if len(G) == 0:
        return {}
    if G.number_of_edges() == 0:
        return {node: idx for idx, node in enumerate(G.nodes())}
    try:
        import community as community_louvain  # type: ignore

        partition = community_louvain.best_partition(G, weight="weight")
        return {str(node): int(comm) for node, comm in partition.items()}
    except Exception:
        from networkx.algorithms.community import greedy_modularity_communities

        communities = greedy_modularity_communities(G, weight="weight")
        partition: dict[str, int] = {}
        for idx, community_nodes in enumerate(communities):
            for node in community_nodes:
                partition[str(node)] = idx
        return partition


def apply_communities(G: nx.Graph, communities: dict[str, int]) -> nx.Graph:
    """Attach community IDs to graph nodes."""
    for node, community_id in communities.items():
        if node in G:
            G.nodes[node]["community"] = int(community_id)
    return G


def calculate_graph_metrics(G: nx.Graph) -> dict[str, Any]:
    """Calculate graph-level metrics."""
    n_nodes = G.number_of_nodes()
    n_edges = G.number_of_edges()
    degrees = dict(G.degree())
    weighted_degrees = dict(G.degree(weight="weight"))
    components = list(nx.connected_components(G)) if n_nodes else []
    metrics: dict[str, Any] = {
        "num_nodes": n_nodes,
        "num_edges": n_edges,
        "density": nx.density(G) if n_nodes > 1 else 0.0,
        "average_degree": sum(degrees.values()) / n_nodes if n_nodes else 0.0,
        "average_weighted_degree": sum(weighted_degrees.values()) / n_nodes if n_nodes else 0.0,
        "average_clustering": nx.average_clustering(G, weight="weight") if n_nodes and n_edges else 0.0,
        "num_connected_components": len(components),
        "largest_component_size": max((len(c) for c in components), default=0),
    }
    communities: dict[int, set[str]] = {}
    for node, data in G.nodes(data=True):
        community_id = int(data.get("community", -1))
        communities.setdefault(community_id, set()).add(node)
    try:
        from networkx.algorithms.community.quality import modularity

        valid_communities = [nodes for cid, nodes in communities.items() if cid >= 0 and nodes]
        metrics["modularity"] = modularity(G, valid_communities, weight="weight") if n_edges and valid_communities else None
    except Exception:
        metrics["modularity"] = None
    return metrics


def calculate_node_metrics(G: nx.Graph) -> pd.DataFrame:
    """Calculate node-level centrality metrics."""
    if len(G) == 0:
        return pd.DataFrame(
            columns=[
                "error_category",
                "degree",
                "weighted_degree",
                "degree_centrality",
                "betweenness_centrality",
                "closeness_centrality",
                "eigenvector_centrality",
                "pagerank",
                "community",
            ]
        )
    degree = dict(G.degree())
    weighted_degree = dict(G.degree(weight="weight"))
    degree_centrality = nx.degree_centrality(G)
    betweenness = nx.betweenness_centrality(G, weight="weight", normalized=True) if G.number_of_edges() else {n: 0.0 for n in G}
    closeness = nx.closeness_centrality(G) if G.number_of_edges() else {n: 0.0 for n in G}
    try:
        eigenvector = nx.eigenvector_centrality(G, weight="weight", max_iter=1000) if G.number_of_edges() else {n: 0.0 for n in G}
    except Exception:
        eigenvector = {n: 0.0 for n in G}
    pagerank = nx.pagerank(G, weight="weight") if G.number_of_edges() else {n: 1 / len(G) for n in G}
    rows = []
    for node in G.nodes():
        rows.append(
            {
                "error_category": node,
                "degree": degree.get(node, 0),
                "weighted_degree": weighted_degree.get(node, 0.0),
                "degree_centrality": degree_centrality.get(node, 0.0),
                "betweenness_centrality": betweenness.get(node, 0.0),
                "closeness_centrality": closeness.get(node, 0.0),
                "eigenvector_centrality": eigenvector.get(node, 0.0),
                "pagerank": pagerank.get(node, 0.0),
                "community": int(G.nodes[node].get("community", -1)),
            }
        )
    return pd.DataFrame(rows).sort_values("weighted_degree", ascending=False)


def calculate_edge_metrics(G: nx.Graph) -> pd.DataFrame:
    """Return edge-level metrics from graph attributes."""
    rows = []
    for source, target, data in G.edges(data=True):
        rows.append(
            {
                "source": source,
                "target": target,
                "weight": data.get("weight", 0.0),
                "cooccurrence_count": data.get("cooccurrence_count", 0),
                "jaccard": data.get("jaccard", 0.0),
                "phi_coefficient": data.get("phi_coefficient", 0.0),
                "p_value": data.get("p_value", 1.0),
                "corrected_p_value": data.get("corrected_p_value", 1.0),
                "edge_mode": data.get("edge_mode", ""),
                "network_unit": data.get("network_unit", ""),
                "edge_interpretation": data.get("edge_interpretation", ""),
            }
        )
    return pd.DataFrame(rows)


def merge_node_metrics(nodes_df: pd.DataFrame, node_metrics: pd.DataFrame) -> pd.DataFrame:
    """Merge centrality metrics into nodes.csv."""
    metric_cols = [c for c in node_metrics.columns if c != "error_category"]
    base = nodes_df.drop(columns=[c for c in metric_cols if c in nodes_df.columns], errors="ignore")
    result = base.merge(node_metrics, on="error_category", how="left")
    for col in metric_cols:
        if col not in result.columns:
            result[col] = 0.0
    result[metric_cols] = result[metric_cols].fillna(0)
    return result


def communities_dataframe(G: nx.Graph, errors_df: pd.DataFrame, node_metrics: pd.DataFrame) -> pd.DataFrame:
    """Summarize detected communities with simple pedagogical interpretations."""
    rows = []
    if len(G) == 0:
        return pd.DataFrame(columns=["community", "error_categories", "total_error_count", "central_node", "interpretation"])
    node_counts = errors_df.groupby("error_category").size().to_dict() if not errors_df.empty else {}
    for community_id in sorted({int(data.get("community", -1)) for _, data in G.nodes(data=True)}):
        nodes = [node for node, data in G.nodes(data=True) if int(data.get("community", -1)) == community_id]
        if not nodes:
            continue
        submetrics = node_metrics[node_metrics["error_category"].isin(nodes)].copy()
        central_node = (
            submetrics.sort_values("weighted_degree", ascending=False).iloc[0]["error_category"]
            if not submetrics.empty
            else nodes[0]
        )
        total = int(sum(node_counts.get(node, 0) for node in nodes))
        interpretation = interpret_community(nodes, central_node)
        rows.append(
            {
                "community": community_id,
                "error_categories": "; ".join(sorted(nodes)),
                "total_error_count": total,
                "central_node": central_node,
                "interpretation": interpretation,
            }
        )
    return pd.DataFrame(rows)


def interpret_community(nodes: list[str], central_node: str) -> str:
    """Generate a compact methodological interpretation for a community."""
    node_set = set(nodes)
    if {"Word_Order", "Sentence_Structure"} <= node_set:
        return "Кластер указывает на системные трудности построения английского предложения."
    if {"Prepositions", "Collocations_Fixed_Expressions"} <= node_set:
        return "Кластер может отражать трудности управления и устойчивой сочетаемости."
    if {"Reference", "Pronouns"} <= node_set:
        return "Кластер связан с межфразовой связностью и местоименной референцией."
    if "Verb_Tense_Aspect" in node_set and ({"Linking_Devices", "Discourse_Logic"} & node_set):
        return "Кластер может связывать грамматическое время с логикой и связностью повествования."
    return f"Кластер объединяет ошибки вокруг узла {central_node}; рекомендуется экспертная проверка общей причины."
