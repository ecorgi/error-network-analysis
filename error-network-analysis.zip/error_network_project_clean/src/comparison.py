"""Build and compare group-specific error networks."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import pandas as pd
import networkx as nx

from .cooccurrence import build_cooccurrence_table, test_error_associations
from .frequencies import calculate_error_frequencies
from .graph_builder import build_edges_table, build_error_graph, build_nodes_table, save_graph_outputs
from .io_utils import save_dataframe, write_json
from .metrics import (
    apply_communities,
    calculate_edge_metrics,
    calculate_graph_metrics,
    calculate_node_metrics,
    communities_dataframe,
    detect_communities,
    merge_node_metrics,
)
from .reporting import interpret_central_nodes
from .visualization import edge_weight_heatmap, visualize_communities_network, visualize_network


def _safe_name(value: str) -> str:
    """Return a filesystem-safe group folder name."""
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("_") or "missing"


def _group_label(group_cols: list[str], key: Any) -> tuple[str, dict[str, Any]]:
    """Make a group label and dict from a pandas group key."""
    if not isinstance(key, tuple):
        key = (key,)
    pieces = []
    values = {}
    for col, val in zip(group_cols, key):
        values[col] = val
        pieces.append(f"{col}_{_safe_name(val)}")
    return "__".join(pieces), values


def _write_group_interpretation(path: Path, label: str, metrics: dict[str, Any], nodes: pd.DataFrame, edges: pd.DataFrame, warnings: list[str]) -> None:
    """Write a short Markdown interpretation for a group-specific graph."""
    lines = [f"# Интерпретация группы `{label}`", ""]
    if warnings:
        lines.append("## Предупреждения")
        lines.extend(f"- {w}" for w in warnings)
        lines.append("")
    lines.append("## Сеть")
    lines.append(f"- узлы: {metrics.get('num_nodes', 0)}")
    lines.append(f"- рёбра: {metrics.get('num_edges', 0)}")
    lines.append(f"- плотность: {metrics.get('density', 0):.4f}")
    if not edges.empty and "edge_mode" in edges.columns:
        lines.append(f"- режим рёбер: {edges['edge_mode'].dropna().astype(str).iloc[0]}")
    if not edges.empty and "network_unit" in edges.columns:
        lines.append(f"- единица сети: {edges['network_unit'].dropna().astype(str).iloc[0]}")
    lines.append("")
    lines.append("## Автоматическая интерпретация")
    lines.extend(f"- {note}" for note in interpret_central_nodes(nodes, edges))
    path.write_text("\n".join(lines), encoding="utf-8")


def _unit_sequence(primary_unit: str, fallback_units: str) -> list[str]:
    units = [primary_unit]
    units.extend(unit.strip() for unit in (fallback_units or "").split(",") if unit.strip())
    result: list[str] = []
    for unit in units:
        if unit in {"sentence", "paragraph", "text"} and unit not in result:
            result.append(unit)
    return result


def _mark_edges(edges: pd.DataFrame, edge_mode: str, network_unit: str) -> pd.DataFrame:
    result = edges.copy()
    if result.empty:
        for col in ["edge_mode", "network_unit", "edge_interpretation"]:
            if col not in result.columns:
                result[col] = pd.Series(dtype="object")
        return result
    result["edge_mode"] = edge_mode
    result["network_unit"] = network_unit
    if edge_mode == "confirmatory":
        result["edge_interpretation"] = "Fisher/FDR-significant positive co-occurrence"
    else:
        result["edge_interpretation"] = "Exploratory positive co-occurrence for small group-specific network extraction"
    return result


def _build_group_edges(
    group_errors: pd.DataFrame,
    group_units: pd.DataFrame,
    unit: str,
    min_edge_weight: int,
    correction: str,
    p_threshold: float,
    disable_statistical_filter: bool,
    edge_mode: str,
    exploratory_min_edge_weight: int,
    exploratory_min_jaccard: float,
    network_fallback_units: str,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Build group edges with the same confirmatory/exploratory fallback as the main graph."""
    attempts: list[dict[str, Any]] = []

    def score_edges(edges: pd.DataFrame) -> tuple[float, int, float]:
        categories = sorted(group_errors["error_category"].dropna().astype(str).unique().tolist()) if not group_errors.empty else []
        if not categories:
            return (0.0, 0, 0.0)
        graph = nx.Graph()
        graph.add_nodes_from(categories)
        if not edges.empty:
            for _, row in edges.iterrows():
                graph.add_edge(row["source"], row["target"], weight=float(row.get("weight", 0.0) or 0.0))
        largest = max((len(component) for component in nx.connected_components(graph)), default=0)
        coverage = largest / len(categories) if categories else 0.0
        mean_weight = float(pd.to_numeric(edges.get("weight", pd.Series(dtype=float)), errors="coerce").fillna(0).mean()) if not edges.empty else 0.0
        return (coverage, int(len(edges)), mean_weight)

    def attempt(candidate_unit: str, mode: str, edge_weight: int, min_jaccard: float) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, tuple[float, int, float]]:
        cooc = build_cooccurrence_table(group_errors, group_units, unit=candidate_unit)
        assoc = test_error_associations(cooc, correction=correction, p_threshold=p_threshold)
        edges = build_edges_table(
            assoc,
            min_edge_weight=edge_weight,
            disable_statistical_filter=(mode == "exploratory") or disable_statistical_filter,
            min_jaccard_if_no_stats=min_jaccard,
        )
        edges = _mark_edges(edges, mode, candidate_unit)
        attempts.append(
            {
                "attempt_order": len(attempts) + 1,
                "network_unit": candidate_unit,
                "edge_mode": mode,
                "min_edge_weight": edge_weight,
                "min_jaccard": min_jaccard,
                "pairs_tested": int(len(assoc)),
                "edges_found": int(len(edges)),
                "largest_component_coverage": score_edges(edges)[0],
                "selected": False,
            }
        )
        return cooc, assoc, edges, score_edges(edges)

    selected_cooc = pd.DataFrame()
    selected_assoc = pd.DataFrame()
    selected_edges = pd.DataFrame()

    if edge_mode in {"auto", "confirmatory"} and not disable_statistical_filter:
        selected_cooc, selected_assoc, selected_edges, selected_score = attempt(unit, "confirmatory", min_edge_weight, 0.0)
        if not selected_edges.empty or edge_mode == "confirmatory":
            attempts[-1]["selected"] = True
            return selected_assoc, selected_edges, pd.DataFrame(attempts)

    if edge_mode in {"auto", "exploratory"} or disable_statistical_filter:
        exploratory_candidates: list[tuple[tuple[float, int, float], pd.DataFrame, pd.DataFrame, pd.DataFrame, int]] = []
        for candidate_unit in _unit_sequence(unit, network_fallback_units):
            selected_cooc, selected_assoc, selected_edges, selected_score = attempt(
                candidate_unit,
                "exploratory",
                exploratory_min_edge_weight,
                exploratory_min_jaccard,
            )
            exploratory_candidates.append((selected_score, selected_cooc, selected_assoc, selected_edges, len(attempts) - 1))
        if exploratory_candidates:
            exploratory_candidates.sort(key=lambda item: item[0], reverse=True)
            best_score, selected_cooc, selected_assoc, selected_edges, attempt_idx = exploratory_candidates[0]
            attempts[attempt_idx]["selected"] = True
            return selected_assoc, selected_edges, pd.DataFrame(attempts)

    if attempts:
        attempts[-1]["selected"] = True
    return selected_assoc, selected_edges, pd.DataFrame(attempts)


def compare_group_networks(
    errors_df: pd.DataFrame,
    units_df: pd.DataFrame,
    group_by: list[str],
    output_dir: str | Path,
    unit: str = "sentence",
    min_edge_weight: int = 2,
    correction: str = "fdr_bh",
    p_threshold: float = 0.05,
    disable_statistical_filter: bool = False,
    edge_mode: str = "auto",
    exploratory_min_edge_weight: int = 1,
    exploratory_min_jaccard: float = 0.05,
    network_fallback_units: str = "paragraph,text",
    save_figures: bool = True,
) -> dict[str, pd.DataFrame | dict[str, str]]:
    """Build separate networks by one grouping specification and compare them."""
    output_dir = Path(output_dir)
    group_root = output_dir / "groups"
    group_root.mkdir(parents=True, exist_ok=True)

    missing = [col for col in group_by if col not in units_df.columns]
    if missing:
        logging.warning("Cannot compare by %s: missing columns %s", group_by, missing)
        return {"summary": {"/".join(group_by): f"missing columns {missing}"}}

    node_rows = []
    rate_rows = []
    edge_rows = []
    metric_rows = []
    summary: dict[str, str] = {}

    grouped = units_df.groupby(group_by, dropna=False)
    for key, group_units in grouped:
        label, values = _group_label(group_by, key)
        group_path = group_root / label
        group_path.mkdir(parents=True, exist_ok=True)

        mask = pd.Series(True, index=errors_df.index)
        for col, val in values.items():
            if col in errors_df.columns:
                if pd.isna(val):
                    mask &= errors_df[col].isna()
                else:
                    mask &= errors_df[col] == val
        group_errors = errors_df.loc[mask].copy() if not errors_df.empty else errors_df.copy()
        warnings = []
        n_texts = group_units["text_id"].nunique() if "text_id" in group_units.columns else 0
        n_errors = len(group_errors)
        if n_texts < 5:
            warnings.append(f"В группе менее 5 текстов: {n_texts}.")
        if n_errors < 30:
            warnings.append(f"В группе менее 30 ошибок: {n_errors}.")

        frequencies = calculate_error_frequencies(group_errors, group_units)
        assoc, edges, construction_report = _build_group_edges(
            group_errors,
            group_units,
            unit=unit,
            min_edge_weight=min_edge_weight,
            correction=correction,
            p_threshold=p_threshold,
            disable_statistical_filter=disable_statistical_filter,
            edge_mode=edge_mode,
            exploratory_min_edge_weight=exploratory_min_edge_weight,
            exploratory_min_jaccard=exploratory_min_jaccard,
            network_fallback_units=network_fallback_units,
        )
        nodes = build_nodes_table(group_errors, frequencies["overall"])
        graph = build_error_graph(nodes, edges)
        communities = detect_communities(graph)
        apply_communities(graph, communities)
        node_metrics = calculate_node_metrics(graph)
        nodes = merge_node_metrics(nodes, node_metrics)
        graph = build_error_graph(nodes, edges)
        apply_communities(graph, communities)
        metrics = calculate_graph_metrics(graph)
        edge_metrics = calculate_edge_metrics(graph)
        communities_df = communities_dataframe(graph, group_errors, node_metrics)

        save_dataframe(nodes, group_path / "nodes.csv")
        save_dataframe(edges, group_path / "edges.csv")
        save_dataframe(assoc, group_path / "associations.csv")
        save_dataframe(construction_report, group_path / "network_construction_report.csv")
        save_dataframe(edge_metrics, group_path / "edge_metrics.csv")
        save_dataframe(communities_df, group_path / "communities.csv")
        write_json(metrics, group_path / "graph_metrics.json")
        save_graph_outputs(graph, group_path)
        if save_figures:
            visualize_network(graph, group_path / "error_network.png")
            visualize_communities_network(graph, group_path / "communities_network.png")
            edge_weight_heatmap(edges, group_path / "edge_weight_heatmap.png")
        _write_group_interpretation(group_path / "interpretation.md", label, metrics, nodes, edges, warnings)

        for col, val in values.items():
            nodes[col] = val
            edges[col] = val
            frequencies["overall"][col] = val
        nodes["group_label"] = label
        edges["group_label"] = label
        frequencies["overall"]["group_label"] = label
        node_rows.append(nodes)
        edge_rows.append(edges)
        rate_rows.append(frequencies["overall"])
        metric_rows.append({**values, "group_label": label, **metrics, "warnings": "; ".join(warnings)})
        selected = construction_report[construction_report["selected"].eq(True)].tail(1) if not construction_report.empty else pd.DataFrame()
        selected_unit = selected.iloc[0]["network_unit"] if not selected.empty else unit
        selected_mode = selected.iloc[0]["edge_mode"] if not selected.empty else edge_mode
        metric_rows[-1]["selected_network_unit"] = selected_unit
        metric_rows[-1]["selected_edge_mode"] = selected_mode
        summary[label] = f"{n_texts} texts, {n_errors} errors, {metrics.get('num_edges', 0)} edges, {selected_mode}/{selected_unit}"

    compare_node = pd.concat(node_rows, ignore_index=True) if node_rows else pd.DataFrame()
    compare_rates = pd.concat(rate_rows, ignore_index=True) if rate_rows else pd.DataFrame()
    compare_edges = pd.concat(edge_rows, ignore_index=True) if edge_rows else pd.DataFrame()
    compare_metrics = pd.DataFrame(metric_rows)

    return {
        "compare_node_centrality": compare_node,
        "compare_error_rates": compare_rates,
        "compare_edge_weights": compare_edges,
        "compare_graph_metrics": compare_metrics,
        "summary": summary,
    }
