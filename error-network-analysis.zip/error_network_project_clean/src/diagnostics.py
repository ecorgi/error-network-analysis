"""Annotation/corpus compatibility diagnostics."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pandas as pd


EXTERNAL_CORPUS_MARKERS = {
    "jfleg": "JFLEG",
    "jfleg_github": "JFLEG",
    "nucle": "NUCLE",
    "fce": "FCE",
    "bea": "BEA/FCE",
    "wi_locness": "W&I+LOCNESS",
    "locness": "LOCNESS",
}


def _as_str_set(series: pd.Series) -> set[str]:
    return set(series.dropna().astype(str))


def _first_values(series: pd.Series, n: int = 10) -> list[str]:
    return series.dropna().astype(str).drop_duplicates().head(n).tolist()


def detect_external_corpus(annotations_df: pd.DataFrame) -> str | None:
    """Infer whether annotations look like a known external GEC corpus."""
    haystacks: list[str] = []
    for col in ["source_corpus", "text_id", "student_id", "source_file", "annotation_source"]:
        if col in annotations_df.columns:
            haystacks.extend(annotations_df[col].dropna().astype(str).head(200).tolist())
    joined = " ".join(haystacks).lower()
    for marker, label in EXTERNAL_CORPUS_MARKERS.items():
        if marker in joined:
            return label
    return None


def validate_annotation_compatibility(corpus_df: pd.DataFrame, annotations_df: pd.DataFrame) -> dict[str, Any]:
    """Return and log detailed diagnostics for corpus/annotation compatibility."""
    corpus_ids = _as_str_set(corpus_df["text_id"]) if "text_id" in corpus_df.columns else set()
    ann_ids = _as_str_set(annotations_df["text_id"]) if "text_id" in annotations_df.columns else set()
    corpus_students = _as_str_set(corpus_df["student_id"]) if "student_id" in corpus_df.columns else set()
    ann_students = _as_str_set(annotations_df["student_id"]) if "student_id" in annotations_df.columns else set()
    matched_ids = corpus_ids & ann_ids
    missing_in_corpus = sorted(ann_ids - corpus_ids)
    corpus_without_annotations = sorted(corpus_ids - ann_ids)
    corpus_coverage_ratio = len(matched_ids) / len(corpus_ids) if corpus_ids else 0.0
    annotation_valid_ratio = len(matched_ids) / len(ann_ids) if ann_ids else 1.0

    if {"student_id", "time_slice"}.issubset(corpus_df.columns):
        student_time = (
            corpus_df.assign(_present=1)
            .pivot_table(index="student_id", columns="time_slice", values="_present", aggfunc="sum", fill_value=0)
            .reset_index()
        )
    else:
        student_time = pd.DataFrame()

    report = {
        "num_corpus_rows": int(len(corpus_df)),
        "num_corpus_text_ids": int(len(corpus_ids)),
        "num_corpus_student_ids": int(len(corpus_students)),
        "num_time_slices": int(corpus_df["time_slice"].nunique(dropna=True)) if "time_slice" in corpus_df.columns else 0,
        "student_time_distribution": student_time,
        "num_annotation_rows": int(len(annotations_df)),
        "num_annotation_text_ids": int(len(ann_ids)),
        "matched_text_id_count": int(len(matched_ids)),
        "matched_text_id_ratio": float(corpus_coverage_ratio),
        "corpus_text_id_coverage_ratio": float(corpus_coverage_ratio),
        "annotation_text_id_valid_ratio": float(annotation_valid_ratio),
        "annotation_text_ids_not_in_corpus_count": int(len(missing_in_corpus)),
        "corpus_text_ids_without_annotations_count": int(len(corpus_without_annotations)),
        "matched_student_id_count": int(len(corpus_students & ann_students)),
        "first_10_corpus_text_ids": _first_values(corpus_df["text_id"]) if "text_id" in corpus_df.columns else [],
        "first_10_annotation_text_ids": _first_values(annotations_df["text_id"]) if "text_id" in annotations_df.columns else [],
        "annotation_text_ids_not_in_corpus": missing_in_corpus[:100],
        "corpus_text_ids_without_annotations": corpus_without_annotations[:100],
        "external_corpus_guess": detect_external_corpus(annotations_df),
    }

    logging.info(
        "Annotation compatibility: %s/%s annotation text_id values belong to the corpus; %s/%s corpus texts have at least one annotation row.",
        report["matched_text_id_count"],
        report["num_annotation_text_ids"],
        report["matched_text_id_count"],
        report["num_corpus_text_ids"],
    )
    if corpus_without_annotations:
        logging.warning(
            "%s corpus text_id values have no annotation rows; they will be treated as zero detected errors.",
            len(corpus_without_annotations),
        )
    if report["external_corpus_guess"]:
        logging.warning("Annotations look like external corpus: %s.", report["external_corpus_guess"])
    return report


def compatibility_report_dataframe(report: dict[str, Any]) -> pd.DataFrame:
    """Flatten diagnostics to a CSV-friendly key/value table."""
    rows = []
    for key, value in report.items():
        if isinstance(value, pd.DataFrame):
            rows.append({"metric": key, "value": value.to_json(force_ascii=False, orient="records")})
        elif isinstance(value, list):
            rows.append({"metric": key, "value": "; ".join(map(str, value))})
        else:
            rows.append({"metric": key, "value": value})
    return pd.DataFrame(rows)


def write_diagnostic_report(report: dict[str, Any], output_path: str | Path) -> None:
    """Write a Russian diagnostic Markdown report for incompatible annotations."""
    output_path = Path(output_path)
    matched = report.get("matched_text_id_count", 0)
    total = report.get("num_corpus_text_ids", 0)
    corpus_guess = report.get("external_corpus_guess") or "другого внешнего корпуса"
    lines = [
        "# Диагностический отчёт",
        "",
        "Анализ остановлен, потому что файл annotations.csv не соответствует input corpus.",
        "",
        "## Причина",
        f"{matched} из {total} text_id совпали.",
        f"Аннотации похожи на разметку корпуса {corpus_guess}.",
        "",
        "## Что делать",
        "1. Использовать annotations.csv, созданный именно для data.csv.",
        "2. Запустить автоматическую разметку текущего корпуса.",
        "3. Не использовать JFLEG annotations для пользовательского корпуса.",
        "",
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines), encoding="utf-8")


def format_incompatibility_error(report: dict[str, Any]) -> str:
    """Build a concise fail-fast error message."""
    matched = int(report.get("matched_text_id_count", 0))
    total = int(report.get("num_corpus_text_ids", 0))
    guessed = report.get("external_corpus_guess")
    suffix = f", e.g. {guessed}" if guessed else ""
    return (
        "annotations.csv is incompatible with input corpus.\n"
        f"{matched} of {total} corpus text_id values match annotations.csv.\n"
        f"The annotations appear to come from another corpus{suffix}.\n"
        "Use annotations generated for this exact input corpus or run without --annotations."
    )
