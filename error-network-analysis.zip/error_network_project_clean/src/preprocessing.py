"""Text normalization, sentence segmentation and token statistics."""

from __future__ import annotations

import logging
import re
import unicodedata
from functools import lru_cache
from typing import Any

import pandas as pd


def normalize_text(text: str) -> str:
    """Normalize whitespace and remove control characters without lowercasing."""
    text = "".join(ch for ch in str(text) if unicodedata.category(ch)[0] != "C" or ch in "\n\t")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


@lru_cache(maxsize=8)
def get_spacy_pipeline(language: str, model_name: str | None = None):
    """Load spaCy pipeline; fall back to a blank pipeline with sentencizer."""
    try:
        import spacy
    except ImportError as exc:
        raise ImportError("spaCy is required. Install it with: pip install spacy") from exc

    candidate_models = [model_name] if model_name else []
    if language == "en":
        candidate_models.extend(["en_core_web_lg", "en_core_web_sm"])
    else:
        candidate_models.append(language)
    nlp = None
    last_error: Exception | None = None
    for candidate in [m for m in candidate_models if m]:
        try:
            nlp = spacy.load(candidate, disable=["ner"])
            logging.info("Loaded spaCy model: %s", candidate)
            break
        except Exception as exc:
            last_error = exc
            logging.debug("Could not load spaCy model %r: %s", candidate, exc)
    if nlp is None:
        logging.warning(
            "Could not load spaCy models %s; using spacy.blank(%r) with sentencizer. Last error: %s",
            candidate_models,
            language,
            last_error,
        )
        nlp = spacy.blank(language if len(language) == 2 else "en")
    if "sentencizer" not in nlp.pipe_names and "parser" not in nlp.pipe_names:
        nlp.add_pipe("sentencizer")
    return nlp


def _paragraphs_with_offsets(text: str) -> list[tuple[int, str, int]]:
    """Return (paragraph_index, paragraph_text, start_offset) triples."""
    paragraphs: list[tuple[int, str, int]] = []
    cursor = 0
    for p_idx, part in enumerate(re.split(r"\n\s*\n", text)):
        if not part.strip():
            cursor += len(part)
            continue
        start = text.find(part, cursor)
        paragraphs.append((p_idx, part.strip(), max(start, 0)))
        cursor = max(start, cursor) + len(part)
    if not paragraphs and text.strip():
        paragraphs.append((0, text.strip(), 0))
    return paragraphs


def preprocess_texts(df: pd.DataFrame, language: str = "en", spacy_model: str | None = None) -> pd.DataFrame:
    """Preprocess texts and return one row per sentence with token statistics."""
    nlp = get_spacy_pipeline(language, spacy_model)
    rows: list[dict[str, Any]] = []
    for _, record in df.iterrows():
        original = str(record["text"])
        clean = normalize_text(original)
        text_char_count = len(clean)
        text_doc = nlp(clean)
        text_tokens = [tok for tok in text_doc if not tok.is_space and not tok.is_punct]
        word_count_text = len(text_tokens)
        word_lengths = [len(tok.text) for tok in text_tokens]
        sentence_count_text = 0

        for paragraph_index, paragraph, paragraph_start in _paragraphs_with_offsets(clean):
            doc = nlp(paragraph)
            sentences = list(doc.sents) or [doc[:]]
            for sent_index_local, sent in enumerate(sentences):
                sentence_text = sent.text.strip()
                if not sentence_text:
                    continue
                global_start = paragraph_start + sent.start_char
                sentence_id = f"{record['text_id']}::s{sentence_count_text:04d}"
                paragraph_id = f"{record['text_id']}::p{paragraph_index:04d}"
                tokens = [tok for tok in sent if not tok.is_space and not tok.is_punct]
                token_count = len(tokens)
                nouns = [tok for tok in tokens if tok.pos_ in {"NOUN", "PROPN", "PRON"}]
                verbs = [tok for tok in tokens if tok.pos_ in {"VERB", "AUX"}]
                sentence_count_text += 1
                base = {
                    "text_id": record["text_id"],
                    "student_id": record["student_id"],
                    "time_slice": record["time_slice"],
                    "lang_level": record["lang_level"],
                    "topic": record["topic"],
                    "sentence_id": sentence_id,
                    "paragraph_id": paragraph_id,
                    "sentence_index": sentence_count_text - 1,
                    "paragraph_index": paragraph_index,
                    "sentence_text": sentence_text,
                    "sentence_start_char": global_start,
                    "sentence_end_char": global_start + len(sentence_text),
                    "token_count": token_count,
                    "noun_count": len(nouns),
                    "verb_count": len(verbs),
                    "finite_verb_count": sum(1 for tok in verbs if "Fin" in tok.morph.get("VerbForm")),
                    "pos_sequence": " ".join(tok.pos_ for tok in tokens),
                    "dep_sequence": " ".join(tok.dep_ for tok in tokens),
                    "char_count": len(sentence_text),
                    "original_text": original,
                    "clean_text": clean,
                    "text_char_count": text_char_count,
                    "text_word_count": word_count_text,
                    "avg_word_length_text": (sum(word_lengths) / len(word_lengths)) if word_lengths else 0.0,
                }
                if "native_lang" in record.index:
                    base["native_lang"] = record.get("native_lang")
                rows.append(base)

        # If spaCy failed to identify any sentence, keep one text-level row.
        if sentence_count_text == 0:
            base = {
                "text_id": record["text_id"],
                "student_id": record["student_id"],
                "time_slice": record["time_slice"],
                "lang_level": record["lang_level"],
                "topic": record["topic"],
                "sentence_id": f"{record['text_id']}::s0000",
                "paragraph_id": f"{record['text_id']}::p0000",
                "sentence_index": 0,
                "paragraph_index": 0,
                "sentence_text": clean,
                "sentence_start_char": 0,
                "sentence_end_char": len(clean),
                "token_count": word_count_text,
                "noun_count": 0,
                "verb_count": 0,
                "finite_verb_count": 0,
                "pos_sequence": "",
                "dep_sequence": "",
                "char_count": len(clean),
                "original_text": original,
                "clean_text": clean,
                "text_char_count": text_char_count,
                "text_word_count": word_count_text,
                "avg_word_length_text": (sum(word_lengths) / len(word_lengths)) if word_lengths else 0.0,
            }
            if "native_lang" in record.index:
                base["native_lang"] = record.get("native_lang")
            rows.append(base)

    result = pd.DataFrame(rows)
    if result.empty:
        return pd.DataFrame(
            columns=[
                "text_id",
                "student_id",
                "time_slice",
                "lang_level",
                "native_lang",
                "topic",
                "sentence_id",
                "paragraph_id",
                "sentence_text",
                "token_count",
                "char_count",
            ]
        )

    sentence_counts = result.groupby("text_id")["sentence_id"].transform("nunique")
    token_sums = result.groupby("text_id")["token_count"].transform("sum")
    result["sentence_count_text"] = sentence_counts
    result["avg_sentence_length_text"] = token_sums / sentence_counts.replace(0, 1)
    return result
