"""Markdown reporting and automatic methodological interpretation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd

from .taxonomy import error_category_ru


def _as_list(series: pd.Series) -> str:
    values = [str(v) for v in series.dropna().unique().tolist() if str(v).strip()]
    return ", ".join(values) if values else "нет данных"


def _top_table(df: pd.DataFrame, value_col: str, n: int = 10) -> str:
    if df.empty or value_col not in df.columns:
        return "Нет данных."
    working = df.copy()
    if "error_count" in working.columns:
        working = working[working["error_count"].astype(float) > 0]
    if working.empty:
        return "Ненулевых значений нет."
    if "error_category_ru" not in working.columns and "error_category" in working.columns:
        working["error_category_ru"] = working["error_category"].map(error_category_ru)
    cols = []
    for c in ["error_category_ru", "error_count", value_col]:
        if c in working.columns and c not in cols:
            cols.append(c)
    return working.sort_values(value_col, ascending=False).head(n)[cols].to_markdown(index=False)


def interpret_central_nodes(nodes_df: pd.DataFrame, edges_df: pd.DataFrame) -> list[str]:
    notes: list[str] = []
    if nodes_df.empty:
        return ["Сетевые метрики недоступны, потому что узлы не были построены."]
    central = nodes_df.sort_values(["weighted_degree", "error_rate_per_1000"], ascending=False).head(5)
    central_categories = set(central["error_category"].tolist())
    if "Articles_Determiners" in central_categories:
        notes.append("Артикли и определители остаются важной зоной риска, если сочетают высокую частотность и центральность.")
    edge_pairs = {frozenset((row["source"], row["target"])) for _, row in edges_df.iterrows()} if not edges_df.empty else set()
    if frozenset(("Word_Order", "Sentence_Structure")) in edge_pairs:
        notes.append("Связь порядка слов и структуры предложения указывает на системную трудность построения английского предложения.")
    if frozenset(("Prepositions", "Collocations_Fixed_Expressions")) in edge_pairs:
        notes.append("Связь предлогов и коллокаций говорит о проблеме управления и устойчивой сочетаемости.")
    if frozenset(("Reference", "Pronouns")) in edge_pairs:
        notes.append("Связь референции и местоимений требует работы с межфразовой связностью.")
    if not notes:
        notes.append("Для интерпретации центральных узлов нужно сопоставить частотность, weighted degree и реальные примеры ошибок.")
    return notes


def _longitudinal_summary(wide_df: pd.DataFrame) -> list[str]:
    if wide_df.empty:
        return ["Продольные данные недоступны или ошибок не найдено."]
    lines: list[str] = []
    by_student = wide_df.groupby("student_id")["T3_minus_T1"].mean().sort_values()
    improved = by_student[by_student < 0].index.tolist()
    worsened = by_student[by_student > 0].index.tolist()
    stable = by_student[by_student == 0].index.tolist()
    lines.append("- улучшились: " + (", ".join(improved) if improved else "нет явного снижения ошибок;"))
    lines.append("- ухудшились: " + (", ".join(worsened) if worsened else "нет явного роста ошибок;"))
    if stable:
        lines.append("- стабильная динамика: " + ", ".join(stable) + ";")
    by_category = wide_df.groupby("error_category")["T3_minus_T1"].mean().sort_values()
    decreased = [error_category_ru(cat) for cat in by_category[by_category < 0].index.tolist()]
    persistent = [error_category_ru(cat) for cat in by_category[by_category.abs() < 1e-9].index.tolist()]
    mixed = wide_df[wide_df["trend_label"].eq("mixed")]["student_id"].drop_duplicates().tolist()
    lines.append("- категории, снизившиеся от T1 к T3: " + (", ".join(decreased) if decreased else "нет;"))
    lines.append("- категории, сохраняющиеся без изменения: " + (", ".join(persistent) if persistent else "нет;"))
    lines.append("- нестабильная динамика обнаружена у: " + (", ".join(mixed) if mixed else "нет;"))
    lines.append("- ограничение: выборка мала, поэтому индивидуальные траектории нужно проверять по текстам и экспертной разметке.")
    return lines


def generate_report(results: dict[str, Any], output_path: str | Path) -> None:
    """Generate the main Russian Markdown report."""
    output_path = Path(output_path)
    corpus = results.get("corpus_df", pd.DataFrame())
    units = results.get("units_df", pd.DataFrame())
    errors = results.get("errors_df", pd.DataFrame())
    frequencies = results.get("frequencies", {})
    nodes = results.get("nodes_df", pd.DataFrame())
    edges = results.get("edges_df", pd.DataFrame())
    communities = results.get("communities_df", pd.DataFrame())
    graph_metrics = results.get("graph_metrics", {})
    compare_summary = results.get("compare_summary", {})
    longitudinal_wide = results.get("longitudinal_wide", pd.DataFrame())
    compatibility = results.get("annotation_compatibility", {})
    unit = results.get("unit", "sentence")
    p_threshold = results.get("p_threshold", 0.05)
    correction = results.get("correction", "fdr_bh")
    network_info = results.get("network_info", {})
    selected_network_unit = network_info.get("network_unit", unit) if isinstance(network_info, dict) else unit
    selected_edge_mode = network_info.get("edge_mode", "confirmatory") if isinstance(network_info, dict) else "confirmatory"

    total_words = int(units["token_count"].sum()) if "token_count" in units.columns else 0
    total_sentences = int(units["sentence_id"].nunique()) if "sentence_id" in units.columns else 0
    mean_words = round(corpus["text"].astype(str).str.split().map(len).mean(), 1) if "text" in corpus.columns and not corpus.empty else 0

    lines: list[str] = []
    lines.append("# Отчёт о сетевом анализе речевых ошибок\n")

    lines.append("## 1. Проверка совместимости данных")
    lines.append(f"- input corpus: `{results.get('input_path', 'не указан')}`;")
    lines.append(f"- annotations.csv: `{results.get('annotations_path', 'не использовался')}`;")
    if compatibility:
        lines.append(f"- совпавшие text_id: {compatibility.get('matched_text_id_count', 0)} из {compatibility.get('num_corpus_text_ids', 0)};")
        lines.append("- несовместимость: не обнаружена;")
        lines.append("- отброшенные аннотации: нет;")
    else:
        lines.append("- внешняя разметка не использовалась; проверка совместимости не требовалась;")
    lines.append("- доверие к результатам: зависит от качества разметки; автоматическая разметка требует экспертной проверки.\n")

    lines.append("## 2. Описание корпуса")
    lines.append(f"- количество текстов: {corpus['text_id'].nunique() if 'text_id' in corpus.columns else 0};")
    lines.append(f"- количество студентов: {corpus['student_id'].nunique() if 'student_id' in corpus.columns else 0};")
    if "time_slice" in corpus.columns:
        distribution = corpus["time_slice"].value_counts().sort_index()
        distribution_text = "; ".join(f"{idx}: {value}" for idx, value in distribution.items())
        lines.append("- распределение по T1/T2/T3: " + distribution_text + ";")
    lines.append(f"- уровни владения: {_as_list(corpus['lang_level']) if 'lang_level' in corpus.columns else 'нет данных'};")
    lines.append(f"- темы: {_as_list(corpus['topic']) if 'topic' in corpus.columns else 'нет данных'};")
    lines.append(f"- средний объём текста: {mean_words} слов;")
    lines.append(f"- общее число слов: {total_words};")
    lines.append(f"- общее число предложений: {total_sentences}.\n")

    lines.append("## 3. Методика")
    lines.append(
        "Узел сети соответствует категории ошибки. Ребро соответствует совместной встречаемости двух категорий в одной единице анализа. "
        f"Запрошенная единица анализа: `{unit}`; фактически выбранная единица для итогового графа: `{selected_network_unit}`. "
        f"Режим построения рёбер: `{selected_edge_mode}`. Частоты считаются как `error_count / word_count * 1000`. "
        f"Связи проверяются точным критерием Фишера; коррекция множественных сравнений: `{correction}`, порог: `{p_threshold}`. "
        "Динамика T1-T3 рассчитывается внутри каждого `student_id` по нормированным частотам. "
        "Автоматическая разметка является полуавтоматической и требует экспертной проверки. "
        "Сетевые связи показывают статистическую совместную встречаемость ошибок, но не доказывают причинность.\n"
    )
    if selected_edge_mode == "exploratory":
        lines.append(
            "Итоговая сеть является исследовательской: строгий Fisher/FDR-граф для малой выборки не дал связей, поэтому использована положительная совместная встречаемость. "
            "Такой граф пригоден для извлечения гипотез и визуального анализа, но не должен интерпретироваться как подтверждённая причинная структура.\n"
        )

    lines.append("## 4. Частотный анализ ошибок")
    overall = frequencies.get("overall", pd.DataFrame())
    lines.append("**Топ ошибок по абсолютной частоте:**\n")
    lines.append(_top_table(overall, "error_count"))
    lines.append("\n**Топ ошибок на 1000 слов:**\n")
    lines.append(_top_table(overall, "error_rate_per_1000"))
    lines.append("")

    lines.append("## 5. Динамика ошибок T1–T3 по студентам")
    lines.extend(_longitudinal_summary(longitudinal_wide))
    lines.append("")

    lines.append("## 6. Сетевая структура ошибок")
    lines.append(f"- число узлов: {graph_metrics.get('num_nodes', 0)};")
    lines.append(f"- число рёбер: {graph_metrics.get('num_edges', 0)};")
    lines.append(f"- плотность сети: {graph_metrics.get('density', 0):.4f};")
    lines.append(f"- средняя степень: {graph_metrics.get('average_degree', 0):.4f};")
    lines.append(f"- средняя взвешенная степень: {graph_metrics.get('average_weighted_degree', 0):.4f}.")
    lines.append(f"- единица сети: `{selected_network_unit}`;")
    lines.append(f"- режим рёбер: `{selected_edge_mode}`.")
    if edges.empty:
        lines.append("Значимые рёбра не обнаружены: сеть не построена из-за недостатка данных или строгих порогов.")
    else:
        show_edges = edges.copy()
        for col in ["source", "target"]:
            show_edges[f"{col}_ru"] = show_edges[col].map(error_category_ru)
        table_cols = [c for c in ["source_ru", "target_ru", "cooccurrence_count", "weight", "corrected_p_value", "edge_mode", "network_unit"] if c in show_edges.columns]
        lines.append(show_edges.sort_values("weight", ascending=False).head(10)[table_cols].to_markdown(index=False))
    lines.append("")

    lines.append("## 7. Кластеры ошибок")
    if communities.empty:
        lines.append("Кластеры не выделены: сеть пуста или не содержит рёбер.\n")
    else:
        lines.append(communities.to_markdown(index=False))
        lines.append("")

    lines.append("## 8. Зоны риска")
    for note in interpret_central_nodes(nodes, edges):
        lines.append(f"- {note}")
    if not errors.empty and "annotation_source" in errors.columns:
        sources = ", ".join(sorted(errors["annotation_source"].dropna().astype(str).unique()))
        lines.append(f"- источник разметки: {sources}.")
    lines.append("")

    lines.append("## 9. Методические рекомендации")
    lines.append("1. Начинать с категорий, где одновременно высоки частотность и центральность.")
    lines.append("2. Категории из одного кластера разбирать совместно, но подтверждать примерами из текстов.")
    lines.append("3. Для T1-T3 использовать индивидуальную обратную связь по студенту, а не только средние значения.")
    lines.append("4. Автоматические категории ошибок интерпретировать как аналитические приближения, а не окончательную экспертную классификацию.\n")

    lines.append("## 10. Ограничения")
    lines.append("- Автоматическая разметка не равна экспертной и требует проверки.")
    lines.append("- Малые подвыборки могут давать нестабильные графы и пустые статистически значимые сети.")
    lines.append("- Сетевые связи не доказывают причинность.")
    lines.append("- Если LanguageTool недоступен, эвристическая fallback-разметка особенно нуждается в ручной проверке.")
    if compare_summary:
        lines.append("\nДополнительные сравнения групп сохранены в `compare_*.csv`.")
    lines.append("")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines), encoding="utf-8")
