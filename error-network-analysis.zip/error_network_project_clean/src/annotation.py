"""Automatic and expert annotation handling."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

import pandas as pd

from .diagnostics import format_incompatibility_error, validate_annotation_compatibility
from .preprocessing import get_spacy_pipeline
from .taxonomy import map_languagetool_rule_to_error_category, validate_error_category

ERROR_COLUMNS = [
    "error_id",
    "text_id",
    "student_id",
    "time_slice",
    "lang_level",
    "native_lang",
    "topic",
    "unit_id",
    "sentence_id",
    "paragraph_id",
    "start_char",
    "end_char",
    "error_span",
    "suggested_correction",
    "macro_category",
    "error_category",
    "tool_rule_id",
    "tool_message",
    "confidence",
    "interference_flag",
    "interference_type",
    "interference_confidence",
    "annotation_source",
    "source_corpus",
    "source_rule_or_alignment",
    "classification_confidence",
]

RU_INTERFERENCE_MAP = {
    "Articles_Determiners": ("L1_article_absence_transfer", 0.65),
    "Word_Order": ("L1_word_order_transfer", 0.60),
    "Prepositions": ("L1_preposition_transfer", 0.62),
    "Verb_Tense_Aspect": ("L1_tense_aspect_transfer", 0.60),
    "Reference": ("L1_reference_transfer", 0.58),
    "Pronouns": ("L1_reference_transfer", 0.58),
    "Noun_Number_Countability": ("L1_countability_transfer", 0.58),
}


def empty_errors_df() -> pd.DataFrame:
    """Return an empty errors DataFrame with the canonical schema."""
    return pd.DataFrame(columns=ERROR_COLUMNS)


def _language_tool_code(language: str) -> str:
    """Map a short language code to LanguageTool's expected code."""
    if language == "en":
        return "en-US"
    return language


def annotate_errors(
    df_sentences: pd.DataFrame,
    language: str = "en",
    strategy: str = "combined",
    spacy_model: str | None = None,
) -> pd.DataFrame:
    """Annotate errors with LanguageTool and map them to the project taxonomy.

    The output is semi-automatic and should be checked by experts. With the
    default ``combined`` strategy, LanguageTool detections are enriched with a
    conservative heuristic pass over the same input corpus. This improves graph
    connectivity for small corpora without importing external data.
    """
    strategy = (strategy or "combined").lower()
    if strategy not in {"languagetool", "heuristic", "combined"}:
        raise ValueError("annotation strategy must be one of: languagetool, heuristic, combined")
    if strategy == "heuristic":
        return annotate_errors_heuristic(df_sentences, language=language, spacy_model=spacy_model)

    lt_errors = _annotate_errors_languagetool(df_sentences, language=language)
    if strategy == "languagetool":
        return lt_errors
    heuristic_errors = annotate_errors_heuristic(df_sentences, language=language, spacy_model=spacy_model)
    return combine_annotation_sources([lt_errors, heuristic_errors])


def _annotate_errors_languagetool(df_sentences: pd.DataFrame, language: str = "en") -> pd.DataFrame:
    """Annotate errors with LanguageTool only."""
    try:
        import language_tool_python
    except ImportError:
        logging.warning(
            "language_tool_python is not installed; using a small automatic heuristic annotator. "
            "Install language-tool-python or provide compatible --annotations for stronger analysis."
        )
        return annotate_errors_heuristic(df_sentences, language=language)

    if df_sentences.empty:
        return empty_errors_df()

    try:
        tool = language_tool_python.LanguageTool(_language_tool_code(language))
    except Exception as exc:
        logging.warning(
            "LanguageTool is unavailable (%s); using a small automatic heuristic annotator. "
            "Install/check LanguageTool or provide compatible --annotations for stronger analysis.",
            exc,
        )
        return annotate_errors_heuristic(df_sentences, language=language)
    rows: list[dict[str, Any]] = []
    error_counter = 0
    try:
        grouped = df_sentences.groupby("text_id", dropna=False) if "text_id" in df_sentences.columns else [(None, df_sentences)]
        for _, text_units in grouped:
            text_units = text_units.sort_values("sentence_start_char").copy()
            text = str(text_units.iloc[0].get("clean_text", "")) if "clean_text" in text_units.columns else ""
            if not text.strip():
                text = " ".join(text_units.get("sentence_text", pd.Series(dtype=str)).dropna().astype(str).tolist())
            if not text.strip():
                continue
            matches = tool.check(text)
            for match in matches:
                start_global = int(getattr(match, "offset", 0) or 0)
                length = int(getattr(match, "errorLength", 0) or 0)
                end_global = start_global + length
                sentence_mask = (
                    (pd.to_numeric(text_units["sentence_start_char"], errors="coerce") <= start_global)
                    & (pd.to_numeric(text_units["sentence_end_char"], errors="coerce") >= start_global)
                    if {"sentence_start_char", "sentence_end_char"}.issubset(text_units.columns)
                    else pd.Series(False, index=text_units.index)
                )
                sent = text_units.loc[sentence_mask].iloc[0] if sentence_mask.any() else text_units.iloc[0]
                replacements = getattr(match, "replacements", []) or []
                rule_id = str(getattr(match, "ruleId", "") or "")
                message = str(getattr(match, "message", "") or "")
                category = str(getattr(match, "category", "") or getattr(match, "ruleIssueType", "") or "")
                mapping = map_languagetool_rule_to_error_category(rule_id, message, category, text[max(0, start_global - 30): end_global + 30])
                error_counter += 1
                rows.append(
                    {
                        "error_id": f"E{error_counter:07d}",
                        "text_id": sent.get("text_id"),
                        "student_id": sent.get("student_id"),
                        "time_slice": sent.get("time_slice"),
                        "lang_level": sent.get("lang_level"),
                        "native_lang": sent.get("native_lang") if "native_lang" in sent.index else pd.NA,
                        "topic": sent.get("topic"),
                        "unit_id": sent.get("sentence_id"),
                        "sentence_id": sent.get("sentence_id"),
                        "paragraph_id": sent.get("paragraph_id"),
                        "start_char": start_global,
                        "end_char": end_global,
                        "error_span": text[start_global:end_global],
                        "suggested_correction": replacements[0] if replacements else "",
                        "macro_category": mapping["macro_category"],
                        "error_category": mapping["error_category"],
                        "tool_rule_id": rule_id,
                        "tool_message": message,
                        "confidence": mapping["confidence"],
                        "interference_flag": None,
                        "interference_type": "not_evaluated",
                        "interference_confidence": None,
                        "annotation_source": "LanguageTool_semi_automatic",
                        "source_corpus": "input_corpus",
                        "source_rule_or_alignment": rule_id,
                        "classification_confidence": mapping["confidence"],
                    }
                )
    finally:
        try:
            tool.close()
        except Exception:
            logging.debug("Could not close LanguageTool process cleanly.")
    return pd.DataFrame(rows, columns=ERROR_COLUMNS) if rows else empty_errors_df()


def combine_annotation_sources(frames: list[pd.DataFrame]) -> pd.DataFrame:
    """Combine automatic annotation sources and remove exact duplicate spans."""
    working = [frame.copy() for frame in frames if frame is not None and not frame.empty]
    if not working:
        return empty_errors_df()
    combined = pd.concat(working, ignore_index=True)
    for col in ERROR_COLUMNS:
        if col not in combined.columns:
            combined[col] = pd.NA
    dedupe_cols = ["text_id", "sentence_id", "start_char", "end_char", "error_category"]
    combined = combined.sort_values(["confidence", "classification_confidence"], ascending=False, na_position="last")
    combined = combined.drop_duplicates(subset=[c for c in dedupe_cols if c in combined.columns], keep="first").reset_index(drop=True)
    combined["error_id"] = [f"AUTO{i:07d}" for i in range(1, len(combined) + 1)]
    return combined[ERROR_COLUMNS]


def annotate_errors_heuristic(
    df_sentences: pd.DataFrame,
    language: str = "en",
    spacy_model: str | None = None,
) -> pd.DataFrame:
    """Create conservative automatic annotations for the current input corpus.

    This fallback is intentionally simple and marked as heuristic. It exists so
    the project can run without external corpora or a local LanguageTool service.
    """
    if df_sentences.empty:
        return empty_errors_df()

    patterns: list[tuple[re.Pattern[str], str, str, str, float]] = [
        (re.compile(r"\ba ([aeiouAEIOU]\w*)"), "Grammar", "Articles_Determiners", "HEUR_A_BEFORE_VOWEL", 0.58),
        (re.compile(r"\ban ([^aeiouAEIOU\s]\w*)"), "Grammar", "Articles_Determiners", "HEUR_AN_BEFORE_CONSONANT", 0.58),
        (re.compile(r"\b(I|we|you|they)\s+(has|is has)\b", re.I), "Grammar", "Subject_Verb_Agreement", "HEUR_SVA_HAVE", 0.55),
        (re.compile(r"\b(he|she|it)\s+have\b", re.I), "Grammar", "Subject_Verb_Agreement", "HEUR_SVA_HAS", 0.55),
        (re.compile(r"\b(a|an)\s+\w+s\b", re.I), "Grammar", "Noun_Number_Countability", "HEUR_ARTICLE_PLURAL", 0.50),
        (re.compile(r"\b(in|on|at|to|for|of|with)\s+(the\s+)?(internet|university|work)\b", re.I), "Grammar", "Prepositions", "HEUR_PREPOSITION_CONTEXT", 0.42),
        (re.compile(r"\b(make|do|take)\s+(a\s+)?(decision|mistake|homework|research)\b", re.I), "Vocabulary", "Collocations_Fixed_Expressions", "HEUR_COLLOCATION_CONTEXT", 0.42),
        (re.compile(r"\bvery\s+(big|good|bad|important)\b", re.I), "Vocabulary", "Word_Choice", "HEUR_WORD_CHOICE_BROAD", 0.38),
        (re.compile(r"\b(this|these|it|they)\s+(is|are)\b", re.I), "Grammar", "Pronouns", "HEUR_REFERENCE_PRONOUN", 0.40),
    ]

    try:
        nlp = get_spacy_pipeline(language, spacy_model)
    except Exception:
        nlp = None

    rows: list[dict[str, Any]] = []
    error_counter = 0

    def add_row(sent: pd.Series, start_local: int, end_local: int, macro: str, category: str, rule_id: str, confidence: float, message: str) -> None:
        nonlocal error_counter
        text = str(sent.get("sentence_text", ""))
        sentence_start = int(sent.get("sentence_start_char", 0) or 0)
        error_counter += 1
        rows.append(
            {
                "error_id": f"H{error_counter:07d}",
                "text_id": sent.get("text_id"),
                "student_id": sent.get("student_id"),
                "time_slice": sent.get("time_slice"),
                "lang_level": sent.get("lang_level"),
                "native_lang": sent.get("native_lang") if "native_lang" in sent.index else pd.NA,
                "topic": sent.get("topic"),
                "unit_id": sent.get("sentence_id"),
                "sentence_id": sent.get("sentence_id"),
                "paragraph_id": sent.get("paragraph_id"),
                "start_char": sentence_start + start_local,
                "end_char": sentence_start + end_local,
                "error_span": text[start_local:end_local],
                "suggested_correction": "",
                "macro_category": macro,
                "error_category": category,
                "tool_rule_id": rule_id,
                "tool_message": message,
                "confidence": confidence,
                "interference_flag": None,
                "interference_type": "not_evaluated",
                "interference_confidence": None,
                "annotation_source": "automatic_heuristic",
                "source_corpus": "input_corpus",
                "source_rule_or_alignment": rule_id,
                "classification_confidence": confidence,
            }
        )

    for _, sent in df_sentences.iterrows():
        text = str(sent.get("sentence_text", ""))
        for pattern, macro, category, rule_id, confidence in patterns:
            for match in pattern.finditer(text):
                start_local, end_local = match.span()
                add_row(
                    sent,
                    start_local,
                    end_local,
                    macro,
                    category,
                    rule_id,
                    confidence,
                    "Automatic heuristic fallback; requires expert verification.",
                )
        if nlp is None or not text.strip():
            continue
        doc = nlp(text)
        word_tokens = [tok for tok in doc if not tok.is_space and not tok.is_punct]
        if word_tokens and word_tokens[0].is_alpha and word_tokens[0].text[:1].islower():
            add_row(
                sent,
                word_tokens[0].idx,
                word_tokens[0].idx + len(word_tokens[0]),
                "Capitalisation",
                "Capitalisation",
                "SPACY_SENTENCE_INITIAL_CAPITALISATION",
                0.72,
                "Sentence appears to start with a lowercase alphabetic token.",
            )
        finite_verbs = [tok for tok in word_tokens if tok.pos_ in {"VERB", "AUX"} and "Fin" in tok.morph.get("VerbForm")]
        if len(word_tokens) >= 7 and not finite_verbs:
            add_row(
                sent,
                0,
                min(len(text), 40),
                "Grammar",
                "Sentence_Structure",
                "SPACY_NO_FINITE_VERB",
                0.46,
                "No finite verb detected in a sentence-like unit; possible fragment.",
            )
        for token in word_tokens:
            lower = token.text.lower()
            if lower not in {"is", "are", "was", "were", "has", "have", "do", "does"}:
                continue
            subjects = [child for child in token.children if child.dep_ in {"nsubj", "nsubjpass"}]
            for subj in subjects:
                subj_lower = subj.text.lower()
                if lower in {"has", "is", "does"} and subj_lower in {"i", "we", "you", "they"}:
                    add_row(
                        sent,
                        token.idx,
                        token.idx + len(token),
                        "Grammar",
                        "Subject_Verb_Agreement",
                        "SPACY_SUBJECT_VERB_AGREEMENT",
                        0.64,
                        "spaCy dependency parse suggests possible subject-verb agreement mismatch.",
                    )
                if lower in {"have", "are", "do"} and subj_lower in {"he", "she", "it"}:
                    add_row(
                        sent,
                        token.idx,
                        token.idx + len(token),
                        "Grammar",
                        "Subject_Verb_Agreement",
                        "SPACY_SUBJECT_VERB_AGREEMENT",
                        0.64,
                        "spaCy dependency parse suggests possible subject-verb agreement mismatch.",
                    )
    return pd.DataFrame(rows, columns=ERROR_COLUMNS) if rows else empty_errors_df()


def _validate_annotation_coordinates(annotations: pd.DataFrame, df_sentences: pd.DataFrame, allow_partial: bool) -> pd.DataFrame:
    """Validate sentence IDs and character offsets against the input corpus."""
    if annotations.empty:
        return annotations
    required_cols = {"sentence_id", "text_id", "start_char", "end_char"}
    if not required_cols.issubset(annotations.columns):
        return annotations

    text_lengths = df_sentences[["text_id", "clean_text"]].drop_duplicates("text_id").copy()
    text_lengths["text_char_count_meta"] = text_lengths["clean_text"].astype(str).str.len()
    sentence_ids = set(df_sentences["sentence_id"].dropna().astype(str)) if "sentence_id" in df_sentences.columns else set()
    result = annotations.merge(text_lengths[["text_id", "text_char_count_meta"]], on="text_id", how="left")
    bad_sentence = ~result["sentence_id"].astype(str).isin(sentence_ids)
    starts = pd.to_numeric(result["start_char"], errors="coerce")
    ends = pd.to_numeric(result["end_char"], errors="coerce")
    lengths = pd.to_numeric(result["text_char_count_meta"], errors="coerce")
    bad_offsets = starts.isna() | ends.isna() | (starts < 0) | (ends < starts) | (ends > lengths)
    bad = bad_sentence | bad_offsets
    if bad.any():
        message = (
            f"{int(bad.sum())} annotation rows have sentence_id/start_char/end_char values "
            "that cannot be matched to the input corpus."
        )
        if not allow_partial:
            raise ValueError(message)
        logging.warning("%s Dropping those rows because --allow-partial-annotations is enabled.", message)
        result = result.loc[~bad].copy()
    return result.drop(columns=["text_char_count_meta"], errors="ignore")


def load_annotations(
    path: str | Path,
    df_sentences: pd.DataFrame,
    corpus_df: pd.DataFrame | None = None,
    *,
    allow_partial: bool = False,
    strict: bool = True,
) -> pd.DataFrame:
    """Load expert/pre-existing annotations and enrich them with corpus metadata."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Annotations file not found: {path}")
    annotations = pd.read_csv(path, encoding="utf-8", dtype={"text_id": str, "student_id": str})
    required = {
        "error_id",
        "text_id",
        "student_id",
        "sentence_id",
        "start_char",
        "end_char",
        "error_span",
        "suggested_correction",
        "macro_category",
        "error_category",
        "interference_flag",
        "interference_type",
        "confidence",
    }
    missing = required - set(annotations.columns)
    if missing:
        raise ValueError(f"Annotations CSV is missing required columns: {sorted(missing)}")

    corpus_meta = corpus_df if corpus_df is not None else df_sentences.drop_duplicates("text_id")
    report = validate_annotation_compatibility(corpus_meta, annotations)
    external_guess = report.get("external_corpus_guess")
    if external_guess:
        corpus_sample = " ".join(corpus_meta["text_id"].dropna().astype(str).head(50).tolist()).lower()
        marker = str(external_guess).lower().split("/")[0]
        if marker and marker not in corpus_sample:
            raise ValueError(format_incompatibility_error(report))
    if strict and report["annotation_text_id_valid_ratio"] < 0.95 and not allow_partial:
        raise ValueError(format_incompatibility_error(report))

    ann_ids = set(annotations["text_id"].dropna().astype(str))
    corpus_ids = set(corpus_meta["text_id"].dropna().astype(str))
    extra_ids = ann_ids - corpus_ids
    if extra_ids:
        message = f"{len(extra_ids)} annotation text_id values are not present in the input corpus."
        if not allow_partial:
            raise ValueError(message)
        logging.warning("%s Dropping incompatible annotation rows.", message)
        annotations = annotations[annotations["text_id"].astype(str).isin(corpus_ids)].copy()

    if annotations.empty:
        return empty_errors_df()

    sent_meta_cols = [
        "text_id",
        "student_id",
        "sentence_id",
        "paragraph_id",
        "time_slice",
        "lang_level",
        "native_lang",
        "topic",
    ]
    available_cols = [c for c in sent_meta_cols if c in df_sentences.columns]
    meta = df_sentences[available_cols].drop_duplicates("sentence_id") if "sentence_id" in available_cols else pd.DataFrame()
    result = annotations.merge(meta, on=["text_id", "sentence_id"], how="left", suffixes=("", "_meta"))

    if "student_id_meta" in result.columns:
        mismatch = (
            result["student_id"].notna()
            & result["student_id_meta"].notna()
            & (result["student_id"].astype(str) != result["student_id_meta"].astype(str))
        )
        if mismatch.any() and strict:
            raise ValueError(f"{int(mismatch.sum())} annotation rows have student_id inconsistent with the input corpus.")
        if mismatch.any():
            logging.warning("Replacing inconsistent annotation student_id values with corpus metadata.")
        result["student_id"] = result["student_id_meta"].combine_first(result["student_id"])

    for col in ["time_slice", "lang_level", "native_lang", "topic", "paragraph_id"]:
        meta_col = f"{col}_meta"
        if meta_col in result.columns:
            if col in result.columns:
                mismatch = (
                    result[col].notna()
                    & result[meta_col].notna()
                    & (result[col].astype(str) != result[meta_col].astype(str))
                )
                if mismatch.any():
                    logging.warning("Using corpus %s for %s annotation rows where annotation metadata differs.", col, int(mismatch.sum()))
            result[col] = result[meta_col].combine_first(result[col] if col in result.columns else pd.Series(pd.NA, index=result.index))
    result["unit_id"] = result["sentence_id"] if "unit_id" not in result.columns else result["unit_id"].combine_first(result["sentence_id"])
    result["tool_rule_id"] = result["tool_rule_id"] if "tool_rule_id" in result.columns else "expert_annotation"
    result["tool_message"] = result["tool_message"] if "tool_message" in result.columns else "expert/pre-existing annotation"
    result["interference_confidence"] = result["interference_confidence"] if "interference_confidence" in result.columns else result.get("confidence")
    result["annotation_source"] = result["annotation_source"] if "annotation_source" in result.columns else "expert_or_preannotated"
    result["source_corpus"] = result["source_corpus"] if "source_corpus" in result.columns else "input_corpus"
    result["source_rule_or_alignment"] = (
        result["source_rule_or_alignment"]
        if "source_rule_or_alignment" in result.columns
        else result.get("tool_rule_id", "expert_annotation")
    )
    result["classification_confidence"] = (
        result["classification_confidence"] if "classification_confidence" in result.columns else result.get("confidence")
    )

    result = _validate_annotation_coordinates(result, df_sentences, allow_partial)

    for idx, row in result.iterrows():
        macro, cat = validate_error_category(row.get("error_category"), row.get("macro_category"))
        result.at[idx, "macro_category"] = macro
        result.at[idx, "error_category"] = cat

    for col in ERROR_COLUMNS:
        if col not in result.columns:
            result[col] = pd.NA
    return result[ERROR_COLUMNS]


def detect_possible_interference(errors_df: pd.DataFrame) -> pd.DataFrame:
    """Mark probabilistic L1 interference signals when native language is known.

    The flags are heuristic and do not prove transfer. Unknown native language is
    represented exactly as requested in the task specification.
    """
    if errors_df.empty:
        return errors_df.copy()
    result = errors_df.copy()
    if "native_lang" not in result.columns:
        result["native_lang"] = pd.NA
    for idx, row in result.iterrows():
        native = row.get("native_lang")
        category = row.get("error_category")
        if pd.isna(native) or str(native).strip() == "":
            result.at[idx, "interference_flag"] = None
            result.at[idx, "interference_type"] = "unknown_native_language"
            result.at[idx, "interference_confidence"] = None
            continue
        native_norm = str(native).strip().lower()
        if native_norm in {"ru", "rus", "russian", "русский"} and category in RU_INTERFERENCE_MAP:
            interference_type, confidence = RU_INTERFERENCE_MAP[category]
            result.at[idx, "interference_flag"] = True
            result.at[idx, "interference_type"] = interference_type
            result.at[idx, "interference_confidence"] = confidence
        else:
            result.at[idx, "interference_flag"] = False
            result.at[idx, "interference_type"] = "not_flagged"
            result.at[idx, "interference_confidence"] = 0.0
    return result
