"""Matplotlib visualizations for error networks and frequencies."""

from __future__ import annotations

import os
import textwrap
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")

import matplotlib

matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = "DejaVu Sans"
matplotlib.rcParams["axes.unicode_minus"] = False
import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd
import seaborn as sns

from .taxonomy import error_category_ru, macro_category_ru

PLOT_RC = {
    "axes.facecolor": "white",
    "figure.facecolor": "white",
    "axes.edgecolor": "#222222",
    "axes.labelcolor": "#111111",
    "axes.labelsize": 16,
    "axes.titlesize": 22,
    "axes.titleweight": "bold",
    "xtick.color": "#111111",
    "ytick.color": "#111111",
    "xtick.labelsize": 13,
    "ytick.labelsize": 13,
    "legend.fontsize": 11,
    "legend.title_fontsize": 12,
    "grid.color": "#b8b8b8",
    "grid.linestyle": ":",
    "grid.linewidth": 0.9,
}
sns.set_theme(style="whitegrid", font="DejaVu Sans", context="talk", rc=PLOT_RC)

TIME_ORDER = ["T1", "T2", "T3"]
LEVEL_ORDER = ["A1", "A2", "B1", "B2", "C1"]

TITLE_SIZE = 22
LABEL_SIZE = 16
TICK_SIZE = 13
LEGEND_SIZE = 11
NETWORK_LABEL_SIZE = 11
MACRO_COLORS = {
    "Grammar": "#55B879",
    "Vocabulary": "#F06423",
    "Punctuation": "#4E79A7",
    "Spelling": "#59A14F",
    "Capitalisation": "#B07AA1",
    "Discourse": "#EDC948",
    "Other": "#8C8C8C",
    "Technical": "#8C8C8C",
}
LINE_COLORS = [
    "#4169E1",
    "#FF3B30",
    "#2CA02C",
    "#7B3FE4",
    "#8B5A2B",
    "#7F7F7F",
    "#E377C2",
    "#9B59B6",
    "#17BECF",
    "#BCBD22",
]


def _safe_savefig(path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def _apply_axis_style(ax: plt.Axes | None = None, *, grid_axis: str = "both") -> plt.Axes:
    """Apply the high-contrast publication style used by all non-network plots."""
    ax = ax or plt.gca()
    ax.set_facecolor("white")
    ax.figure.set_facecolor("white")
    ax.grid(True, which="major", axis=grid_axis, linestyle=":", linewidth=0.9, color="#b8b8b8", alpha=0.95)
    for spine in ax.spines.values():
        spine.set_color("#222222")
        spine.set_linewidth(1.1)
    ax.tick_params(axis="both", colors="#111111", labelsize=TICK_SIZE, width=1.1)
    ax.xaxis.label.set_size(LABEL_SIZE)
    ax.yaxis.label.set_size(LABEL_SIZE)
    ax.xaxis.label.set_weight("bold")
    ax.yaxis.label.set_weight("bold")
    return ax


def _style_legend(legend) -> None:
    if legend is None:
        return
    legend.get_frame().set_facecolor("white")
    legend.get_frame().set_edgecolor("#9a9a9a")
    legend.get_frame().set_linewidth(0.9)
    legend.get_frame().set_alpha(0.95)
    legend.get_title().set_fontweight("bold")
    for text in legend.get_texts():
        text.set_color("#111111")
        text.set_fontsize(LEGEND_SIZE)


def _wrap_label(value: object, width: int = 24) -> str:
    text = str(value)
    return "\n".join(textwrap.wrap(text, width=width, break_long_words=False, break_on_hyphens=False)) or text


def _category_label(category: str, plot_language: str = "ru", *, width: int = 24) -> str:
    label = error_category_ru(category) if plot_language == "ru" else category
    return _wrap_label(label, width=width)


def _macro_color(value: str) -> str:
    return MACRO_COLORS.get(value, "#8C8C8C")


def _warning_figure(output_path: str | Path, message: str) -> None:
    plt.figure(figsize=(12, 6), facecolor="white")
    plt.text(0.5, 0.5, message, ha="center", va="center", wrap=True, fontsize=16, fontweight="bold", color="#111111")
    plt.axis("off")
    _safe_savefig(output_path)


def _filtered_graph(G: nx.Graph) -> nx.Graph:
    keep = [n for n, data in G.nodes(data=True) if int(data.get("error_count", 0) or 0) > 0]
    return G.subgraph(keep).copy()


def visualize_network(G: nx.Graph, output_path: str | Path, color_by: str = "macro_category", plot_language: str = "ru") -> None:
    """Draw the main error network: color by macro-category, size by frequency."""
    H = _filtered_graph(G)
    if len(H) == 0:
        _warning_figure(output_path, "Нет данных для построения графика: проверьте совместимость annotations.csv и data.csv")
        return
    fig, ax = plt.subplots(figsize=(13, 9), facecolor="white")
    ax.set_facecolor("white")
    pos = nx.spring_layout(H, weight="weight", seed=42, k=1.15, iterations=300)
    rates = [float(H.nodes[n].get("error_rate_per_1000", 0.0) or 0.0) for n in H.nodes]
    max_rate = max(rates) if rates else 1.0
    node_sizes = [620 + (rate / max_rate * 3200 if max_rate else 0) for rate in rates]
    values = [str(H.nodes[n].get(color_by, "unknown")) for n in H.nodes]
    weights = [float(data.get("weight", 0.1) or 0.1) for _, _, data in H.edges(data=True)]
    max_weight = max(weights) if weights else 1.0
    widths = [1.2 + (w / max_weight * 6.0 if max_weight else 1.2) for w in weights]
    nx.draw_networkx_edges(H, pos, width=widths, alpha=0.78, edge_color="#6b6b6b", ax=ax)
    color_values = [_macro_color(value) for value in values]
    nx.draw_networkx_nodes(
        H,
        pos,
        node_size=node_sizes,
        node_color=color_values,
        edgecolors="#222222",
        linewidths=1.3,
        alpha=0.98,
        ax=ax,
    )
    labels = {node: _category_label(str(node), plot_language, width=23) for node in H.nodes}
    nx.draw_networkx_labels(
        H,
        pos,
        labels=labels,
        font_size=NETWORK_LABEL_SIZE,
        font_weight="bold",
        font_color="#111111",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.75, "pad": 0.18},
        ax=ax,
    )
    handles = []
    for value in sorted(set(values)):
        handles.append(
            plt.Line2D(
                [0],
                [0],
                marker="o",
                color="w",
                label=macro_category_ru(value),
                markerfacecolor=_macro_color(value),
                markeredgecolor="#222222",
                markersize=12,
            )
        )
    if handles:
        legend = ax.legend(handles=handles, title="Макрокатегория", loc="upper right", fontsize=LEGEND_SIZE)
        _style_legend(legend)
    ax.set_title("Сеть совместной встречаемости ошибок", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=14)
    ax.margins(0.18)
    ax.axis("off")
    _safe_savefig(output_path)


def visualize_communities_network(G: nx.Graph, output_path: str | Path, plot_language: str = "ru") -> None:
    """Draw a community-focused network with colors denoting clusters."""
    H = _filtered_graph(G)
    if len(H) == 0:
        _warning_figure(output_path, "Нет данных для построения графика: сеть ошибок пуста")
        return
    fig, ax = plt.subplots(figsize=(13, 9), facecolor="white")
    ax.set_facecolor("white")
    pos = nx.spring_layout(H, weight="weight", seed=17, k=1.25, iterations=300)
    communities = [int(H.nodes[n].get("community", -1)) for n in H.nodes]
    community_values = sorted(set(communities))
    community_to_id = {value: idx for idx, value in enumerate(community_values)}
    colors = [community_to_id[c] for c in communities]
    rates = [float(H.nodes[n].get("error_rate_per_1000", 0.0) or 0.0) for n in H.nodes]
    max_rate = max(rates) if rates else 1.0
    sizes = [620 + (rate / max_rate * 3000 if max_rate else 0) for rate in rates]
    weights = [float(data.get("weight", 0.1) or 0.1) for _, _, data in H.edges(data=True)]
    max_weight = max(weights) if weights else 1.0
    widths = [1.2 + (w / max_weight * 5.2 if max_weight else 1.2) for w in weights]
    nx.draw_networkx_edges(H, pos, width=widths, alpha=0.72, edge_color="#6b6b6b", ax=ax)
    palette = sns.color_palette("Set2", max(len(community_to_id), 1))
    node_colors = [palette[color_id % len(palette)] for color_id in colors]
    nx.draw_networkx_nodes(
        H,
        pos,
        node_size=sizes,
        node_color=node_colors,
        edgecolors="#222222",
        linewidths=1.5,
        alpha=0.95,
        ax=ax,
    )
    nx.draw_networkx_labels(
        H,
        pos,
        labels={node: _category_label(str(node), plot_language, width=23) for node in H.nodes},
        font_size=NETWORK_LABEL_SIZE,
        font_weight="bold",
        font_color="#111111",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.75, "pad": 0.18},
        ax=ax,
    )
    handles = []
    for community_id, color_id in community_to_id.items():
        handles.append(
            plt.Line2D(
                [0],
                [0],
                marker="o",
                color="w",
                label=f"Кластер {color_id + 1}",
                markerfacecolor=palette[color_id % len(palette)],
                markeredgecolor="#222222",
                markersize=10,
            )
        )
    if handles:
        legend = ax.legend(handles=handles, title="Сообщества", loc="upper right", fontsize=LEGEND_SIZE)
        _style_legend(legend)
    ax.set_title(f"Кластеры ошибок: {len(community_values)}", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=14)
    ax.margins(0.18)
    ax.axis("off")
    _safe_savefig(output_path)


def top_errors_barplot(frequencies_df: pd.DataFrame, output_path: str | Path, top_n: int = 15, plot_language: str = "ru") -> None:
    """Save a bar chart of top error categories by normalized frequency."""
    if frequencies_df.empty or "error_count" not in frequencies_df.columns:
        _warning_figure(output_path, "Нет данных для построения графика: проверьте совместимость annotations.csv и data.csv")
        return
    data = frequencies_df[frequencies_df["error_count"].astype(float) > 0].copy()
    if data.empty:
        _warning_figure(output_path, "Нет ненулевых ошибок для построения графика.")
        return
    data = data.sort_values("error_rate_per_1000", ascending=False).head(top_n)
    data["display_category"] = data.get("error_category_ru", data["error_category"].map(error_category_ru))
    data["display_category"] = data["display_category"].map(lambda value: _wrap_label(value, width=34))
    fig, ax = plt.subplots(figsize=(12, 8), facecolor="white")
    sns.barplot(data=data, y="display_category", x="error_rate_per_1000", hue="display_category", palette="Set2", legend=False, ax=ax)
    ax.invert_yaxis()
    ax.set_xlabel("Ошибок на 1000 слов")
    ax.set_ylabel("Категория ошибки")
    ax.set_title("Наиболее частотные ошибки", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
    _apply_axis_style(ax, grid_axis="x")
    _safe_savefig(output_path)


def centrality_barplot(node_metrics: pd.DataFrame, output_path: str | Path, metric: str = "weighted_degree", top_n: int = 15, plot_language: str = "ru") -> None:
    """Save a bar chart of top nodes by centrality."""
    if node_metrics.empty or metric not in node_metrics.columns:
        _warning_figure(output_path, "Нет сетевых метрик для построения графика.")
        return
    data = node_metrics[pd.to_numeric(node_metrics[metric], errors="coerce").fillna(0) > 0].copy()
    if data.empty:
        _warning_figure(output_path, "Нет категорий с положительной взвешенной степенью.")
        return
    data = data.sort_values(metric, ascending=False).head(top_n)
    data["display_category"] = data.get("error_category_ru", data["error_category"].map(error_category_ru))
    data["display_category"] = data["display_category"].map(lambda value: _wrap_label(value, width=34))
    fig, ax = plt.subplots(figsize=(12, 8), facecolor="white")
    sns.barplot(data=data, y="display_category", x=metric, hue="display_category", palette="Set2", legend=False, ax=ax)
    ax.invert_yaxis()
    ax.set_xlabel("Взвешенная степень")
    ax.set_ylabel("Категория ошибки")
    ax.set_title("Центральные категории ошибок в сети", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
    _apply_axis_style(ax, grid_axis="x")
    _safe_savefig(output_path)


def edge_weight_heatmap(edges_df: pd.DataFrame, output_path: str | Path, plot_language: str = "ru") -> None:
    """Save a heatmap-like matrix of edge weights."""
    if edges_df.empty:
        _warning_figure(output_path, "Нет статистически значимых связей между категориями ошибок.")
        return
    categories = sorted(set(edges_df["source"]).union(edges_df["target"]))
    matrix = pd.DataFrame(float("nan"), index=categories, columns=categories)
    for _, row in edges_df.iterrows():
        matrix.at[row["source"], row["target"]] = row["weight"]
        matrix.at[row["target"], row["source"]] = row["weight"]
    labels = [_wrap_label(error_category_ru(cat), width=18) for cat in categories]
    display_matrix = matrix.copy()
    display_matrix.index = labels
    display_matrix.columns = labels
    fig, ax = plt.subplots(figsize=(13, 10), facecolor="white")
    sns.heatmap(
        display_matrix,
        cmap="YlGnBu",
        annot=True,
        annot_kws={"fontsize": 11, "fontweight": "bold", "color": "#111111"},
        fmt=".2f",
        linewidths=0.7,
        linecolor="#f0f0f0",
        cbar_kws={"label": "Сила связи"},
        ax=ax,
    )
    ax.set_xticklabels(ax.get_xticklabels(), rotation=90, fontsize=11, color="#111111")
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=11, color="#111111")
    ax.set_title("Сила связей между категориями ошибок", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelsize=11, colors="#111111")
    cbar.ax.yaxis.label.set_size(13)
    cbar.ax.yaxis.label.set_weight("bold")
    _safe_savefig(output_path)


def error_rates_by_group(frequencies_df: pd.DataFrame, group_col: str, output_path: str | Path, top_n: int = 10, plot_language: str = "ru") -> None:
    """Save grouped normalized error frequencies."""
    if frequencies_df.empty or group_col not in frequencies_df.columns:
        _warning_figure(output_path, "Нет данных для построения графика: проверьте совместимость annotations.csv и data.csv")
        return
    data_nonzero = frequencies_df[frequencies_df["error_count"].astype(float) > 0].copy()
    if data_nonzero.empty:
        _warning_figure(output_path, "Нет ненулевых ошибок для построения графика.")
        return
    top_categories = (
        data_nonzero.groupby("error_category")["error_rate_per_1000"]
        .mean()
        .sort_values(ascending=False)
        .head(top_n)
        .index
    )
    data = data_nonzero[data_nonzero["error_category"].isin(top_categories)].copy()
    pivot = data.pivot_table(index=group_col, columns="error_category", values="error_rate_per_1000", aggfunc="mean").fillna(0)
    if group_col == "time_slice":
        pivot = pivot.reindex([x for x in TIME_ORDER if x in pivot.index])
    elif group_col == "lang_level":
        pivot = pivot.reindex([x for x in LEVEL_ORDER if x in pivot.index])
    if pivot.empty or pivot.to_numpy().sum() == 0:
        _warning_figure(output_path, "Нет ненулевых значений для построения графика.")
        return
    pivot = pivot.rename(columns=error_category_ru)
    fig, ax = plt.subplots(figsize=(12, 8), facecolor="white")
    kind = "line" if group_col == "time_slice" else "bar"
    plot_data = pivot.reset_index().melt(id_vars=group_col, var_name="Категория ошибки", value_name="Ошибок на 1000 слов")
    if kind == "line":
        sns.lineplot(
            data=plot_data,
            x=group_col,
            y="Ошибок на 1000 слов",
            hue="Категория ошибки",
            marker="o",
            markersize=6,
            linewidth=2.2,
            palette=LINE_COLORS,
            ax=ax,
        )
        ax.set_xlabel("Временной срез")
        ax.set_title("Динамика ошибок по временным срезам", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
        _apply_axis_style(ax, grid_axis="both")
        legend = ax.legend(title="Категория ошибки", fontsize=9, title_fontsize=10, loc="center right", frameon=True)
    else:
        sns.barplot(data=plot_data, x=group_col, y="Ошибок на 1000 слов", hue="Категория ошибки", palette="Set2", ax=ax)
        ax.set_xlabel("Уровень владения")
        ax.set_title("Частотность ошибок по уровню владения", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
        _apply_axis_style(ax, grid_axis="y")
        legend = ax.legend(title="Категория ошибки", fontsize=9, title_fontsize=10, bbox_to_anchor=(1.02, 1), loc="upper left", frameon=True)
    ax.set_ylabel("Ошибок на 1000 слов")
    _style_legend(legend)
    _safe_savefig(output_path)


def save_all_figures(
    G: nx.Graph,
    frequencies: dict[str, pd.DataFrame],
    nodes_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    output_dir: str | Path,
    plot_language: str = "ru",
) -> None:
    """Generate all required figures."""
    figures = Path(output_dir) / "figures"
    visualize_network(G, figures / "error_network.png", color_by="macro_category", plot_language=plot_language)
    top_errors_barplot(frequencies.get("overall", pd.DataFrame()), figures / "top_errors_barplot.png", plot_language=plot_language)
    centrality_barplot(nodes_df, figures / "centrality_barplot.png", plot_language=plot_language)
    edge_weight_heatmap(edges_df, figures / "edge_weight_heatmap.png", plot_language=plot_language)
    error_rates_by_group(frequencies.get("by_lang_level", pd.DataFrame()), "lang_level", figures / "error_rates_by_level.png", plot_language=plot_language)
    error_rates_by_group(frequencies.get("by_time_slice", pd.DataFrame()), "time_slice", figures / "error_rates_by_time_slice.png", plot_language=plot_language)
    visualize_communities_network(G, figures / "communities_network.png", plot_language=plot_language)
