"""Network edge export and sensitivity analysis helpers."""

from __future__ import annotations

import pandas as pd

PRONOUN_CATEGORY = "Pronouns"


def export_network_edges(edges_df: pd.DataFrame) -> pd.DataFrame:
    """Return the publication edge table with explicit p/q/Jaccard/phi fields."""
    columns = ["source", "target", "weight", "p_value", "q_value", "jaccard", "phi"]
    if edges_df.empty:
        return pd.DataFrame(columns=columns)
    result = pd.DataFrame(
        {
            "source": edges_df.get("source", pd.Series(dtype=str)),
            "target": edges_df.get("target", pd.Series(dtype=str)),
            "weight": pd.to_numeric(edges_df.get("weight", 0.0), errors="coerce").fillna(0.0),
            "p_value": pd.to_numeric(edges_df.get("p_value", 1.0), errors="coerce").fillna(1.0),
            "q_value": pd.to_numeric(edges_df.get("corrected_p_value", 1.0), errors="coerce").fillna(1.0),
            "jaccard": pd.to_numeric(edges_df.get("jaccard", 0.0), errors="coerce").fillna(0.0),
            "phi": pd.to_numeric(edges_df.get("phi_coefficient", 0.0), errors="coerce").fillna(0.0),
        }
    )
    return result.sort_values(["weight", "source", "target"], ascending=[False, True, True]).reset_index(drop=True)


def _edge_key(source: object, target: object) -> tuple[str, str]:
    a, b = sorted([str(source), str(target)])
    return a, b


def _average_edge_weight(edges_df: pd.DataFrame) -> float:
    if edges_df.empty or "weight" not in edges_df.columns:
        return 0.0
    return float(pd.to_numeric(edges_df["weight"], errors="coerce").fillna(0.0).mean())


def compare_without_pronouns(
    full_graph_metrics: dict,
    reduced_graph_metrics: dict,
    full_node_metrics: pd.DataFrame,
    reduced_node_metrics: pd.DataFrame,
    full_edges: pd.DataFrame,
    reduced_edges: pd.DataFrame,
    change_threshold: float = 0.10,
) -> pd.DataFrame:
    """Compare full network metrics with a network rebuilt without Pronouns."""
    rows: list[dict[str, object]] = []
    metric_names = ["num_nodes", "num_edges", "density", "average_degree", "average_weighted_degree"]
    for metric in metric_names:
        full_value = float(full_graph_metrics.get(metric, 0.0) or 0.0)
        reduced_value = float(reduced_graph_metrics.get(metric, 0.0) or 0.0)
        rows.append(
            {
                "row_type": "graph_metric",
                "item": metric,
                "full_value": full_value,
                "without_pronouns_value": reduced_value,
                "delta": reduced_value - full_value,
                "substantial_change": abs(reduced_value - full_value) >= change_threshold,
            }
        )
    rows.append(
        {
            "row_type": "graph_metric",
            "item": "average_edge_weight",
            "full_value": _average_edge_weight(full_edges),
            "without_pronouns_value": _average_edge_weight(reduced_edges),
            "delta": _average_edge_weight(reduced_edges) - _average_edge_weight(full_edges),
            "substantial_change": abs(_average_edge_weight(reduced_edges) - _average_edge_weight(full_edges)) >= change_threshold,
        }
    )

    metric_cols = ["degree", "weighted_degree", "betweenness_centrality", "eigenvector_centrality", "pagerank"]
    full_nodes = full_node_metrics.copy()
    reduced_nodes = reduced_node_metrics.copy()
    if "error_category" in full_nodes.columns and "error_category" in reduced_nodes.columns:
        merged = full_nodes[["error_category", *[c for c in metric_cols if c in full_nodes.columns]]].merge(
            reduced_nodes[["error_category", *[c for c in metric_cols if c in reduced_nodes.columns]]],
            on="error_category",
            how="outer",
            suffixes=("_full", "_without_pronouns"),
        ).fillna(0)
        for _, row in merged.iterrows():
            for metric in metric_cols:
                full_col = f"{metric}_full"
                reduced_col = f"{metric}_without_pronouns"
                if full_col not in row.index or reduced_col not in row.index:
                    continue
                delta = float(row[reduced_col]) - float(row[full_col])
                rows.append(
                    {
                        "row_type": "node_metric",
                        "item": row["error_category"],
                        "metric": metric,
                        "full_value": float(row[full_col]),
                        "without_pronouns_value": float(row[reduced_col]),
                        "delta": delta,
                        "substantial_change": abs(delta) >= change_threshold,
                    }
                )

    full_edge_map = {
        _edge_key(row["source"], row["target"]): float(row.get("weight", 0.0) or 0.0)
        for _, row in full_edges.iterrows()
        if {"source", "target"}.issubset(full_edges.columns)
    }
    reduced_edge_map = {
        _edge_key(row["source"], row["target"]): float(row.get("weight", 0.0) or 0.0)
        for _, row in reduced_edges.iterrows()
        if {"source", "target"}.issubset(reduced_edges.columns)
    }
    for edge in sorted(set(full_edge_map) | set(reduced_edge_map)):
        full_weight = full_edge_map.get(edge, 0.0)
        reduced_weight = reduced_edge_map.get(edge, 0.0)
        if edge not in reduced_edge_map:
            status = "removed"
        elif edge not in full_edge_map:
            status = "added"
        else:
            status = "retained"
        rows.append(
            {
                "row_type": "edge",
                "item": f"{edge[0]} -- {edge[1]}",
                "metric": "weight",
                "full_value": full_weight,
                "without_pronouns_value": reduced_weight,
                "delta": reduced_weight - full_weight,
                "change_status": status,
                "substantial_change": status in {"removed", "added"} or abs(reduced_weight - full_weight) >= change_threshold,
            }
        )
    return pd.DataFrame(rows)
