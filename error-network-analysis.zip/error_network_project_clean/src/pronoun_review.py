"""Manual review support for the Pronouns error category."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

PRONOUN_CATEGORY = "Pronouns"
VALID_PRONOUN_STATUSES = {"true_error", "pronoun_usage", "ambiguous", "exclude"}
REVIEW_COLUMNS = [
    "review_key",
    "error_id",
    "text_id",
    "student_id",
    "time_slice",
    "lang_level",
    "topic",
    "sentence_id",
    "start_char",
    "end_char",
    "error_span",
    "context",
    "old_category",
    "pronoun_status",
    "expert_comment",
]


def _review_key(row: pd.Series) -> str:
    if str(row.get("error_id", "")).strip():
        return str(row.get("error_id"))
    parts = [row.get("text_id", ""), row.get("sentence_id", ""), row.get("start_char", ""), row.get("end_char", ""), row.get("error_span", "")]
    return "||".join(str(part) for part in parts)


def _context(row: pd.Series, units_df: pd.DataFrame, width: int = 120) -> str:
    text = ""
    sentence_start = 0
    if "sentence_id" in row and "sentence_id" in units_df.columns:
        matched = units_df[units_df["sentence_id"].astype(str).eq(str(row.get("sentence_id")))]
        if not matched.empty:
            text = str(matched.iloc[0].get("sentence_text", ""))
            sentence_start = int(pd.to_numeric(pd.Series([matched.iloc[0].get("sentence_start_char", 0)]), errors="coerce").fillna(0).iloc[0])
    if not text:
        text = str(row.get("error_span", ""))
    start = int(pd.to_numeric(pd.Series([row.get("start_char", 0)]), errors="coerce").fillna(0).iloc[0])
    local_start = max(0, min(len(text), start - sentence_start))
    return text[max(0, local_start - width) : min(len(text), local_start + width)]


def build_pronouns_review(errors_df: pd.DataFrame, units_df: pd.DataFrame) -> pd.DataFrame:
    """Create a review sheet for candidate pronoun errors."""
    if errors_df.empty or "error_category" not in errors_df.columns:
        return pd.DataFrame(columns=REVIEW_COLUMNS)
    pronouns = errors_df[errors_df["error_category"].astype(str).eq(PRONOUN_CATEGORY)].copy()
    rows = []
    for _, row in pronouns.iterrows():
        rows.append(
            {
                "review_key": _review_key(row),
                "error_id": row.get("error_id", ""),
                "text_id": row.get("text_id", ""),
                "student_id": row.get("student_id", ""),
                "time_slice": row.get("time_slice", ""),
                "lang_level": row.get("lang_level", ""),
                "topic": row.get("topic", ""),
                "sentence_id": row.get("sentence_id", ""),
                "start_char": row.get("start_char", ""),
                "end_char": row.get("end_char", ""),
                "error_span": row.get("error_span", ""),
                "context": _context(row, units_df),
                "old_category": row.get("error_category", PRONOUN_CATEGORY),
                "pronoun_status": "",
                "expert_comment": "",
            }
        )
    return pd.DataFrame(rows, columns=REVIEW_COLUMNS)


def apply_pronouns_review(errors_df: pd.DataFrame, review_path: str | Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Keep only reviewed true Pronouns errors and return filtered errors plus review rows."""
    if errors_df.empty:
        return errors_df.copy(), pd.DataFrame()
    review = pd.read_csv(review_path, encoding="utf-8", dtype=str).fillna("")
    if "review_key" not in review.columns:
        if "error_id" in review.columns:
            review["review_key"] = review["error_id"].astype(str)
        else:
            review["review_key"] = review.apply(_review_key, axis=1)
    if "pronoun_status" not in review.columns:
        raise ValueError("Pronouns review file must contain pronoun_status.")
    review["pronoun_status"] = review["pronoun_status"].astype(str).str.strip()
    bad_status = review["pronoun_status"].ne("") & ~review["pronoun_status"].isin(VALID_PRONOUN_STATUSES)
    if bad_status.any():
        values = sorted(review.loc[bad_status, "pronoun_status"].unique().tolist())
        raise ValueError(f"Unknown pronoun_status values: {values}")

    result = errors_df.copy()
    result["_review_key"] = result.apply(_review_key, axis=1)
    status_map = review.set_index("review_key")["pronoun_status"].to_dict()
    result["pronoun_status"] = result["_review_key"].map(status_map).fillna("")

    is_pronoun = result["error_category"].astype(str).eq(PRONOUN_CATEGORY)
    keep = ~is_pronoun | result["pronoun_status"].eq("true_error")
    filtered = result.loc[keep].drop(columns=["_review_key"], errors="ignore").copy()
    return filtered, review
