"""Taxonomy and LanguageTool rule mapping for learner error network analysis."""

from __future__ import annotations

import re
from typing import Any

ERROR_TAXONOMY: dict[str, list[str]] = {
    "Punctuation": ["Punctuation"],
    "Spelling": ["Spelling"],
    "Capitalisation": ["Capitalisation"],
    "Grammar": [
        "Articles_Determiners",
        "Prepositions",
        "Verb_Tense_Aspect",
        "Verb_Form_Morphology",
        "Subject_Verb_Agreement",
        "Noun_Number_Countability",
        "Pronouns",
        "Word_Order",
        "Sentence_Structure",
    ],
    "Vocabulary": ["Word_Choice", "Collocations_Fixed_Expressions"],
    "Discourse": ["Reference", "Linking_Devices", "Discourse_Logic"],
    "Other": ["Other_Unclassified"],
}

CATEGORY_TO_MACRO: dict[str, str] = {
    category: macro for macro, categories in ERROR_TAXONOMY.items() for category in categories
}

ERROR_CATEGORIES: list[str] = list(CATEGORY_TO_MACRO.keys())

ERROR_CATEGORY_RU = {
    "Punctuation": "Пунктуация",
    "Spelling": "Орфография",
    "Capitalisation": "Заглавные буквы",
    "Articles_Determiners": "Артикли и определители",
    "Prepositions": "Предлоги",
    "Verb_Tense_Aspect": "Время и аспект глагола",
    "Verb_Form_Morphology": "Форма глагола",
    "Subject_Verb_Agreement": "Согласование подлежащего и сказуемого",
    "Noun_Number_Countability": "Число и исчисляемость существительных",
    "Pronouns": "Местоимения",
    "Word_Order": "Порядок слов",
    "Sentence_Structure": "Структура предложения",
    "Word_Choice": "Выбор слова",
    "Collocations_Fixed_Expressions": "Коллокации и устойчивые выражения",
    "Reference": "Референция",
    "Linking_Devices": "Средства связи",
    "Discourse_Logic": "Логика дискурса",
    "Other_Unclassified": "Прочее / неклассифицированное",
}

MACRO_CATEGORY_RU = {
    "Punctuation": "Пунктуация",
    "Spelling": "Орфография",
    "Capitalisation": "Заглавные буквы",
    "Grammar": "Грамматика",
    "Vocabulary": "Лексика",
    "Discourse": "Дискурс",
    "Other": "Прочее",
    "Technical": "Прочее",
}

LT_RULE_PATTERNS: list[tuple[re.Pattern[str], str, str, float]] = [
    (re.compile(r"MORFOLOGIK|SPELL|HUNSPELL|TYPO|MISSPELL", re.I), "Spelling", "Spelling", 0.95),
    (re.compile(r"PUNCT|COMMA|COLON|SEMICOLON|APOSTROPHE|DASH|HYPHEN", re.I), "Punctuation", "Punctuation", 0.90),
    (re.compile(r"UPPERCASE|LOWERCASE|CAPITALI[ZS]|CAPITALIZATION", re.I), "Capitalisation", "Capitalisation", 0.90),
    (re.compile(r"ARTICLE|\bA_AN\b|\bTHE\b|\bDET\b|DETERMINER", re.I), "Grammar", "Articles_Determiners", 0.85),
    (re.compile(r"PREP|PREPOSITION|\bIN_ON\b|\bON_IN\b|\bOF_TO\b", re.I), "Grammar", "Prepositions", 0.82),
    (re.compile(r"TENSE|ASPECT|PAST|PRESENT|PERFECT|PROGRESSIVE|CONTINUOUS", re.I), "Grammar", "Verb_Tense_Aspect", 0.78),
    (re.compile(r"VERB_FORM|GERUND|INFINITIVE|PARTICIPLE|IRREGULAR_VERB|VERB", re.I), "Grammar", "Verb_Form_Morphology", 0.72),
    (re.compile(r"AGREEMENT|SVA|SUBJECT_VERB|DOESNT|DONT|IS_ARE|HAS_HAVE", re.I), "Grammar", "Subject_Verb_Agreement", 0.82),
    (re.compile(r"PLURAL|SINGULAR|NOUN_NUMBER|COUNTABLE|UNCOUNTABLE|MANY_MUCH|FEW_LESS", re.I), "Grammar", "Noun_Number_Countability", 0.78),
    (re.compile(r"PRONOUN|REFLEXIVE|POSSESSIVE|\bHE_SHE\b|\bHIS_HER\b", re.I), "Grammar", "Pronouns", 0.76),
    (re.compile(r"WORD_ORDER|ORDER_OF_WORDS|ADVERB_POSITION", re.I), "Grammar", "Word_Order", 0.80),
    (re.compile(r"FRAGMENT|RUN_ON|SENTENCE|CLAUSE|RELATIVE_CLAUSE|SUBORDINATE", re.I), "Grammar", "Sentence_Structure", 0.76),
    (re.compile(r"CONFUSED_WORDS|WORD_CHOICE|WRONG_WORD|MISUSED|FALSE_FRIEND", re.I), "Vocabulary", "Word_Choice", 0.74),
    (re.compile(r"COLLOCATION|IDIOM|FIXED_EXPRESSION|PHRASE", re.I), "Vocabulary", "Collocations_Fixed_Expressions", 0.78),
    (re.compile(r"CONNECTOR|LINKING|TRANSITION|CONJUNCTION", re.I), "Discourse", "Linking_Devices", 0.70),
    (re.compile(r"REFERENCE|COREFERENCE|ANTECEDENT", re.I), "Discourse", "Reference", 0.70),
    (re.compile(r"LOGIC|COHERENCE|DISCOURSE", re.I), "Discourse", "Discourse_Logic", 0.70),
]

MESSAGE_PATTERNS: list[tuple[re.Pattern[str], str, str, float]] = [
    (re.compile(r"article|determiner|\ba\b|\ban\b|\bthe\b", re.I), "Grammar", "Articles_Determiners", 0.65),
    (re.compile(r"preposition|use of ['\"]?(in|on|at|to|for|of|with)['\"]?", re.I), "Grammar", "Prepositions", 0.64),
    (re.compile(r"tense|aspect|past|present perfect|progressive", re.I), "Grammar", "Verb_Tense_Aspect", 0.62),
    (re.compile(r"verb form|infinitive|gerund|participle", re.I), "Grammar", "Verb_Form_Morphology", 0.62),
    (re.compile(r"agreement|singular verb|plural verb", re.I), "Grammar", "Subject_Verb_Agreement", 0.65),
    (re.compile(r"plural|singular|countable|uncountable", re.I), "Grammar", "Noun_Number_Countability", 0.62),
    (re.compile(r"pronoun|antecedent|reference", re.I), "Grammar", "Pronouns", 0.60),
    (re.compile(r"word order|order of words", re.I), "Grammar", "Word_Order", 0.62),
    (re.compile(r"sentence structure|sentence fragment|run-on|clause", re.I), "Grammar", "Sentence_Structure", 0.62),
    (re.compile(r"word choice|wrong word|confused", re.I), "Vocabulary", "Word_Choice", 0.60),
    (re.compile(r"collocation|idiom|fixed expression", re.I), "Vocabulary", "Collocations_Fixed_Expressions", 0.62),
    (re.compile(r"linking word|connector|transition", re.I), "Discourse", "Linking_Devices", 0.58),
    (re.compile(r"punctuation|comma|semicolon|colon|apostrophe", re.I), "Punctuation", "Punctuation", 0.70),
    (re.compile(r"spelling|typo|misspelled", re.I), "Spelling", "Spelling", 0.72),
    (re.compile(r"capital|uppercase|lowercase", re.I), "Capitalisation", "Capitalisation", 0.72),
]


def get_macro_category(error_category: str) -> str:
    """Return the macro-category for an operational error category."""
    return CATEGORY_TO_MACRO.get(error_category, "Other")


def error_category_ru(error_category: str | None) -> str:
    """Return a Russian display label for an error category."""
    value = str(error_category or "Other_Unclassified")
    return ERROR_CATEGORY_RU.get(value, value)


def macro_category_ru(macro_category: str | None) -> str:
    """Return a Russian display label for a macro-category."""
    value = str(macro_category or "Other")
    return MACRO_CATEGORY_RU.get(value, value)


def add_display_columns(df):
    """Add Russian display columns when category columns are present."""
    result = df.copy()
    if "error_category" in result.columns:
        result["error_category_ru"] = result["error_category"].map(error_category_ru)
    if "macro_category" in result.columns:
        result["macro_category_ru"] = result["macro_category"].map(macro_category_ru)
    for source_col, display_col in [("source", "source_ru"), ("target", "target_ru")]:
        if source_col in result.columns:
            result[display_col] = result[source_col].map(error_category_ru)
    for source_col, display_col in [
        ("source_macro_category", "source_macro_category_ru"),
        ("target_macro_category", "target_macro_category_ru"),
    ]:
        if source_col in result.columns:
            result[display_col] = result[source_col].map(macro_category_ru)
    return result


def map_languagetool_rule_to_error_category(
    rule_id: str | None,
    message: str | None,
    category: str | None = None,
    context: str | None = None,
) -> dict[str, Any]:
    """Map a LanguageTool rule to the project error taxonomy.

    The mapping is intentionally heuristic. It returns a confidence score so
    downstream reports can clearly mark the annotation as semi-automatic.
    """
    haystack = " ".join(str(x or "") for x in [rule_id, category, context])
    for pattern, macro, error_category, confidence in LT_RULE_PATTERNS:
        if pattern.search(haystack):
            return {
                "macro_category": macro,
                "error_category": error_category,
                "confidence": confidence,
            }

    message_text = str(message or "")
    for pattern, macro, error_category, confidence in MESSAGE_PATTERNS:
        if pattern.search(message_text):
            return {
                "macro_category": macro,
                "error_category": error_category,
                "confidence": confidence,
            }

    return {
        "macro_category": "Other",
        "error_category": "Other_Unclassified",
        "confidence": 0.35,
    }


def map_error_category(rule_id: str, message: str, category: str = "") -> dict[str, Any]:
    """Backward-compatible wrapper around LanguageTool mapping."""
    return map_languagetool_rule_to_error_category(rule_id, message, category)


def validate_error_category(error_category: str | None, macro_category: str | None = None) -> tuple[str, str]:
    """Validate and normalize a category pair."""
    cat = str(error_category or "Other_Unclassified").strip()
    if cat not in CATEGORY_TO_MACRO:
        cat = "Other_Unclassified"
    macro = str(macro_category or CATEGORY_TO_MACRO[cat]).strip()
    if macro not in ERROR_TAXONOMY:
        macro = CATEGORY_TO_MACRO[cat]
    return macro, cat
