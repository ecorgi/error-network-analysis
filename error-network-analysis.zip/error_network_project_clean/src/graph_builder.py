"""Build NetworkX error graphs and node/edge tables."""

from __future__ import annotations

from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd

from .taxonomy import CATEGORY_TO_MACRO, ERROR_CATEGORIES, add_display_columns

NODE_METRIC_COLUMNS = [
    "degree",
    "weighted_degree",
    "degree_centrality",
    "betweenness_centrality",
    "closeness_centrality",
    "eigenvector_centrality",
    "pagerank",
    "community",
]


def build_nodes_table(errors_df: pd.DataFrame, frequencies_df: pd.DataFrame, include_zero: bool = False) -> pd.DataFrame:
    """Create nodes.csv scaffold from frequencies and taxonomy."""
    if frequencies_df is None or frequencies_df.empty:
        rows = []
        total_errors = len(errors_df) if errors_df is not None else 0
        for idx, cat in enumerate(ERROR_CATEGORIES):
            count = int((errors_df["error_category"] == cat).sum()) if errors_df is not None and not errors_df.empty else 0
            rows.append(
                {
                    "node_id": idx,
                    "error_category": cat,
                    "macro_category": CATEGORY_TO_MACRO[cat],
                    "error_count": count,
                    "error_rate": 0.0,
                    "error_rate_per_1000": 0.0,
                    "category_share": count / total_errors if total_errors else 0.0,
                }
            )
        nodes = pd.DataFrame(rows)
    else:
        nodes = frequencies_df[[
            "macro_category",
            "error_category",
            "error_count",
            "error_rate",
            "error_rate_per_1000",
            "category_share",
        ]].copy()
        if not include_zero and "error_count" in nodes.columns:
            nodes = nodes[nodes["error_count"].astype(float) > 0].copy()
        nodes.insert(0, "node_id", range(len(nodes)))

    nodes = add_display_columns(nodes)
    for col in NODE_METRIC_COLUMNS:
        if col == "community":
            nodes[col] = -1
        else:
            nodes[col] = 0.0
    return nodes


def build_edges_table(
    associations_df: pd.DataFrame,
    min_edge_weight: int = 2,
    disable_statistical_filter: bool = False,
    min_jaccard_if_no_stats: float = 0.0,
) -> pd.DataFrame:
    """Create edges.csv from statistically tested associations."""
    columns = [
        "source",
        "target",
        "source_macro_category",
        "target_macro_category",
        "cooccurrence_count",
        "jaccard",
        "phi_coefficient",
        "odds_ratio",
        "p_value",
        "corrected_p_value",
        "significant",
        "weight",
    ]
    if associations_df.empty:
        return pd.DataFrame(columns=columns)

    result = associations_df.copy()
    result = result[result["cooccurrence_count"] >= min_edge_weight].copy()
    if not disable_statistical_filter and "significant" in result.columns:
        result = result[result["significant"] == True].copy()  # noqa: E712
    elif disable_statistical_filter and min_jaccard_if_no_stats > 0:
        result = result[result["jaccard"] >= min_jaccard_if_no_stats].copy()

    if result.empty:
        return pd.DataFrame(columns=columns)

    result["source_macro_category"] = result["source"].map(CATEGORY_TO_MACRO).fillna("Other")
    result["target_macro_category"] = result["target"].map(CATEGORY_TO_MACRO).fillna("Other")

    def choose_weight(row: pd.Series) -> float:
        phi = row.get("phi_coefficient")
        if pd.notna(phi) and float(phi) > 0:
            return float(phi)
        jaccard = row.get("jaccard")
        return float(jaccard) if pd.notna(jaccard) else 0.0

    result["weight"] = result.apply(choose_weight, axis=1).clip(lower=0.0)
    result = result[result["weight"] > 0].copy()
    if result.empty:
        return pd.DataFrame(columns=columns)
    return add_display_columns(result[columns].sort_values(["weight", "cooccurrence_count"], ascending=False).reset_index(drop=True))


def build_edge_filtering_report(
    associations_df: pd.DataFrame,
    edges_df: pd.DataFrame,
    min_edge_weight: int = 2,
    p_threshold: float = 0.05,
    disable_statistical_filter: bool = False,
) -> pd.DataFrame:
    """Summarize why candidate category pairs were filtered out."""
    total = int(len(associations_df))
    if associations_df.empty:
        rows = {
            "pairs_tested": 0,
            "dropped_cooccurrence_count_lt_min_edge_weight": 0,
            "dropped_p_value": 0,
            "dropped_corrected_p_value": 0,
            "dropped_non_positive_weight": 0,
            "edges_written": int(len(edges_df)),
        }
        return pd.DataFrame([rows])
    cooc_ok = associations_df["cooccurrence_count"] >= min_edge_weight
    p_ok = associations_df["p_value"].fillna(1.0) < p_threshold if "p_value" in associations_df.columns else pd.Series(True, index=associations_df.index)
    corrected_ok = (
        associations_df["corrected_p_value"].fillna(1.0) < p_threshold
        if "corrected_p_value" in associations_df.columns
        else pd.Series(True, index=associations_df.index)
    )
    if disable_statistical_filter:
        p_drop = 0
        corrected_drop = 0
    else:
        p_drop = int((cooc_ok & ~p_ok).sum())
        corrected_drop = int((cooc_ok & p_ok & ~corrected_ok).sum())
    weight_candidates = associations_df.loc[cooc_ok].copy()
    if not disable_statistical_filter and "significant" in weight_candidates.columns:
        weight_candidates = weight_candidates[weight_candidates["significant"] == True]  # noqa: E712
    non_positive = 0
    if not weight_candidates.empty:
        phi = pd.to_numeric(weight_candidates.get("phi_coefficient"), errors="coerce")
        jac = pd.to_numeric(weight_candidates.get("jaccard"), errors="coerce")
        weights = phi.where(phi > 0, jac).fillna(0)
        non_positive = int((weights <= 0).sum())
    return pd.DataFrame(
        [
            {
                "pairs_tested": total,
                "dropped_cooccurrence_count_lt_min_edge_weight": int((~cooc_ok).sum()),
                "dropped_p_value": p_drop,
                "dropped_corrected_p_value": corrected_drop,
                "dropped_non_positive_weight": non_positive,
                "edges_written": int(len(edges_df)),
            }
        ]
    )


def build_error_graph(nodes_df: pd.DataFrame, edges_df: pd.DataFrame) -> nx.Graph:
    """Build an undirected weighted NetworkX graph from node and edge tables."""
    graph = nx.Graph()
    for _, row in nodes_df.iterrows():
        category = row["error_category"]
        graph.add_node(
            category,
            macro_category=str(row.get("macro_category", CATEGORY_TO_MACRO.get(category, "Other"))),
            error_count=int(row.get("error_count", 0) or 0),
            error_rate_per_1000=float(row.get("error_rate_per_1000", 0.0) or 0.0),
            community=int(row.get("community", -1) if pd.notna(row.get("community", -1)) else -1),
        )
    for _, row in edges_df.iterrows():
        source = row["source"]
        target = row["target"]
        graph.add_edge(
            source,
            target,
            weight=float(row.get("weight", 0.0) or 0.0),
            cooccurrence_count=int(row.get("cooccurrence_count", 0) or 0),
            jaccard=float(row.get("jaccard", 0.0) or 0.0),
            phi_coefficient=float(row.get("phi_coefficient", 0.0)) if pd.notna(row.get("phi_coefficient")) else 0.0,
            p_value=float(row.get("p_value", 1.0)) if pd.notna(row.get("p_value")) else 1.0,
            corrected_p_value=float(row.get("corrected_p_value", 1.0)) if pd.notna(row.get("corrected_p_value")) else 1.0,
            edge_mode=str(row.get("edge_mode", "")),
            network_unit=str(row.get("network_unit", "")),
            edge_interpretation=str(row.get("edge_interpretation", "")),
        )
    return graph


def save_graph_outputs(G: nx.Graph, output_dir: str | Path) -> None:
    """Save GraphML, GEXF and adjacency matrix files."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    nx.write_graphml(G, output / "error_network.graphml")
    nx.write_gexf(G, output / "error_network.gexf")
    adjacency = nx.to_pandas_adjacency(G, weight="weight") if len(G) else pd.DataFrame()
    adjacency.to_csv(output / "error_network_adjacency_matrix.csv", encoding="utf-8")
