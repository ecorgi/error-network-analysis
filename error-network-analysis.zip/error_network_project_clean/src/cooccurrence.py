"""Co-occurrence tables and statistical association testing."""

from __future__ import annotations

from itertools import combinations
from math import sqrt

import numpy as np
import pandas as pd

from .taxonomy import ERROR_CATEGORIES


def _unit_column(unit: str) -> str:
    """Map unit names to columns."""
    mapping = {"sentence": "sentence_id", "paragraph": "paragraph_id", "text": "text_id"}
    if unit not in mapping:
        raise ValueError(f"Unsupported unit {unit!r}; expected one of {sorted(mapping)}")
    return mapping[unit]


def build_cooccurrence_table(errors_df: pd.DataFrame, units_df: pd.DataFrame, unit: str = "sentence") -> pd.DataFrame:
    """Build 2x2 co-occurrence tables for every pair of error categories."""
    unit_col = _unit_column(unit)
    if unit_col not in units_df.columns:
        raise ValueError(f"Units DataFrame lacks required column: {unit_col}")
    units = units_df[[unit_col]].drop_duplicates().rename(columns={unit_col: "analysis_unit_id"})
    total_units = len(units)

    if errors_df.empty or "error_category" not in errors_df.columns:
        categories: list[str] = []
    else:
        categories = sorted(set(errors_df["error_category"].dropna().astype(str)) & set(ERROR_CATEGORIES))
    if total_units == 0:
        return pd.DataFrame(
            columns=[
                "source",
                "target",
                "a",
                "b",
                "c",
                "d",
                "cooccurrence_count",
                "jaccard",
                "phi_coefficient",
            ]
        )

    if len(categories) < 2:
        return pd.DataFrame(
            columns=[
                "source",
                "target",
                "a",
                "b",
                "c",
                "d",
                "cooccurrence_count",
                "jaccard",
                "phi_coefficient",
            ]
        )

    unit_to_categories: dict[str, set[str]] = {str(uid): set() for uid in units["analysis_unit_id"]}
    if not errors_df.empty:
        if unit_col not in errors_df.columns:
            raise ValueError(f"Errors DataFrame lacks required column for unit {unit!r}: {unit_col}")
        for uid, group in errors_df.dropna(subset=[unit_col]).groupby(unit_col):
            unit_to_categories.setdefault(str(uid), set()).update(group["error_category"].dropna().astype(str).tolist())

    presence = pd.DataFrame(0, index=list(unit_to_categories.keys()), columns=categories, dtype=int)
    for uid, cats in unit_to_categories.items():
        for cat in cats:
            if cat in presence.columns:
                presence.at[uid, cat] = 1

    rows = []
    for cat1, cat2 in combinations(categories, 2):
        x = presence[cat1].to_numpy()
        y = presence[cat2].to_numpy()
        a = int(((x == 1) & (y == 1)).sum())
        b = int(((x == 1) & (y == 0)).sum())
        c = int(((x == 0) & (y == 1)).sum())
        d = int(((x == 0) & (y == 0)).sum())
        denom_j = a + b + c
        jaccard = a / denom_j if denom_j else 0.0
        denom_phi = sqrt((a + b) * (c + d) * (a + c) * (b + d))
        phi = ((a * d) - (b * c)) / denom_phi if denom_phi else np.nan
        rows.append(
            {
                "source": cat1,
                "target": cat2,
                "a": a,
                "b": b,
                "c": c,
                "d": d,
                "cooccurrence_count": a,
                "jaccard": jaccard,
                "phi_coefficient": phi,
            }
        )
    return pd.DataFrame(rows)


def build_unit_error_matrix(errors_df: pd.DataFrame, units_df: pd.DataFrame, unit: str = "sentence") -> pd.DataFrame:
    """Return a binary analysis-unit by error-category matrix for diagnostics."""
    unit_col = _unit_column(unit)
    if unit_col not in units_df.columns:
        raise ValueError(f"Units DataFrame lacks required column: {unit_col}")
    meta_cols = []
    for col in [unit_col, "text_id", "student_id", "time_slice", "lang_level", "topic"]:
        if col in units_df.columns and col not in meta_cols:
            meta_cols.append(col)
    units = units_df[meta_cols].drop_duplicates(unit_col)
    units = units.rename(columns={unit_col: "analysis_unit_id"})
    categories = sorted(set(errors_df["error_category"].dropna().astype(str)) & set(ERROR_CATEGORIES)) if not errors_df.empty else []
    for cat in categories:
        units[cat] = 0
    if not errors_df.empty and unit_col in errors_df.columns:
        for uid, group in errors_df.dropna(subset=[unit_col]).groupby(unit_col):
            mask = units["analysis_unit_id"].astype(str) == str(uid)
            for cat in set(group["error_category"].dropna().astype(str)):
                if cat in units.columns:
                    units.loc[mask, cat] = 1
    return units


def test_error_associations(
    cooc_df: pd.DataFrame,
    correction: str = "fdr_bh",
    p_threshold: float = 0.05,
) -> pd.DataFrame:
    """Run Fisher exact tests and multiple-comparison correction."""
    if cooc_df.empty:
        result = cooc_df.copy()
        for col in ["odds_ratio", "p_value", "corrected_p_value", "significant"]:
            result[col] = []
        return result

    try:
        from scipy.stats import fisher_exact
    except ImportError as exc:
        raise ImportError("scipy is required for Fisher exact tests. Install it with: pip install scipy") from exc

    result = cooc_df.copy()
    odds_ratios = []
    p_values = []
    for _, row in result.iterrows():
        table = [[int(row["a"]), int(row["b"])], [int(row["c"]), int(row["d"] )]]
        try:
            odds, p = fisher_exact(table, alternative="two-sided")
        except Exception:
            odds, p = np.nan, 1.0
        odds_ratios.append(odds)
        p_values.append(p)
    result["odds_ratio"] = odds_ratios
    result["p_value"] = p_values

    if correction == "none":
        result["corrected_p_value"] = result["p_value"]
    else:
        try:
            from statsmodels.stats.multitest import multipletests
        except ImportError as exc:
            raise ImportError("statsmodels is required for p-value correction. Install it with: pip install statsmodels") from exc
        valid = result["p_value"].fillna(1.0).to_numpy()
        _, corrected, _, _ = multipletests(valid, alpha=p_threshold, method=correction)
        result["corrected_p_value"] = corrected
    result["significant"] = result["corrected_p_value"] < p_threshold
    return result
