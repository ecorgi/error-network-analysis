"""Absolute and normalized error frequencies."""

from __future__ import annotations

from itertools import product

import numpy as np
import pandas as pd

from .taxonomy import ERROR_CATEGORIES, CATEGORY_TO_MACRO, add_display_columns


def _empty_freq(columns: list[str]) -> pd.DataFrame:
    """Return an empty frequency table with stable columns."""
    return pd.DataFrame(columns=columns)


def _frequency_for_group(errors_df: pd.DataFrame, units_df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    """Compute category frequencies for a grouping level."""
    base_cols = group_cols + [
        "macro_category",
        "error_category",
        "error_count",
        "word_count",
        "error_rate",
        "error_rate_per_1000",
        "category_share",
    ]
    if units_df.empty:
        return _empty_freq(base_cols)

    unit_word = units_df.copy()
    if group_cols:
        word_counts = unit_word.groupby(group_cols, dropna=False)["token_count"].sum().reset_index(name="word_count")
    else:
        word_counts = pd.DataFrame({"word_count": [unit_word["token_count"].sum()]})

    if errors_df.empty:
        if not group_cols:
            rows = [
                {
                    "macro_category": CATEGORY_TO_MACRO[cat],
                    "error_category": cat,
                    "error_count": 0,
                    "word_count": int(word_counts.iloc[0]["word_count"]) if not word_counts.empty else 0,
                }
                for cat in ERROR_CATEGORIES
            ]
            result = pd.DataFrame(rows)
        else:
            rows = []
            for _, group in word_counts.iterrows():
                for cat in ERROR_CATEGORIES:
                    row = {col: group[col] for col in group_cols}
                    row.update(
                        {
                            "macro_category": CATEGORY_TO_MACRO[cat],
                            "error_category": cat,
                            "error_count": 0,
                            "word_count": group["word_count"],
                        }
                    )
                    rows.append(row)
            result = pd.DataFrame(rows)
    else:
        count_cols = group_cols + ["macro_category", "error_category"]
        counts = errors_df.groupby(count_cols, dropna=False).size().reset_index(name="error_count")
        if not group_cols:
            all_categories = pd.DataFrame(
                {
                    "macro_category": [CATEGORY_TO_MACRO[c] for c in ERROR_CATEGORIES],
                    "error_category": ERROR_CATEGORIES,
                }
            )
            result = all_categories.merge(counts, on=["macro_category", "error_category"], how="left")
            result["word_count"] = int(word_counts.iloc[0]["word_count"])
        else:
            group_values = [word_counts[col].drop_duplicates().tolist() for col in group_cols]
            rows = []
            for values in product(*group_values):
                for cat in ERROR_CATEGORIES:
                    row = dict(zip(group_cols, values))
                    row.update({"macro_category": CATEGORY_TO_MACRO[cat], "error_category": cat})
                    rows.append(row)
            scaffold = pd.DataFrame(rows)
            result = scaffold.merge(counts, on=count_cols, how="left")
            result = result.merge(word_counts, on=group_cols, how="left")
        result["error_count"] = result["error_count"].fillna(0).astype(int)

    result["word_count"] = result["word_count"].fillna(0).astype(float)
    result["error_rate"] = result.apply(
        lambda r: (r["error_count"] / r["word_count"]) if r["word_count"] else 0.0, axis=1
    )
    result["error_rate_per_1000"] = result["error_rate"] * 1000
    if group_cols:
        total_errors = result.groupby(group_cols, dropna=False)["error_count"].transform("sum")
    else:
        total_errors = pd.Series([result["error_count"].sum()] * len(result), index=result.index)
    denominator = total_errors.astype(float).replace(0, np.nan)
    result["category_share"] = (result["error_count"].astype(float) / denominator).fillna(0.0)
    return add_display_columns(result[base_cols])


def calculate_error_frequencies(errors_df: pd.DataFrame, corpus_df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Calculate overall and grouped absolute/normalized error frequencies."""
    tables: dict[str, pd.DataFrame] = {
        "overall": _frequency_for_group(errors_df, corpus_df, []),
        "by_student": _frequency_for_group(errors_df, corpus_df, ["student_id"]),
        "by_lang_level": _frequency_for_group(errors_df, corpus_df, ["lang_level"]),
        "by_time_slice": _frequency_for_group(errors_df, corpus_df, ["time_slice"]),
        "by_topic": _frequency_for_group(errors_df, corpus_df, ["topic"]),
    }
    if "native_lang" in corpus_df.columns and corpus_df["native_lang"].notna().any():
        tables["by_native_lang"] = _frequency_for_group(errors_df, corpus_df, ["native_lang"])
    return tables
