"""Input/output utilities and corpus validation."""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

REQUIRED_COLUMNS = ["text_id", "student_id", "time_slice", "lang_level", "topic", "text"]


def load_corpus(path: str | Path) -> pd.DataFrame:
    """Load the learner corpus from a UTF-8 CSV file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Input CSV not found: {path}")
    try:
        return pd.read_csv(path, encoding="utf-8", dtype={"text_id": str, "student_id": str})
    except UnicodeDecodeError as exc:
        raise UnicodeDecodeError(
            exc.encoding,
            exc.object,
            exc.start,
            exc.end,
            f"Could not decode {path} as UTF-8. Please save the file in UTF-8.",
        ) from exc


def _token_count_simple(text: str) -> int:
    """Count word-like tokens with a simple regex for validation."""
    return len(re.findall(r"\b\w+\b", str(text)))


def validate_corpus(df: pd.DataFrame, min_tokens: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Validate the input corpus and return a cleaned corpus plus a quality report.

    Rows with missing IDs, empty/too short texts, exact duplicates, and duplicate
    text IDs are removed. All actions are recorded in a data quality report.
    """
    missing_columns = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing_columns:
        raise ValueError(f"Input CSV is missing required columns: {missing_columns}")

    report_rows: list[dict[str, Any]] = []
    working = df.copy()
    original_len = len(working)

    duplicated_full = working.duplicated(keep="first")
    for idx in working.index[duplicated_full]:
        report_rows.append(
            {
                "text_id": working.at[idx, "text_id"] if "text_id" in working else f"row_{idx}",
                "issue_type": "duplicate_row",
                "issue_description": "Fully duplicated row.",
                "action": "removed",
            }
        )
    working = working.loc[~duplicated_full].copy()

    for col in ["text_id", "student_id", "text"]:
        missing_mask = working[col].isna() | (working[col].astype(str).str.strip() == "")
        for idx in working.index[missing_mask]:
            report_rows.append(
                {
                    "text_id": working.at[idx, "text_id"] if pd.notna(working.at[idx, "text_id"]) else f"row_{idx}",
                    "issue_type": f"missing_{col}",
                    "issue_description": f"Required field {col!r} is missing or empty.",
                    "action": "removed",
                }
            )
        working = working.loc[~missing_mask].copy()

    non_string_text = ~working["text"].map(lambda value: isinstance(value, str))
    for idx in working.index[non_string_text]:
        report_rows.append(
            {
                "text_id": working.at[idx, "text_id"],
                "issue_type": "non_string_text",
                "issue_description": "Text value is not a string; converted to string.",
                "action": "converted",
            }
        )
    working["text"] = working["text"].astype(str)

    short_mask = working["text"].map(_token_count_simple) < min_tokens
    for idx in working.index[short_mask]:
        report_rows.append(
            {
                "text_id": working.at[idx, "text_id"],
                "issue_type": "too_short_text",
                "issue_description": f"Text has fewer than {min_tokens} word-like tokens.",
                "action": "removed",
            }
        )
    working = working.loc[~short_mask].copy()

    duplicate_text_id = working.duplicated(subset=["text_id"], keep="first")
    for idx in working.index[duplicate_text_id]:
        report_rows.append(
            {
                "text_id": working.at[idx, "text_id"],
                "issue_type": "duplicate_text_id",
                "issue_description": "Duplicate text_id; only the first occurrence is kept.",
                "action": "removed",
            }
        )
    working = working.loc[~duplicate_text_id].copy()

    if not report_rows:
        report_rows.append(
            {
                "text_id": "__corpus__",
                "issue_type": "none",
                "issue_description": f"No data quality issues found in {original_len} rows.",
                "action": "kept",
            }
        )

    quality = pd.DataFrame(report_rows, columns=["text_id", "issue_type", "issue_description", "action"])
    return working.reset_index(drop=True), quality


def load_student_meta(path: str | Path | None) -> pd.DataFrame | None:
    """Load optional student metadata with native language."""
    if path is None:
        return None
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"student_meta.csv not found: {path}")
    meta = pd.read_csv(path, encoding="utf-8", dtype={"student_id": str})
    required = {"student_id", "native_lang"}
    missing = required - set(meta.columns)
    if missing:
        raise ValueError(f"Student metadata is missing required columns: {sorted(missing)}")
    return meta[["student_id", "native_lang"]].drop_duplicates("student_id")


def attach_native_language(
    df: pd.DataFrame,
    meta: pd.DataFrame | None,
    native_lang: str | None,
) -> pd.DataFrame:
    """Attach native language information from metadata or a global CLI value."""
    result = df.copy()
    if meta is not None:
        result = result.merge(meta, on="student_id", how="left")
    elif native_lang:
        result["native_lang"] = native_lang
    elif "native_lang" not in result.columns:
        result["native_lang"] = pd.NA
    return result


def create_run_dir(output_dir: str | Path) -> Path:
    """Create an output directory, avoiding overwrite by adding a timestamp if needed."""
    output = Path(output_dir)
    if output.exists() and any(output.iterdir()):
        timestamp = datetime.now().strftime("run_%Y%m%d_%H%M%S")
        output = output / timestamp
        logging.warning("Output directory was not empty; writing to %s", output)
    output.mkdir(parents=True, exist_ok=True)
    (output / "figures").mkdir(exist_ok=True)
    (output / "groups").mkdir(exist_ok=True)
    return output


def save_dataframe(df: pd.DataFrame, path: str | Path) -> None:
    """Save a DataFrame as UTF-8 CSV, creating parent directories if needed."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False, encoding="utf-8")


def write_json(data: dict[str, Any], path: str | Path) -> None:
    """Write JSON with UTF-8 encoding and stable indentation."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)
