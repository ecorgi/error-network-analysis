"""Longitudinal T1-T3 error-rate analysis."""

from __future__ import annotations

import os
import textwrap
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")

import matplotlib

matplotlib.use("Agg")
matplotlib.rcParams["font.family"] = "DejaVu Sans"
matplotlib.rcParams["axes.unicode_minus"] = False
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from .taxonomy import add_display_columns, error_category_ru

PLOT_RC = {
    "axes.facecolor": "white",
    "figure.facecolor": "white",
    "axes.edgecolor": "#222222",
    "axes.labelcolor": "#111111",
    "axes.labelsize": 16,
    "axes.titlesize": 22,
    "axes.titleweight": "bold",
    "xtick.color": "#111111",
    "ytick.color": "#111111",
    "xtick.labelsize": 13,
    "ytick.labelsize": 13,
    "legend.fontsize": 11,
    "legend.title_fontsize": 12,
    "grid.color": "#b8b8b8",
    "grid.linestyle": ":",
    "grid.linewidth": 0.9,
}
sns.set_theme(style="whitegrid", font="DejaVu Sans", context="talk", rc=PLOT_RC)

TIME_ORDER = ["T1", "T2", "T3"]
TITLE_SIZE = 22
LABEL_SIZE = 16
TICK_SIZE = 13
LEGEND_SIZE = 11
LINE_COLORS = [
    "#4169E1",
    "#FF3B30",
    "#2CA02C",
    "#7B3FE4",
    "#8B5A2B",
    "#7F7F7F",
    "#E377C2",
    "#9B59B6",
    "#17BECF",
    "#BCBD22",
    "#D62728",
    "#1F77B4",
    "#2E8B57",
]


def validate_longitudinal_structure(corpus_df: pd.DataFrame) -> pd.DataFrame:
    """Return a student x time-slice presence table."""
    if not {"student_id", "time_slice"}.issubset(corpus_df.columns):
        return pd.DataFrame()
    table = (
        corpus_df.assign(present=1)
        .pivot_table(index="student_id", columns="time_slice", values="present", aggfunc="sum", fill_value=0)
        .reset_index()
    )
    for time_slice in TIME_ORDER:
        if time_slice not in table.columns:
            table[time_slice] = 0
    table["has_T1_T2_T3"] = table[TIME_ORDER].ge(1).all(axis=1)
    return table[["student_id", *TIME_ORDER, "has_T1_T2_T3"]]


def calculate_longitudinal_error_rates(errors_df: pd.DataFrame, units_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Create long and wide longitudinal error-rate tables."""
    if units_df.empty or not {"student_id", "time_slice", "token_count"}.issubset(units_df.columns):
        return pd.DataFrame(), pd.DataFrame()

    text_meta_cols = [c for c in ["student_id", "lang_level", "topic", "time_slice", "text_id"] if c in units_df.columns]
    word_counts = (
        units_df.groupby(text_meta_cols, dropna=False)["token_count"]
        .sum()
        .reset_index(name="word_count")
        .groupby([c for c in text_meta_cols if c != "text_id"], dropna=False)["word_count"]
        .sum()
        .reset_index()
    )
    if errors_df.empty:
        counts = pd.DataFrame(columns=["student_id", "time_slice", "error_category", "category_error_count"])
        total_counts = pd.DataFrame(columns=["student_id", "time_slice", "total_errors"])
    else:
        counts = (
            errors_df.groupby(["student_id", "time_slice", "error_category"], dropna=False)
            .size()
            .reset_index(name="category_error_count")
        )
        total_counts = (
            errors_df.groupby(["student_id", "time_slice"], dropna=False)
            .size()
            .reset_index(name="total_errors")
        )

    categories = sorted(counts["error_category"].dropna().astype(str).unique().tolist()) if not counts.empty else []
    scaffold_rows = []
    for _, row in word_counts.iterrows():
        if categories:
            for cat in categories:
                item = row.to_dict()
                item["error_category"] = cat
                scaffold_rows.append(item)
        else:
            item = row.to_dict()
            item["error_category"] = "Other_Unclassified"
            scaffold_rows.append(item)
    long_df = pd.DataFrame(scaffold_rows)
    if long_df.empty:
        return pd.DataFrame(), pd.DataFrame()
    long_df = long_df.merge(counts, on=["student_id", "time_slice", "error_category"], how="left")
    long_df = long_df.merge(total_counts, on=["student_id", "time_slice"], how="left")
    long_df["category_error_count"] = long_df["category_error_count"].fillna(0).astype(int)
    long_df["total_errors"] = long_df["total_errors"].fillna(0).astype(int)
    long_df["errors_per_1000"] = long_df.apply(
        lambda r: (r["total_errors"] / r["word_count"] * 1000) if r["word_count"] else 0.0,
        axis=1,
    )
    long_df["category_errors_per_1000"] = long_df.apply(
        lambda r: (r["category_error_count"] / r["word_count"] * 1000) if r["word_count"] else 0.0,
        axis=1,
    )
    long_df = add_display_columns(long_df)

    meta_rows = []
    for student_id, group in units_df.groupby("student_id", dropna=False):
        meta_rows.append(
            {
                "student_id": student_id,
                "lang_level": group["lang_level"].dropna().astype(str).iloc[0] if "lang_level" in group.columns and group["lang_level"].notna().any() else pd.NA,
                "topic": " | ".join(group["topic"].dropna().astype(str).drop_duplicates().tolist()) if "topic" in group.columns else pd.NA,
            }
        )
    student_meta = pd.DataFrame(meta_rows)
    index_cols = ["student_id", "error_category"]
    wide = (
        long_df.pivot_table(
            index=index_cols,
            columns="time_slice",
            values="category_errors_per_1000",
            aggfunc="mean",
        )
        .reset_index()
        .rename_axis(None, axis=1)
    )
    wide = wide.merge(student_meta, on="student_id", how="left")
    for time_slice in TIME_ORDER:
        if time_slice not in wide.columns:
            wide[time_slice] = pd.NA
        wide[f"{time_slice}_rate_per_1000"] = wide[time_slice]
    wide["T2_minus_T1"] = wide["T2_rate_per_1000"] - wide["T1_rate_per_1000"]
    wide["T3_minus_T2"] = wide["T3_rate_per_1000"] - wide["T2_rate_per_1000"]
    wide["T3_minus_T1"] = wide["T3_rate_per_1000"] - wide["T1_rate_per_1000"]

    def trend_label(row: pd.Series) -> str:
        vals = [row.get(f"{t}_rate_per_1000") for t in TIME_ORDER]
        if any(pd.isna(v) for v in vals):
            return "insufficient_data"
        delta_21 = float(row["T2_minus_T1"])
        delta_32 = float(row["T3_minus_T2"])
        delta_31 = float(row["T3_minus_T1"])
        eps = 1e-9
        if abs(delta_21) <= eps and abs(delta_32) <= eps:
            return "stable"
        if delta_31 < -eps and delta_21 <= eps and delta_32 <= eps:
            return "improved"
        if delta_31 > eps and delta_21 >= -eps and delta_32 >= -eps:
            return "worsened"
        return "mixed"

    wide["trend_label"] = wide.apply(trend_label, axis=1)
    wide = add_display_columns(wide)
    keep = [
        c
        for c in [
            "student_id",
            "lang_level",
            "topic",
            "error_category",
            "error_category_ru",
            "T1_rate_per_1000",
            "T2_rate_per_1000",
            "T3_rate_per_1000",
            "T2_minus_T1",
            "T3_minus_T2",
            "T3_minus_T1",
            "trend_label",
        ]
        if c in wide.columns
    ]
    return long_df, wide[keep]


def _save(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def _apply_axis_style(ax: plt.Axes | None = None, *, grid_axis: str = "both") -> plt.Axes:
    ax = ax or plt.gca()
    ax.set_facecolor("white")
    ax.figure.set_facecolor("white")
    ax.grid(True, which="major", axis=grid_axis, linestyle=":", linewidth=0.9, color="#b8b8b8", alpha=0.95)
    for spine in ax.spines.values():
        spine.set_color("#222222")
        spine.set_linewidth(1.1)
    ax.tick_params(axis="both", colors="#111111", labelsize=TICK_SIZE, width=1.1)
    ax.xaxis.label.set_size(LABEL_SIZE)
    ax.yaxis.label.set_size(LABEL_SIZE)
    ax.xaxis.label.set_weight("bold")
    ax.yaxis.label.set_weight("bold")
    return ax


def _style_legend(legend) -> None:
    if legend is None:
        return
    legend.get_frame().set_facecolor("white")
    legend.get_frame().set_edgecolor("#9a9a9a")
    legend.get_frame().set_linewidth(0.9)
    legend.get_frame().set_alpha(0.95)
    legend.get_title().set_fontweight("bold")
    for text in legend.get_texts():
        text.set_color("#111111")
        text.set_fontsize(LEGEND_SIZE)


def _wrap_label(value: object, width: int = 22) -> str:
    text = str(value)
    return "\n".join(textwrap.wrap(text, width=width, break_long_words=False, break_on_hyphens=False)) or text


def _warning_figure(path: Path, message: str) -> None:
    plt.figure(figsize=(12, 6), facecolor="white")
    plt.text(0.5, 0.5, message, ha="center", va="center", wrap=True, fontsize=16, fontweight="bold", color="#111111")
    plt.axis("off")
    _save(path)


def save_longitudinal_figures(long_df: pd.DataFrame, wide_df: pd.DataFrame, output_dir: str | Path) -> None:
    """Save Russian-language longitudinal visualizations."""
    figures = Path(output_dir) / "figures"
    if long_df.empty:
        for name in [
            "longitudinal_total_errors_by_student.png",
            "longitudinal_category_errors_by_student.png",
            "longitudinal_mean_errors_by_time_slice.png",
            "longitudinal_heatmap_student_category_change.png",
            "longitudinal_spaghetti_plot.png",
        ]:
            _warning_figure(figures / name, "Нет данных для построения продольного графика.")
        return

    totals = long_df.drop_duplicates(["student_id", "time_slice"])[["student_id", "time_slice", "errors_per_1000"]].copy()
    observed_times = totals["time_slice"].dropna().astype(str).drop_duplicates().tolist()
    ordered_times = [value for value in TIME_ORDER if value in observed_times]
    ordered_times.extend(sorted(value for value in observed_times if value not in ordered_times))
    if not ordered_times:
        for name in [
            "longitudinal_total_errors_by_student.png",
            "longitudinal_category_errors_by_student.png",
            "longitudinal_mean_errors_by_time_slice.png",
            "longitudinal_heatmap_student_category_change.png",
            "longitudinal_spaghetti_plot.png",
        ]:
            _warning_figure(figures / name, "Нет временных срезов для построения продольного графика.")
        return
    totals["time_slice"] = pd.Categorical(totals["time_slice"].astype(str), ordered_times, ordered=True)

    fig, ax = plt.subplots(figsize=(12, 8), facecolor="white")
    totals_plot = totals.copy()
    totals_plot["time_order"] = totals_plot["time_slice"].astype(str).map({value: idx for idx, value in enumerate(ordered_times)})
    sns.lineplot(
        data=totals_plot.sort_values("time_order"),
        x="time_slice",
        y="errors_per_1000",
        hue="student_id",
        marker="o",
        markersize=5.5,
        linewidth=2.0,
        palette=LINE_COLORS,
        ax=ax,
    )
    ax.set_title("Динамика общего числа ошибок по студентам", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
    ax.set_xlabel("Временной срез")
    ax.set_ylabel("Ошибок на 1000 слов")
    _apply_axis_style(ax, grid_axis="both")
    legend = ax.legend(title="Студент", fontsize=9, title_fontsize=10, bbox_to_anchor=(1.02, 1), loc="upper left", frameon=True)
    _style_legend(legend)
    _save(figures / "longitudinal_total_errors_by_student.png")

    top_cats = (
        long_df.groupby("error_category")["category_error_count"].sum().sort_values(ascending=False).head(8).index.tolist()
    )
    cat_data = long_df[long_df["error_category"].isin(top_cats)].copy()
    fig, ax = plt.subplots(figsize=(13, 8), facecolor="white")
    if cat_data.empty or cat_data["category_error_count"].sum() == 0:
        ax.text(0.5, 0.5, "Нет ненулевых категорий ошибок.", ha="center", va="center", fontsize=16, fontweight="bold")
        ax.axis("off")
    else:
        pivot = cat_data.pivot_table(
            index="student_id",
            columns="error_category",
            values="category_errors_per_1000",
            aggfunc="mean",
            fill_value=0,
        )
        pivot = pivot.rename(columns=error_category_ru).reset_index()
        plot_data = pivot.melt(id_vars="student_id", var_name="Категория ошибки", value_name="Ошибок на 1000 слов")
        sns.barplot(data=plot_data, x="student_id", y="Ошибок на 1000 слов", hue="Категория ошибки", palette="Set2", ax=ax)
        ax.set_title("Категории ошибок по студентам", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
        ax.set_xlabel("Студент")
        ax.set_ylabel("Ошибок на 1000 слов")
        _apply_axis_style(ax, grid_axis="y")
        legend = ax.legend(title="Категория ошибки", fontsize=9, title_fontsize=10, bbox_to_anchor=(1.02, 1), loc="upper left", frameon=True)
        _style_legend(legend)
    _save(figures / "longitudinal_category_errors_by_student.png")

    fig, ax = plt.subplots(figsize=(10, 7), facecolor="white")
    mean_data = totals.groupby("time_slice", observed=False)["errors_per_1000"].mean().reindex(ordered_times)
    sns.lineplot(x=ordered_times, y=mean_data.values, marker="o", markersize=7, linewidth=2.6, color="#7B3FE4", ax=ax)
    ax.set_title("Средняя динамика ошибок по временным срезам", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
    ax.set_xlabel("Временной срез")
    ax.set_ylabel("Ошибок на 1000 слов")
    _apply_axis_style(ax, grid_axis="both")
    _save(figures / "longitudinal_mean_errors_by_time_slice.png")

    fig, ax = plt.subplots(figsize=(13, 9), facecolor="white")
    if wide_df.empty or "T3_minus_T1" not in wide_df.columns:
        ax.text(0.5, 0.5, "Нет данных для тепловой карты.", ha="center", va="center", fontsize=16, fontweight="bold")
        ax.axis("off")
    else:
        heat = wide_df.pivot_table(index="student_id", columns="error_category_ru", values="T3_minus_T1", aggfunc="mean")
        if heat.empty:
            ax.text(0.5, 0.5, "Нет данных для тепловой карты.", ha="center", va="center", fontsize=16, fontweight="bold")
            ax.axis("off")
        else:
            heat.columns = [_wrap_label(col, width=18) for col in heat.columns]
            sns.heatmap(
                heat.fillna(0),
                cmap="coolwarm",
                center=0,
                linewidths=0.5,
                linecolor="#f0f0f0",
                annot=False,
                cbar_kws={"label": "Изменение T3-T1, ошибок на 1000 слов"},
                ax=ax,
            )
            ax.set_xticklabels(ax.get_xticklabels(), rotation=90, fontsize=10, color="#111111")
            ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=11, color="#111111")
            ax.set_title("Изменение категорий ошибок от T1 к T3", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
            cbar = ax.collections[0].colorbar
            cbar.ax.tick_params(labelsize=11, colors="#111111")
            cbar.ax.yaxis.label.set_size(13)
            cbar.ax.yaxis.label.set_weight("bold")
    _save(figures / "longitudinal_heatmap_student_category_change.png")

    fig, ax = plt.subplots(figsize=(12, 8), facecolor="white")
    sns.lineplot(
        data=totals_plot.sort_values("time_order"),
        x="time_slice",
        y="errors_per_1000",
        units="student_id",
        estimator=None,
        alpha=0.5,
        marker="o",
        linewidth=1.7,
        color="#4169E1",
        ax=ax,
    )
    sns.lineplot(x=ordered_times, y=mean_data.values, color="black", linewidth=3.2, marker="o", markersize=7, label="Среднее", ax=ax)
    ax.set_title("Индивидуальные траектории ошибок", fontsize=TITLE_SIZE, fontweight="bold", color="#111111", pad=12)
    ax.set_xlabel("Временной срез")
    ax.set_ylabel("Ошибок на 1000 слов")
    _apply_axis_style(ax, grid_axis="both")
    legend = ax.legend(frameon=True)
    _style_legend(legend)
    _save(figures / "longitudinal_spaghetti_plot.png")
