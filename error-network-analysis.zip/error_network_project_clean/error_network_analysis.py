#!/usr/bin/env python3
"""CLI pipeline for network analysis of learner English error categories."""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd

from src.annotation import annotate_errors, detect_possible_interference, empty_errors_df, load_annotations
from src.comparison import compare_group_networks
from src.cooccurrence import build_cooccurrence_table, build_unit_error_matrix, test_error_associations
from src.diagnostics import (
    compatibility_report_dataframe,
    format_incompatibility_error,
    validate_annotation_compatibility,
    write_diagnostic_report,
)
from src.frequencies import calculate_error_frequencies
from src.graph_builder import (
    build_edge_filtering_report,
    build_edges_table,
    build_error_graph,
    build_nodes_table,
    save_graph_outputs,
)
from src.io_utils import (
    attach_native_language,
    create_run_dir,
    load_corpus,
    load_student_meta,
    save_dataframe,
    validate_corpus,
    write_json,
)
from src.longitudinal import calculate_longitudinal_error_rates, save_longitudinal_figures, validate_longitudinal_structure
from src.metrics import (
    apply_communities,
    calculate_edge_metrics,
    calculate_graph_metrics,
    calculate_node_metrics,
    communities_dataframe,
    detect_communities,
    merge_node_metrics,
)
from src.preprocessing import preprocess_texts
from src.pronoun_review import apply_pronouns_review, build_pronouns_review
from src.reporting import generate_report
from src.sensitivity import compare_without_pronouns, export_network_edges
from src.taxonomy import add_display_columns
from src.validation import calculate_inter_annotator_agreement, compare_with_expert_validation, create_stratified_validation_sample
from src.visualization import save_all_figures, visualize_network


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Network analysis of learner English error categories from mini-essays.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--input", required=True, help="Path to essays CSV.")
    parser.add_argument("--output-dir", required=True, help="Directory for outputs.")
    parser.add_argument("--language", default="en", help="Language code for spaCy and LanguageTool.")
    parser.add_argument("--spacy-model", default=None, help="Optional explicit spaCy model, e.g. en_core_web_lg.")
    parser.add_argument(
        "--annotation-strategy",
        choices=["combined", "languagetool", "heuristic"],
        default="combined",
        help="Automatic annotation strategy when --annotations is not supplied.",
    )
    parser.add_argument("--student-meta", default=None, help="Optional CSV with student_id,native_lang.")
    parser.add_argument("--native-lang", default=None, help="Optional native language for the whole corpus, e.g. ru.")
    parser.add_argument("--unit", choices=["sentence", "paragraph", "text"], default="sentence", help="Analysis unit for co-occurrence.")
    parser.add_argument("--min-edge-weight", type=int, default=2, help="Minimum co-occurrence count for an edge.")
    parser.add_argument("--p-threshold", type=float, default=0.05, help="Significance threshold.")
    parser.add_argument("--correction", choices=["bonferroni", "fdr_bh", "none"], default="fdr_bh", help="Multiple-comparison correction method.")
    parser.add_argument("--skip-grammar-check", action="store_true", help="Do not run LanguageTool. Use --annotations or produce empty errors.")
    parser.add_argument("--annotations", default=None, help="Optional CSV with pre-existing/expert error annotations.")
    parser.add_argument("--allow-partial-annotations", action="store_true", help="Allow annotations for a compatible subset of corpus texts.")
    parser.add_argument("--strict-annotation-check", action=argparse.BooleanOptionalAction, default=True, help="Fail on incompatible annotation files.")
    parser.add_argument("--compare-by", default="lang_level,time_slice,student_id", help="Comma-separated grouping specs; use + for combinations, e.g. native_lang+lang_level.")
    parser.add_argument("--save-figures", action="store_true", help="Save visualizations.")
    parser.add_argument("--plot-language", choices=["ru", "en"], default="ru", help="Language for plot labels.")
    parser.add_argument("--report-language", choices=["ru", "en"], default="ru", help="Language for report text.")
    parser.add_argument("--verbose", action="store_true", help="Verbose logging.")
    parser.add_argument("--disable-statistical-filter", action="store_true", help="Create edges by co-occurrence/Jaccard thresholds without significance filtering.")
    parser.add_argument("--min-jaccard-if-no-stats", type=float, default=0.0, help="Minimum Jaccard when statistical filtering is disabled.")
    parser.add_argument(
        "--edge-mode",
        choices=["auto", "confirmatory", "exploratory"],
        default="auto",
        help="Network edge construction mode. auto tries confirmatory Fisher/FDR first, then exploratory fallback if no edges are found.",
    )
    parser.add_argument("--exploratory-min-edge-weight", type=int, default=1, help="Minimum co-occurrence count for exploratory edges.")
    parser.add_argument("--exploratory-min-jaccard", type=float, default=0.05, help="Minimum Jaccard for exploratory edges.")
    parser.add_argument(
        "--network-fallback-units",
        default="paragraph,text",
        help="Comma-separated analysis units to try in auto exploratory mode after --unit.",
    )
    parser.add_argument("--make-validation-sample", action="store_true", help="Write a stratified expert validation sample to validation_sample.csv.")
    parser.add_argument("--validation-sample-fraction", type=float, default=0.30, help="Corpus fraction for expert validation sampling; values below 0.20 are raised to 0.20.")
    parser.add_argument("--validation-strata", default="lang_level,time_slice", help="Comma-separated corpus columns used for stratified validation sampling.")
    parser.add_argument("--validation-random-seed", type=int, default=42, help="Random seed for validation sampling.")
    parser.add_argument("--expert-validation", default=None, help="CSV returned by an expert for validation_sample.csv; writes validation_report.csv and validation_confusion_matrix.csv.")
    parser.add_argument(
        "--expert-annotation-files",
        nargs="*",
        default=[],
        help="Two or more expert CSV files for inter-annotator agreement; supports validation_id or text_id/sentence_id/span keys.",
    )
    parser.add_argument("--pronouns-review", default=None, help="CSV review file with pronoun_status values; only true_error Pronouns remain in downstream analysis.")
    parser.add_argument("--sensitivity-without-pronouns", action="store_true", help="Build and compare a second network without the Pronouns category.")
    parser.add_argument("--sensitivity-change-threshold", type=float, default=0.10, help="Absolute metric delta treated as substantial in sensitivity reports.")
    return parser.parse_args(argv)


def setup_logging(verbose: bool) -> None:
    """Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(message)s")
    logging.getLogger("matplotlib").setLevel(logging.WARNING)


def _save_frequency_tables(frequencies: dict[str, pd.DataFrame], output_dir: Path) -> None:
    """Save all frequency tables with required filenames."""
    name_map = {
        "overall": "error_frequencies_overall.csv",
        "by_student": "error_frequencies_by_student.csv",
        "by_lang_level": "error_frequencies_by_lang_level.csv",
        "by_time_slice": "error_frequencies_by_time_slice.csv",
        "by_topic": "error_frequencies_by_topic.csv",
        "by_native_lang": "error_frequencies_by_native_lang.csv",
    }
    for key, filename in name_map.items():
        if key in frequencies:
            save_dataframe(frequencies[key], output_dir / filename)


def _parse_compare_specs(compare_by: str, available_columns: set[str]) -> list[list[str]]:
    """Parse comma-separated comparison specs."""
    specs: list[list[str]] = []
    for raw in (compare_by or "").split(","):
        raw = raw.strip()
        if not raw:
            continue
        cols = [c.strip() for c in raw.split("+") if c.strip()]
        if all(col in available_columns for col in cols):
            specs.append(cols)
        else:
            logging.warning("Skipping comparison spec %r because some columns are unavailable.", raw)
    return specs


def _unit_sequence(primary_unit: str, fallback_units: str) -> list[str]:
    """Return a de-duplicated unit fallback sequence."""
    units = [primary_unit]
    units.extend(unit.strip() for unit in (fallback_units or "").split(",") if unit.strip())
    result: list[str] = []
    for unit in units:
        if unit in {"sentence", "paragraph", "text"} and unit not in result:
            result.append(unit)
    return result


def _build_association_bundle(
    errors_df: pd.DataFrame,
    units_df: pd.DataFrame,
    unit: str,
    correction: str,
    p_threshold: float,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Build co-occurrence, unit matrix and association tables for one unit."""
    cooc = build_cooccurrence_table(errors_df, units_df, unit=unit)
    matrix = build_unit_error_matrix(errors_df, units_df, unit=unit)
    assoc = test_error_associations(cooc, correction=correction, p_threshold=p_threshold)
    return cooc, matrix, assoc


def _mark_edges(edges: pd.DataFrame, edge_mode: str, network_unit: str) -> pd.DataFrame:
    """Attach interpretation metadata to edge rows."""
    result = edges.copy()
    if result.empty:
        for col in ["edge_mode", "network_unit", "edge_interpretation"]:
            if col not in result.columns:
                result[col] = pd.Series(dtype="object")
        return result
    result["edge_mode"] = edge_mode
    result["network_unit"] = network_unit
    if edge_mode == "confirmatory":
        result["edge_interpretation"] = "Fisher/FDR-significant positive co-occurrence"
    else:
        result["edge_interpretation"] = "Exploratory positive co-occurrence for small-corpus network extraction"
    return result


def _construct_network_edges(
    errors_df: pd.DataFrame,
    units_df: pd.DataFrame,
    args: argparse.Namespace,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Construct edges, falling back to an exploratory network when needed."""
    attempts: list[dict[str, Any]] = []
    selected: tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]] | None = None
    units = _unit_sequence(args.unit, args.network_fallback_units)

    if args.edge_mode in {"auto", "confirmatory"} and not args.disable_statistical_filter:
        cooc, matrix, assoc = _build_association_bundle(errors_df, units_df, args.unit, args.correction, args.p_threshold)
        edges = build_edges_table(
            assoc,
            min_edge_weight=args.min_edge_weight,
            disable_statistical_filter=False,
            min_jaccard_if_no_stats=args.min_jaccard_if_no_stats,
        )
        edges = _mark_edges(edges, "confirmatory", args.unit)
        attempts.append(
            {
                "attempt_order": len(attempts) + 1,
                "network_unit": args.unit,
                "edge_mode": "confirmatory",
                "min_edge_weight": args.min_edge_weight,
                "min_jaccard": args.min_jaccard_if_no_stats,
                "pairs_tested": int(len(assoc)),
                "edges_found": int(len(edges)),
                "selected": False,
            }
        )
        selected = (cooc, matrix, assoc, edges, attempts[-1])
        if len(edges) > 0 or args.edge_mode == "confirmatory":
            attempts[-1]["selected"] = True
            return cooc, matrix, assoc, edges, {"attempts": attempts, **attempts[-1]}

    if args.edge_mode in {"auto", "exploratory"} or args.disable_statistical_filter:
        for unit in units:
            cooc, matrix, assoc = _build_association_bundle(errors_df, units_df, unit, args.correction, args.p_threshold)
            edges = build_edges_table(
                assoc,
                min_edge_weight=args.exploratory_min_edge_weight,
                disable_statistical_filter=True,
                min_jaccard_if_no_stats=args.exploratory_min_jaccard,
            )
            edges = _mark_edges(edges, "exploratory", unit)
            attempts.append(
                {
                    "attempt_order": len(attempts) + 1,
                    "network_unit": unit,
                    "edge_mode": "exploratory",
                    "min_edge_weight": args.exploratory_min_edge_weight,
                    "min_jaccard": args.exploratory_min_jaccard,
                    "pairs_tested": int(len(assoc)),
                    "edges_found": int(len(edges)),
                    "selected": False,
                }
            )
            selected = (cooc, matrix, assoc, edges, attempts[-1])
            if len(edges) > 0:
                attempts[-1]["selected"] = True
                return cooc, matrix, assoc, edges, {"attempts": attempts, **attempts[-1]}

    if selected is None:
        cooc, matrix, assoc = _build_association_bundle(errors_df, units_df, args.unit, args.correction, args.p_threshold)
        edges = build_edges_table(assoc, min_edge_weight=args.min_edge_weight)
        edges = _mark_edges(edges, "confirmatory", args.unit)
        selected = (cooc, matrix, assoc, edges, {"network_unit": args.unit, "edge_mode": "confirmatory"})
    selected[4]["selected"] = True
    return selected[0], selected[1], selected[2], selected[3], {"attempts": attempts, **selected[4]}


def run_pipeline(args: argparse.Namespace) -> Path:
    """Execute the full analysis pipeline and return the output directory."""
    output_dir = create_run_dir(args.output_dir)
    logging.info("Writing results to %s", output_dir)

    run_info: dict[str, Any] = {
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "command_args": vars(args),
        "annotation_mode": "annotations" if args.annotations else ("none" if args.skip_grammar_check else "LanguageTool"),
    }

    logging.info("1/16 Loading and validating corpus")
    corpus_raw = load_corpus(args.input)
    corpus_df, quality_report = validate_corpus(corpus_raw)
    meta = load_student_meta(args.student_meta)
    corpus_df = attach_native_language(corpus_df, meta, args.native_lang)
    save_dataframe(quality_report, output_dir / "data_quality_report.csv")

    logging.info("2/16 Preprocessing texts")
    units_df = preprocess_texts(corpus_df, language=args.language, spacy_model=args.spacy_model)
    save_dataframe(units_df, output_dir / "preprocessed_texts.csv")

    logging.info("3/16 Annotating errors")
    annotation_compatibility: dict[str, Any] = {}
    if args.annotations:
        annotations_preview = pd.read_csv(args.annotations, encoding="utf-8", dtype={"text_id": str, "student_id": str})
        annotation_compatibility = validate_annotation_compatibility(corpus_df, annotations_preview)
        save_dataframe(compatibility_report_dataframe(annotation_compatibility), output_dir / "annotation_compatibility_report.csv")
        student_time = annotation_compatibility.get("student_time_distribution")
        if isinstance(student_time, pd.DataFrame):
            save_dataframe(student_time, output_dir / "student_time_distribution.csv")
        external_guess = annotation_compatibility.get("external_corpus_guess")
        corpus_id_sample = corpus_df["text_id"].dropna().astype(str).head(20).tolist()
        if external_guess and not any(external_guess.lower().split("/")[0].replace("&", "").replace("+", "").strip() in x.lower() for x in corpus_id_sample):
            write_diagnostic_report(annotation_compatibility, output_dir / "report.md")
            raise ValueError(format_incompatibility_error(annotation_compatibility))
        if (
            args.strict_annotation_check
            and not args.allow_partial_annotations
            and annotation_compatibility["annotation_text_id_valid_ratio"] < 0.95
        ):
            write_diagnostic_report(annotation_compatibility, output_dir / "report.md")
            raise ValueError(format_incompatibility_error(annotation_compatibility))
        errors_df = load_annotations(
            args.annotations,
            units_df,
            corpus_df,
            allow_partial=args.allow_partial_annotations,
            strict=args.strict_annotation_check,
        )
    elif args.skip_grammar_check:
        logging.warning("Grammar check skipped and no annotations provided; analysis will continue with zero errors.")
        errors_df = empty_errors_df()
    else:
        errors_df = annotate_errors(
            units_df,
            language=args.language,
            strategy=args.annotation_strategy,
            spacy_model=args.spacy_model,
        )
    errors_df = add_display_columns(detect_possible_interference(errors_df))
    save_dataframe(errors_df, output_dir / "detected_errors.csv")

    pronouns_review = build_pronouns_review(errors_df, units_df)
    save_dataframe(pronouns_review, output_dir / "pronouns_review.csv")
    if args.pronouns_review:
        errors_df, applied_review = apply_pronouns_review(errors_df, args.pronouns_review)
        errors_df = add_display_columns(errors_df)
        save_dataframe(applied_review, output_dir / "pronouns_review_applied.csv")
        save_dataframe(errors_df, output_dir / "detected_errors_after_pronouns_review.csv")

    validation_sample = pd.DataFrame()
    if args.make_validation_sample:
        strata = [col.strip() for col in str(args.validation_strata or "").split(",") if col.strip()]
        validation_sample = create_stratified_validation_sample(
            corpus_df,
            units_df,
            errors_df,
            fraction=args.validation_sample_fraction,
            strata_cols=strata,
            random_seed=args.validation_random_seed,
        )
        save_dataframe(validation_sample, output_dir / "validation_sample.csv")
    if args.expert_validation:
        validation_report, validation_confusion = compare_with_expert_validation(validation_sample, args.expert_validation)
        save_dataframe(validation_report, output_dir / "validation_report.csv")
        save_dataframe(validation_confusion, output_dir / "validation_confusion_matrix.csv")
    if args.expert_annotation_files and len(args.expert_annotation_files) >= 2:
        agreement = calculate_inter_annotator_agreement(args.expert_annotation_files)
        save_dataframe(agreement, output_dir / "inter_annotator_agreement.csv")
    elif args.expert_annotation_files:
        logging.warning("--expert-annotation-files needs at least two files; skipping agreement calculation.")

    logging.info("4/16 Calculating frequencies")
    frequencies = calculate_error_frequencies(errors_df, units_df)
    _save_frequency_tables(frequencies, output_dir)

    logging.info("5/16 Building co-occurrence and association tables")
    cooc_df, unit_error_matrix, associations_df, edges_df, network_info = _construct_network_edges(errors_df, units_df, args)
    logging.info(
        "Selected network: unit=%s, edge_mode=%s, edges=%s.",
        network_info.get("network_unit", args.unit),
        network_info.get("edge_mode", args.edge_mode),
        len(edges_df),
    )
    save_dataframe(cooc_df, output_dir / "cooccurrence_tables.csv")
    save_dataframe(unit_error_matrix, output_dir / "unit_error_matrix.csv")
    save_dataframe(cooc_df.head(100), output_dir / "cooccurrence_debug_sample.csv")
    save_dataframe(associations_df, output_dir / "associations.csv")
    save_dataframe(pd.DataFrame(network_info.get("attempts", [network_info])), output_dir / "network_construction_report.csv")

    logging.info("6/16 Building nodes, edges and graph")
    edge_filtering_report = build_edge_filtering_report(
        associations_df,
        edges_df,
        min_edge_weight=int(network_info.get("min_edge_weight", args.min_edge_weight)),
        p_threshold=args.p_threshold,
        disable_statistical_filter=network_info.get("edge_mode") == "exploratory" or args.disable_statistical_filter,
    )
    nodes_df = build_nodes_table(errors_df, frequencies["overall"])
    graph = build_error_graph(nodes_df, edges_df)

    logging.info("7/16 Detecting communities and calculating metrics")
    communities = detect_communities(graph)
    apply_communities(graph, communities)
    node_metrics = calculate_node_metrics(graph)
    nodes_df = merge_node_metrics(nodes_df, node_metrics)
    graph = build_error_graph(nodes_df, edges_df)
    apply_communities(graph, communities)
    graph_metrics = calculate_graph_metrics(graph)
    edge_metrics = calculate_edge_metrics(graph)
    communities_df = communities_dataframe(graph, errors_df, node_metrics)

    save_dataframe(nodes_df, output_dir / "nodes.csv")
    save_dataframe(edges_df, output_dir / "edges.csv")
    save_dataframe(export_network_edges(edges_df), output_dir / "network_edges.csv")
    save_dataframe(edge_filtering_report, output_dir / "edge_filtering_report.csv")
    save_dataframe(node_metrics, output_dir / "node_metrics.csv")
    save_dataframe(edge_metrics, output_dir / "edge_metrics.csv")
    save_dataframe(communities_df, output_dir / "communities.csv")
    write_json(graph_metrics, output_dir / "graph_metrics.json")
    save_graph_outputs(graph, output_dir)

    if args.sensitivity_without_pronouns:
        logging.info("7A/16 Running sensitivity analysis without Pronouns")
        reduced_errors = (
            errors_df[~errors_df["error_category"].astype(str).eq("Pronouns")].copy()
            if "error_category" in errors_df.columns
            else errors_df.copy()
        )
        reduced_freq = calculate_error_frequencies(reduced_errors, units_df)
        _, _, reduced_assoc, reduced_edges, reduced_network_info = _construct_network_edges(reduced_errors, units_df, args)
        reduced_nodes = build_nodes_table(reduced_errors, reduced_freq["overall"])
        reduced_graph = build_error_graph(reduced_nodes, reduced_edges)
        reduced_communities = detect_communities(reduced_graph)
        apply_communities(reduced_graph, reduced_communities)
        reduced_node_metrics = calculate_node_metrics(reduced_graph)
        reduced_nodes = merge_node_metrics(reduced_nodes, reduced_node_metrics)
        reduced_graph = build_error_graph(reduced_nodes, reduced_edges)
        apply_communities(reduced_graph, reduced_communities)
        reduced_graph_metrics = calculate_graph_metrics(reduced_graph)
        reduced_edge_metrics = calculate_edge_metrics(reduced_graph)
        reduced_communities_df = communities_dataframe(reduced_graph, reduced_errors, reduced_node_metrics)

        reduced_dir = output_dir / "without_pronouns"
        save_dataframe(reduced_assoc, reduced_dir / "associations_without_pronouns.csv")
        save_dataframe(reduced_nodes, reduced_dir / "nodes_without_pronouns.csv")
        save_dataframe(reduced_edges, reduced_dir / "edges_without_pronouns.csv")
        save_dataframe(export_network_edges(reduced_edges), output_dir / "network_edges_without_pronouns.csv")
        save_dataframe(reduced_edge_metrics, reduced_dir / "edge_metrics_without_pronouns.csv")
        save_dataframe(reduced_communities_df, reduced_dir / "communities_without_pronouns.csv")
        save_dataframe(pd.DataFrame(reduced_network_info.get("attempts", [reduced_network_info])), reduced_dir / "network_construction_report_without_pronouns.csv")
        write_json(reduced_graph_metrics, reduced_dir / "graph_metrics_without_pronouns.json")
        save_graph_outputs(reduced_graph, reduced_dir)
        sensitivity_report = compare_without_pronouns(
            graph_metrics,
            reduced_graph_metrics,
            node_metrics,
            reduced_node_metrics,
            edges_df,
            reduced_edges,
            change_threshold=args.sensitivity_change_threshold,
        )
        save_dataframe(sensitivity_report, output_dir / "sensitivity_without_pronouns.csv")

    logging.info("8/16 Visualizing")
    if args.save_figures:
        save_all_figures(graph, frequencies, nodes_df, edges_df, output_dir, plot_language=args.plot_language)
        if args.sensitivity_without_pronouns:
            visualize_network(reduced_graph, output_dir / "figures" / "error_network_without_pronouns.png", plot_language=args.plot_language)

    logging.info("8A/16 Calculating longitudinal T1-T3 rates")
    longitudinal_structure = validate_longitudinal_structure(corpus_df)
    longitudinal_long, longitudinal_wide = calculate_longitudinal_error_rates(errors_df, units_df)
    save_dataframe(longitudinal_structure, output_dir / "longitudinal_structure.csv")
    save_dataframe(longitudinal_long, output_dir / "longitudinal_error_rates.csv")
    save_dataframe(longitudinal_wide, output_dir / "longitudinal_error_rates_wide.csv")
    if args.save_figures:
        save_longitudinal_figures(longitudinal_long, longitudinal_wide, output_dir)

    logging.info("9/16 Comparing group-specific networks")
    compare_summary: dict[str, str] = {}
    compare_specs = _parse_compare_specs(args.compare_by, set(units_df.columns))
    combined_compare_tables: dict[str, list[pd.DataFrame]] = {
        "compare_node_centrality": [],
        "compare_error_rates": [],
        "compare_edge_weights": [],
        "compare_graph_metrics": [],
    }
    for spec in compare_specs:
        result = compare_group_networks(
            errors_df,
            units_df,
            group_by=spec,
            output_dir=output_dir,
            unit=args.unit,
            min_edge_weight=args.min_edge_weight,
            correction=args.correction,
            p_threshold=args.p_threshold,
            disable_statistical_filter=args.disable_statistical_filter,
            edge_mode=args.edge_mode,
            exploratory_min_edge_weight=args.exploratory_min_edge_weight,
            exploratory_min_jaccard=args.exploratory_min_jaccard,
            network_fallback_units=args.network_fallback_units,
            save_figures=args.save_figures,
        )
        compare_summary.update(result.get("summary", {}))  # type: ignore[arg-type]
        for key in combined_compare_tables:
            table = result.get(key)
            if isinstance(table, pd.DataFrame) and not table.empty:
                table = table.copy()
                table["comparison_spec"] = "+".join(spec)
                combined_compare_tables[key].append(table)

    for key, tables in combined_compare_tables.items():
        if tables:
            save_dataframe(pd.concat(tables, ignore_index=True), output_dir / f"{key}.csv")
        else:
            save_dataframe(pd.DataFrame(), output_dir / f"{key}.csv")

    logging.info("10/16 Generating report")
    generate_report(
        {
            "corpus_df": corpus_df,
            "units_df": units_df,
            "errors_df": errors_df,
            "frequencies": frequencies,
            "nodes_df": nodes_df,
            "edges_df": edges_df,
            "communities_df": communities_df,
            "graph_metrics": graph_metrics,
            "compare_summary": compare_summary,
            "longitudinal_long": longitudinal_long,
            "longitudinal_wide": longitudinal_wide,
            "annotation_compatibility": annotation_compatibility,
            "input_path": args.input,
            "annotations_path": args.annotations,
            "unit": args.unit,
            "p_threshold": args.p_threshold,
            "correction": args.correction,
            "network_info": network_info,
        },
        output_dir / "report.md",
    )

    run_info["finished_at"] = datetime.now().isoformat(timespec="seconds")
    run_info["output_dir"] = str(output_dir)
    run_info["num_texts"] = int(corpus_df["text_id"].nunique()) if "text_id" in corpus_df.columns else 0
    run_info["num_errors"] = int(len(errors_df))
    write_json(run_info, output_dir / "run_info.json")
    logging.info("Analysis completed: %s", output_dir)
    return output_dir


def main(argv: list[str] | None = None) -> int:
    """CLI entry point."""
    args = parse_args(argv)
    setup_logging(args.verbose)
    try:
        run_pipeline(args)
    except Exception as exc:
        if args.verbose:
            logging.exception("Pipeline failed: %s", exc)
        else:
            logging.error("Pipeline failed: %s", exc)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
