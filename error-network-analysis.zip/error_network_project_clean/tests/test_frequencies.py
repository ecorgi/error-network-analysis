import pandas as pd

from src.frequencies import calculate_error_frequencies


def test_overall_frequency_per_1000():
    units = pd.DataFrame(
        {
            "text_id": ["t1", "t1"],
            "student_id": ["s1", "s1"],
            "lang_level": ["A2", "A2"],
            "time_slice": ["pre", "pre"],
            "topic": ["travel", "travel"],
            "token_count": [10, 10],
        }
    )
    errors = pd.DataFrame(
        {
            "error_category": ["Articles_Determiners", "Articles_Determiners"],
            "macro_category": ["Grammar", "Grammar"],
            "student_id": ["s1", "s1"],
            "lang_level": ["A2", "A2"],
            "time_slice": ["pre", "pre"],
            "topic": ["travel", "travel"],
        }
    )
    tables = calculate_error_frequencies(errors, units)
    row = tables["overall"].query("error_category == 'Articles_Determiners'").iloc[0]
    assert row["error_count"] == 2
    assert row["error_rate_per_1000"] == 100.0
