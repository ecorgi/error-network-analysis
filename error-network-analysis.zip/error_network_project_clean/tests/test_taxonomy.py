from src.taxonomy import map_error_category, validate_error_category


def test_article_rule_maps_to_articles():
    result = map_error_category("EN_A_VS_AN", "Use the article 'an'", "GRAMMAR")
    assert result["error_category"] == "Articles_Determiners"
    assert result["macro_category"] == "Grammar"
    assert result["confidence"] > 0.5


def test_unknown_category_falls_back():
    macro, cat = validate_error_category("Unknown", "BadMacro")
    assert macro == "Other"
    assert cat == "Other_Unclassified"
