import subprocess
import sys
from pathlib import Path

import pandas as pd


def test_converter_writes_annotations_without_essays(tmp_path: Path):
    m2 = tmp_path / "sample.m2"
    m2.write_text(
        "S I has a apple .\n"
        "A 1 2|||VERB:SVA|||have|||REQUIRED|||-NONE-|||0\n"
        "A 2 3|||DET|||an|||REQUIRED|||-NONE-|||0\n\n",
        encoding="utf-8",
    )
    out = tmp_path / "out"
    script = Path(__file__).resolve().parents[1] / "scripts" / "build_annotations_from_gec_corpora.py"
    subprocess.run(
        [
            sys.executable,
            str(script),
            "--format",
            "m2",
            "--dataset",
            "custom_research_noncommercial",
            "--allow-custom-dataset",
            "--input-glob",
            str(m2),
            "--output-dir",
            str(out),
            "--accept-license",
        ],
        check=True,
    )

    assert (out / "annotations.csv").exists()
    assert (out / "text_index.csv").exists()
    assert not (out / "essays.csv").exists()
    text_index = pd.read_csv(out / "text_index.csv")
    assert "text" not in text_index.columns
    annotations = pd.read_csv(out / "annotations.csv")
    assert set(annotations["error_category"]) == {"Verb_Form_Morphology", "Articles_Determiners"}
