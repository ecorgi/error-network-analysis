from pathlib import Path

import pandas as pd

from src.comparison import compare_group_networks


def test_group_network_uses_exploratory_fallback(tmp_path: Path):
    units = pd.DataFrame(
        {
            "text_id": ["t1", "t1", "t2", "t2"],
            "student_id": ["s1", "s1", "s2", "s2"],
            "lang_level": ["A2", "A2", "A2", "A2"],
            "time_slice": ["T1", "T1", "T1", "T1"],
            "topic": ["x", "x", "x", "x"],
            "sentence_id": ["s1a", "s1b", "s2a", "s2b"],
            "paragraph_id": ["p1", "p1", "p2", "p2"],
            "token_count": [10, 10, 10, 10],
        }
    )
    errors = pd.DataFrame(
        {
            "text_id": ["t1", "t1", "t2", "t2"],
            "student_id": ["s1", "s1", "s2", "s2"],
            "lang_level": ["A2", "A2", "A2", "A2"],
            "time_slice": ["T1", "T1", "T1", "T1"],
            "topic": ["x", "x", "x", "x"],
            "sentence_id": ["s1a", "s1b", "s2a", "s2b"],
            "paragraph_id": ["p1", "p1", "p2", "p2"],
            "macro_category": ["Grammar", "Grammar", "Grammar", "Grammar"],
            "error_category": ["Prepositions", "Pronouns", "Prepositions", "Pronouns"],
        }
    )
    result = compare_group_networks(
        errors,
        units,
        group_by=["lang_level"],
        output_dir=tmp_path,
        unit="sentence",
        edge_mode="auto",
        exploratory_min_edge_weight=1,
        exploratory_min_jaccard=0.01,
        save_figures=False,
    )
    edges = result["compare_edge_weights"]
    metrics = result["compare_graph_metrics"]
    assert isinstance(edges, pd.DataFrame)
    assert isinstance(metrics, pd.DataFrame)
    assert not edges.empty
    assert edges.iloc[0]["network_unit"] == "paragraph"
    assert metrics.iloc[0]["selected_edge_mode"] == "exploratory"
