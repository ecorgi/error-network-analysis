from pathlib import Path

import pandas as pd
import pytest

from error_network_analysis import parse_args, run_pipeline
from src.annotation import load_annotations
from src.diagnostics import validate_annotation_compatibility
from src.longitudinal import calculate_longitudinal_error_rates
from src.taxonomy import error_category_ru, macro_category_ru
from src.visualization import top_errors_barplot


def _units() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "text_id": ["txt_01"],
            "student_id": ["stu_01"],
            "time_slice": ["T1"],
            "lang_level": ["B1"],
            "topic": ["topic"],
            "sentence_id": ["txt_01::s0000"],
            "paragraph_id": ["txt_01::p0000"],
            "sentence_text": ["I has a apple."],
            "sentence_start_char": [0],
            "sentence_end_char": [14],
            "token_count": [4],
            "clean_text": ["I has a apple."],
        }
    )


def _annotations(text_id: str = "txt_01", source_corpus: str = "input_corpus") -> pd.DataFrame:
    return pd.DataFrame(
        {
            "error_id": ["e1"],
            "text_id": [text_id],
            "student_id": ["stu_01"],
            "sentence_id": [f"{text_id}::s0000" if text_id == "txt_01" else "jfleg_001::s0000"],
            "start_char": [2],
            "end_char": [5],
            "error_span": ["has"],
            "suggested_correction": ["have"],
            "macro_category": ["Grammar"],
            "error_category": ["Subject_Verb_Agreement"],
            "interference_flag": [None],
            "interference_type": ["not_evaluated"],
            "confidence": [0.9],
            "source_corpus": [source_corpus],
        }
    )


def test_incompatible_annotations_fail(tmp_path: Path):
    annotations = tmp_path / "ann.csv"
    _annotations(text_id="jfleg_001", source_corpus="jfleg_github").to_csv(annotations, index=False)
    corpus = pd.DataFrame({"text_id": ["txt_01"], "student_id": ["stu_01"], "time_slice": ["T1"], "lang_level": ["B1"], "topic": ["topic"]})
    with pytest.raises(ValueError, match="incompatible"):
        load_annotations(annotations, _units(), corpus)


def test_compatible_annotations_pipeline_writes_detected_errors(tmp_path: Path):
    corpus = tmp_path / "corpus.csv"
    annotations = tmp_path / "annotations.csv"
    pd.DataFrame(
        {
            "text_id": ["txt_01"],
            "student_id": ["stu_01"],
            "time_slice": ["T1"],
            "lang_level": ["B1"],
            "topic": ["topic"],
            "text": ["I has a apple in university today."],
        }
    ).to_csv(corpus, index=False)
    ann = _annotations()
    ann["end_char"] = [5]
    ann.to_csv(annotations, index=False)

    args = parse_args(
        [
            "--input",
            str(corpus),
            "--annotations",
            str(annotations),
            "--skip-grammar-check",
            "--output-dir",
            str(tmp_path / "out"),
            "--unit",
            "sentence",
        ]
    )
    out = run_pipeline(args)
    assert (out / "detected_errors.csv").exists()
    detected = pd.read_csv(out / "detected_errors.csv")
    assert detected.loc[0, "text_id"] == "txt_01"


def test_longitudinal_rates_include_t1_t2_t3():
    units = pd.DataFrame(
        {
            "text_id": ["t1", "t2", "t3"],
            "student_id": ["s1", "s1", "s1"],
            "time_slice": ["T1", "T2", "T3"],
            "lang_level": ["B1", "B1", "B1"],
            "topic": ["a", "a", "a"],
            "token_count": [100, 100, 100],
        }
    )
    errors = pd.DataFrame(
        {
            "student_id": ["s1", "s1", "s1"],
            "time_slice": ["T1", "T2", "T3"],
            "error_category": ["Articles_Determiners", "Articles_Determiners", "Articles_Determiners"],
        }
    )
    long_df, wide_df = calculate_longitudinal_error_rates(errors, units)
    assert set(long_df["time_slice"]) == {"T1", "T2", "T3"}
    assert {"T1_rate_per_1000", "T2_rate_per_1000", "T3_rate_per_1000"}.issubset(wide_df.columns)


def test_empty_plot_writes_warning_png(tmp_path: Path):
    path = tmp_path / "empty.png"
    top_errors_barplot(pd.DataFrame(), path)
    assert path.exists()
    assert path.stat().st_size > 1000


def test_russian_category_labels():
    assert error_category_ru("Prepositions") == "Предлоги"
    assert macro_category_ru("Grammar") == "Грамматика"


def test_jfleg_annotations_cannot_be_applied_to_custom_corpus(tmp_path: Path):
    annotations = tmp_path / "ann.csv"
    _annotations(text_id="txt_01", source_corpus="jfleg_github").to_csv(annotations, index=False)
    corpus = pd.DataFrame({"text_id": ["txt_01"], "student_id": ["stu_01"], "time_slice": ["T1"], "lang_level": ["B1"], "topic": ["topic"]})
    report = validate_annotation_compatibility(corpus, pd.read_csv(annotations))
    assert report["external_corpus_guess"] == "JFLEG"
    with pytest.raises(ValueError, match="incompatible"):
        load_annotations(annotations, _units(), corpus)
