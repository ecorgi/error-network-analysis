import pandas as pd

from src.cooccurrence import build_cooccurrence_table


def test_sentence_cooccurrence_counts():
    units = pd.DataFrame({"sentence_id": ["s1", "s2", "s3"]})
    errors = pd.DataFrame(
        {
            "sentence_id": ["s1", "s1", "s2"],
            "error_category": ["Articles_Determiners", "Prepositions", "Articles_Determiners"],
        }
    )
    cooc = build_cooccurrence_table(errors, units, unit="sentence")
    row = cooc[(cooc["source"] == "Articles_Determiners") & (cooc["target"] == "Prepositions")].iloc[0]
    assert row["a"] == 1
    assert row["b"] == 1
    assert row["c"] == 0
    assert row["d"] == 1
