from pathlib import Path

import pandas as pd

from src.pronoun_review import apply_pronouns_review, build_pronouns_review
from src.sensitivity import compare_without_pronouns, export_network_edges
from src.validation import (
    calculate_inter_annotator_agreement,
    compare_with_expert_validation,
    create_stratified_validation_sample,
)


def test_stratified_validation_sample_has_editable_expert_columns():
    corpus = pd.DataFrame(
        {
            "text_id": [f"t{i}" for i in range(10)],
            "student_id": [f"s{i}" for i in range(10)],
            "time_slice": ["T1"] * 5 + ["T2"] * 5,
            "lang_level": ["A2", "B1"] * 5,
            "topic": ["topic"] * 10,
            "text": ["I has a apple in class today."] * 10,
        }
    )
    units = pd.DataFrame({"sentence_id": [f"t{i}::s0" for i in range(10)], "sentence_text": ["I has a apple."] * 10})
    errors = pd.DataFrame(
        {
            "text_id": ["t0", "t1", "t2"],
            "student_id": ["s0", "s1", "s2"],
            "time_slice": ["T1", "T1", "T1"],
            "lang_level": ["A2", "B1", "A2"],
            "topic": ["topic"] * 3,
            "sentence_id": ["t0::s0", "t1::s0", "t2::s0"],
            "start_char": [2, 2, 2],
            "end_char": [5, 5, 5],
            "error_span": ["has", "has", "has"],
            "macro_category": ["Grammar"] * 3,
            "error_category": ["Subject_Verb_Agreement", "Pronouns", "Articles_Determiners"],
        }
    )
    sample = create_stratified_validation_sample(corpus, units, errors, fraction=0.2, random_seed=1)
    assert sample["text_id"].nunique() >= 2
    assert {"validation_id", "auto_error_category", "expert_error_category", "expert_comment"}.issubset(sample.columns)


def test_validation_report_and_confusion_matrix(tmp_path: Path):
    expert = pd.DataFrame(
        {
            "validation_id": ["v1", "v2", "v3"],
            "auto_error_category": ["Pronouns", "Articles_Determiners", "NO_ERROR"],
            "expert_error_category": ["NO_ERROR", "Articles_Determiners", "NO_ERROR"],
            "expert_is_error": ["false", "true", "false"],
        }
    )
    path = tmp_path / "expert.csv"
    expert.to_csv(path, index=False)
    report, confusion = compare_with_expert_validation(pd.DataFrame(), path)
    assert {"accuracy_overall", "precision", "recall", "f1"}.issubset(report.columns)
    assert "expert_label" in confusion.columns


def test_inter_annotator_agreement_for_two_experts(tmp_path: Path):
    first = tmp_path / "expert_a.csv"
    second = tmp_path / "expert_b.csv"
    pd.DataFrame({"validation_id": ["v1", "v2"], "expert_error_category": ["Pronouns", "NO_ERROR"]}).to_csv(first, index=False)
    pd.DataFrame({"validation_id": ["v1", "v2"], "expert_error_category": ["Pronouns", "Articles_Determiners"]}).to_csv(second, index=False)
    agreement = calculate_inter_annotator_agreement([first, second])
    assert "cohen_kappa" in set(agreement["metric"])
    assert "Pronouns" in set(agreement["category"])


def test_pronouns_review_filters_non_errors(tmp_path: Path):
    errors = pd.DataFrame(
        {
            "error_id": ["e1", "e2"],
            "text_id": ["t1", "t1"],
            "sentence_id": ["s1", "s1"],
            "start_char": [0, 5],
            "end_char": [2, 7],
            "error_span": ["it", "a"],
            "error_category": ["Pronouns", "Articles_Determiners"],
        }
    )
    units = pd.DataFrame({"sentence_id": ["s1"], "sentence_text": ["it is a test"]})
    review = build_pronouns_review(errors, units)
    review["pronoun_status"] = ["pronoun_usage"]
    path = tmp_path / "pronouns.csv"
    review.to_csv(path, index=False)
    filtered, applied = apply_pronouns_review(errors, path)
    assert len(applied) == 1
    assert set(filtered["error_category"]) == {"Articles_Determiners"}


def test_network_edge_export_and_sensitivity_table():
    edges = pd.DataFrame(
        {
            "source": ["Pronouns", "Articles_Determiners"],
            "target": ["Prepositions", "Prepositions"],
            "weight": [0.4, 0.2],
            "p_value": [0.01, 0.02],
            "corrected_p_value": [0.03, 0.04],
            "jaccard": [0.5, 0.3],
            "phi_coefficient": [0.4, 0.2],
        }
    )
    exported = export_network_edges(edges)
    assert list(exported.columns) == ["source", "target", "weight", "p_value", "q_value", "jaccard", "phi"]
    full_nodes = pd.DataFrame({"error_category": ["Pronouns"], "degree": [1], "weighted_degree": [0.4], "betweenness_centrality": [0], "eigenvector_centrality": [0], "pagerank": [1]})
    reduced_nodes = pd.DataFrame({"error_category": ["Pronouns"], "degree": [0], "weighted_degree": [0.0], "betweenness_centrality": [0], "eigenvector_centrality": [0], "pagerank": [0]})
    report = compare_without_pronouns(
        {"num_nodes": 2, "num_edges": 1, "density": 1.0, "average_degree": 1.0, "average_weighted_degree": 0.4},
        {"num_nodes": 1, "num_edges": 0, "density": 0.0, "average_degree": 0.0, "average_weighted_degree": 0.0},
        full_nodes,
        reduced_nodes,
        edges.iloc[[0]],
        pd.DataFrame(columns=edges.columns),
    )
    assert {"graph_metric", "node_metric", "edge"}.issubset(set(report["row_type"]))
