import subprocess
import sys
from pathlib import Path

import pandas as pd


def test_converter_can_write_corpus_csv_from_real_source_text(tmp_path: Path):
    m2 = tmp_path / "sample.m2"
    m2.write_text(
        "S I has a apple .\n"
        "A 1 2|||VERB:SVA|||have|||REQUIRED|||-NONE-|||0\n\n",
        encoding="utf-8",
    )
    out = tmp_path / "out"
    script = Path(__file__).resolve().parents[1] / "scripts" / "build_annotations_from_gec_corpora.py"
    subprocess.run(
        [
            sys.executable,
            str(script),
            "--format",
            "m2",
            "--dataset",
            "custom_research_noncommercial",
            "--allow-custom-dataset",
            "--input-glob",
            str(m2),
            "--output-dir",
            str(out),
            "--accept-license",
            "--write-corpus-csv",
        ],
        check=True,
    )

    assert (out / "essays.csv").exists()
    essays = pd.read_csv(out / "essays.csv")
    assert set(["text_id", "student_id", "time_slice", "lang_level", "topic", "text"]).issubset(essays.columns)
    assert essays.loc[0, "text"] == "I has a apple ."
    annotations = pd.read_csv(out / "annotations.csv")
    assert set(annotations["text_id"]).issubset(set(essays["text_id"]))
