import pandas as pd

from src.graph_builder import build_edges_table, build_error_graph, build_nodes_table


def test_graph_has_weighted_edge():
    freqs = pd.DataFrame(
        {
            "macro_category": ["Grammar", "Grammar"],
            "error_category": ["Articles_Determiners", "Prepositions"],
            "error_count": [3, 2],
            "error_rate": [0.1, 0.05],
            "error_rate_per_1000": [100, 50],
            "category_share": [0.6, 0.4],
        }
    )
    nodes = build_nodes_table(pd.DataFrame(), freqs)
    assoc = pd.DataFrame(
        {
            "source": ["Articles_Determiners"],
            "target": ["Prepositions"],
            "cooccurrence_count": [2],
            "jaccard": [0.5],
            "phi_coefficient": [0.4],
            "odds_ratio": [3.0],
            "p_value": [0.01],
            "corrected_p_value": [0.02],
            "significant": [True],
        }
    )
    edges = build_edges_table(assoc, min_edge_weight=1)
    graph = build_error_graph(nodes, edges)
    assert graph.has_edge("Articles_Determiners", "Prepositions")
    assert graph["Articles_Determiners"]["Prepositions"]["weight"] == 0.4
